# AML Portal Build Status

## Current milestone
MVP runnable local portal with synthetic AML data pipeline.

## Completed
- Scaffolded production-shaped local stack in `aml-portal/`.
- Implemented backend (FastAPI + SQLAlchemy + Postgres schema + indexes).
- Implemented worker queue (Redis + RQ) for asynchronous seeding jobs.
- Implemented realistic synthetic data generator with AML typologies:
  - structuring, layering, rapid in/out, high-risk corridors.
- Implemented risk engine + explainability (`rule_hits`, reasons).
- Implemented APIs:
  - search clients, client detail, network view, analytics summary, seed job queue/status.
- Implemented React portal UI for investigators:
  - search, client list, detail, transactions, network summary, seeding trigger.
- Added one-command startup (`make up`) and smoke test script.

## In progress
- MVP validated end-to-end locally (native stack mode).

## Runtime validation completed
- Installed and started local Postgres + Redis via Homebrew.
- Created DB/role (`aml_portal`, user `aml`).
- Started API, worker, and frontend.
- Ran seed job (1,000 clients x 8 tx/client) through queue successfully.
- Verified endpoints:
  - `/api/health`
  - `/api/analytics/summary`
  - `/api/clients`
  - `/api/clients/{id}`
  - `/api/network/{id}`
- Executed `scripts/smoke_test.sh` successfully.
- Fixed worker compatibility bug with RQ 2.x (`Connection` import) and macOS fork safety (`OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES`).

## Next actions
1. Increase seed to larger volumes (50k+ per run) and monitor throughput.
2. Add table partitioning migration for transactions by month.
3. Add richer graph analytics metrics (centrality/ring patterns).
4. Add auth/audit logging layer for production hardening.

## Blockers
- Docker CLI not installed on host. Added native one-command startup (`make local-up`) so project remains fully runnable locally.
