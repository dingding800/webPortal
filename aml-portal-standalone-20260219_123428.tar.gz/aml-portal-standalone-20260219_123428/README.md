# AML Portal

Local AML analyst portal (FastAPI + Postgres + Redis/RQ + React/Vite) with deep client drill-down.

## What’s included

- Large detail panel UX with tabs:
  - Demographics
  - Client History
  - Transactions
  - Counterparties
  - Cases/Alerts
- Client demographic/history entities:
  - historical names, addresses, phones
  - world-check hits
  - alerts + cases linked to client
- Transaction analytics enhancements:
  - larger synthetic volume defaults (6,000 clients x 60 tx/client baseline, with per-client multiplier for much larger histories)
  - significantly more cross-border wire traffic
  - explicit source/destination country risk tiers (low/medium/high)
  - explicit transaction types include: `debit`, `credit`, `wire`, `cash`, `emt` (plus card)
  - richer transaction attributes in `typology_tags`:
    - `purpose_code`, `source_country`, `destination_country`
    - `source_country_risk_tier`, `destination_country_risk_tier`
    - `corridor_risk_tag`, `cross_border`
    - `velocity_24h_count`, `velocity_7d_count`, `velocity_24h_amount`, `velocity_7d_amount`
    - `recurring_flag`, `round_amount_flag`, `weekend_flag`, `night_flag`
- UI analytics upgrades:
  - transactions table adds richer columns: type, direction, amount+currency, date, country name, counterparty, channel, purpose code, flags/tags
  - transactions pagination (50/100/200/300 rows per page) for large per-client histories
  - login activity filters simplified to date-only (from/to), backed by full-day boundary filtering
  - country-share wire pie chart with high-risk countries highlighted in red
  - high-risk exposure KPI, inflow/outflow imbalance KPI
  - top corridors table + suspicious feature flag summary
  - country and counterparty drill-down filters into transaction list
- Counterparties table with drill into underlying transactions
- Case management:
  - case ID link to client
  - status enum: Open, Close, Investigating, RFI
  - timestamped case notes
  - computed case age (days)
- Client risk rating enum used in filters and badges:
  - Standard, Medium, High1, High2, High3
- Segment values constrained to:
  - white label ATM
  - payment processor
  - non profit
  - gambling
  - small business
  - public company
  - personal investment
- Analyst extras:
  - outstanding alerts queue
  - decision support actions: up-risk / down-risk / no change with reason log

## New analytics API endpoints

- `GET /api/analytics/country-flow/{client_id}`
  - inbound/outbound wire amounts by country
  - country share percentages
  - risk tier aggregation
  - high-risk totals + ratio
  - top corridors
- `GET /api/analytics/transaction-features/{client_id}`
  - transaction mix by type/direction/channel
  - suspicious flag counts + ratios

## Stability guarantees

- Frontend fixed at `http://localhost:5174` (`strictPort: true`, no Vite drift)
- Seed duplicate-key robustness:
  - client IDs start after existing max client ID
  - generated IDs avoid collisions on repeated seed runs

## Run locally

```bash
cd /Users/dingceliu/.openclaw/workspace/aml-portal
make local-up
```

URLs:
- Frontend: http://localhost:5174
- API docs: http://localhost:8001/docs

## Seed sample data

Larger default preset (used by UI “Queue Seed” button):

```bash
curl -X POST http://localhost:8001/api/seed \
  -H 'Content-Type: application/json' \
  -d '{"clients":6000,"tx_per_client":60,"batch_size":600}'
```

Lighter local test preset:

```bash
curl -X POST http://localhost:8001/api/seed \
  -H 'Content-Type: application/json' \
  -d '{"clients":1200,"tx_per_client":16,"batch_size":400}'
```

## Tests

Smoke test:

```bash
make smoke
```

Targeted API checks (manual):

```bash
CID=$(curl -s 'http://localhost:8001/api/clients?page=1&page_size=1' | jq -r '.items[0].client_id')

curl "http://localhost:8001/api/analytics/country-flow/$CID" | jq .
curl "http://localhost:8001/api/analytics/transaction-features/$CID" | jq .
```

## Screenshots

Saved under:

- `aml-portal/reports/`

Example files after run:

- `reports/aml-dashboard-main.png`
- `reports/aml-dashboard-transactions.png`
- `reports/aml-dashboard-cases.png`
