from datetime import datetime

from redis import Redis
from rq import Worker, get_current_job
from sqlalchemy import text

from app.core.config import settings
from app.db.session import SessionLocal
from app.models.entities import SeedJob
from app.services.seed_data import bulk_seed


def run_seed_job(clients: int, tx_per_client: int, batch_size: int):
    job = get_current_job()
    db = SessionLocal()
    try:
        db.merge(SeedJob(job_id=job.id, status='running', target_clients=clients, metadata_json={
            'tx_per_client': tx_per_client,
            'batch_size': batch_size,
        }))
        db.commit()
        result = bulk_seed(db, clients, tx_per_client, batch_size)
        row = db.get(SeedJob, job.id)
        if row:
            row.status = 'finished'
            row.updated_at = datetime.utcnow()
            row.metadata_json = {'result': result}
            db.commit()
        return result
    except Exception as e:
        row = db.get(SeedJob, job.id)
        if row:
            row.status = 'failed'
            row.updated_at = datetime.utcnow()
            row.metadata_json = {'error': str(e)}
            db.commit()
        raise
    finally:
        db.close()


if __name__ == '__main__':
    redis_conn = Redis.from_url(settings.redis_url)
    worker = Worker(['aml_seed'], connection=redis_conn)
    worker.work()
