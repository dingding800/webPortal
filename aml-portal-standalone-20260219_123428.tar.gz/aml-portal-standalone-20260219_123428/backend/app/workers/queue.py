from redis import Redis
from rq import Queue

from app.core.config import settings

redis_conn = Redis.from_url(settings.redis_url)
queue = Queue('aml_seed', connection=redis_conn)


def enqueue_seed(clients: int, tx_per_client: int, batch_size: int):
    return queue.enqueue('app.workers.worker.run_seed_job', clients, tx_per_client, batch_size, job_timeout='2h')
