from datetime import datetime, date
from sqlalchemy import (
    String, Integer, Float, DateTime, Date, ForeignKey, Text, Index, JSON
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


class Client(Base):
    __tablename__ = 'clients'

    client_id: Mapped[str] = mapped_column(String(24), primary_key=True)
    full_name: Mapped[str] = mapped_column(String(120), index=True)
    dob: Mapped[date] = mapped_column(Date)
    gender: Mapped[str] = mapped_column(String(16), index=True)
    country: Mapped[str] = mapped_column(String(64), index=True)
    city: Mapped[str] = mapped_column(String(64), index=True)
    segment: Mapped[str] = mapped_column(String(40), index=True)
    occupation: Mapped[str] = mapped_column(String(80), default='unknown')
    annual_income: Mapped[float] = mapped_column(Float)
    account_open_date: Mapped[date] = mapped_column(Date)
    pep_flag: Mapped[int] = mapped_column(Integer, default=0)
    sanctions_flag: Mapped[int] = mapped_column(Integer, default=0)
    profile_text: Mapped[str] = mapped_column(Text)
    risk_rating: Mapped[str] = mapped_column(String(16), default='Standard', index=True)

    transactions = relationship('Transaction', back_populates='client', foreign_keys='Transaction.client_id')
    risk = relationship('RiskResult', back_populates='client', uselist=False)


class Transaction(Base):
    __tablename__ = 'transactions'

    tx_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    counterparty_id: Mapped[str] = mapped_column(String(24), index=True)
    tx_type: Mapped[str] = mapped_column(String(16), index=True)
    direction: Mapped[str] = mapped_column(String(16), default='outgoing', index=True)
    amount: Mapped[float] = mapped_column(Float, index=True)
    currency: Mapped[str] = mapped_column(String(8), default='USD')
    channel: Mapped[str] = mapped_column(String(24), default='mobile')
    country: Mapped[str] = mapped_column(String(64), index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, index=True)
    typology_tags: Mapped[dict] = mapped_column(JSON, default=dict)

    client = relationship('Client', back_populates='transactions', foreign_keys=[client_id])


class RiskResult(Base):
    __tablename__ = 'risk_results'

    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), primary_key=True)
    risk_score: Mapped[float] = mapped_column(Float, index=True)
    rule_hits: Mapped[dict] = mapped_column(JSON, default=dict)
    model_reason: Mapped[str] = mapped_column(Text)
    last_updated: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    client = relationship('Client', back_populates='risk')


class ClientNameHistory(Base):
    __tablename__ = 'client_name_history'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    full_name: Mapped[str] = mapped_column(String(120))
    from_date: Mapped[date] = mapped_column(Date)
    to_date: Mapped[date | None] = mapped_column(Date, nullable=True)


class ClientAddressHistory(Base):
    __tablename__ = 'client_address_history'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    address_line: Mapped[str] = mapped_column(String(160))
    city: Mapped[str] = mapped_column(String(64))
    country: Mapped[str] = mapped_column(String(64))
    from_date: Mapped[date] = mapped_column(Date)
    to_date: Mapped[date | None] = mapped_column(Date, nullable=True)


class ClientPhoneHistory(Base):
    __tablename__ = 'client_phone_history'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    phone: Mapped[str] = mapped_column(String(40))
    from_date: Mapped[date] = mapped_column(Date)
    to_date: Mapped[date | None] = mapped_column(Date, nullable=True)


class WorldCheckHit(Base):
    __tablename__ = 'world_check_hits'

    hit_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    category: Mapped[str] = mapped_column(String(40), index=True)
    match_score: Mapped[float] = mapped_column(Float)
    source: Mapped[str] = mapped_column(String(80))
    notes: Mapped[str] = mapped_column(Text)


class Case(Base):
    __tablename__ = 'cases'

    case_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    status: Mapped[str] = mapped_column(String(20), default='Open', index=True)
    opened_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    title: Mapped[str] = mapped_column(String(180))


class CaseNote(Base):
    __tablename__ = 'case_notes'

    note_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    case_id: Mapped[str] = mapped_column(ForeignKey('cases.case_id'), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    note: Mapped[str] = mapped_column(Text)


class Alert(Base):
    __tablename__ = 'alerts'

    alert_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    case_id: Mapped[str | None] = mapped_column(ForeignKey('cases.case_id'), nullable=True, index=True)
    severity: Mapped[str] = mapped_column(String(16), index=True)
    status: Mapped[str] = mapped_column(String(16), default='Open', index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    description: Mapped[str] = mapped_column(Text)


class RiskDecisionLog(Base):
    __tablename__ = 'risk_decision_logs'

    decision_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    action: Mapped[str] = mapped_column(String(16), index=True)  # up-risk/down-risk/no-change
    reason: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class LoginActivity(Base):
    __tablename__ = 'login_activity'

    login_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    ip_address: Mapped[str] = mapped_column(String(64), index=True)
    ip_country: Mapped[str] = mapped_column(String(8), index=True)
    status: Mapped[str] = mapped_column(String(16), default='success', index=True)
    channel: Mapped[str] = mapped_column(String(24), default='web')
    logged_in_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)


class SeedJob(Base):
    __tablename__ = 'seed_jobs'

    job_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    status: Mapped[str] = mapped_column(String(16), index=True)
    target_clients: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)


Index('idx_tx_client_time', Transaction.client_id, Transaction.timestamp)
Index('idx_tx_counterparty_time', Transaction.counterparty_id, Transaction.timestamp)
Index('idx_risk_score_desc', RiskResult.risk_score.desc())
Index('idx_login_client_time', LoginActivity.client_id, LoginActivity.logged_in_at.desc())
