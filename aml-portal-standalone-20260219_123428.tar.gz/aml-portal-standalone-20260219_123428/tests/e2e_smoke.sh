#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/frontend"

npx playwright install chromium >/dev/null
node tests/e2e_smoke.mjs
