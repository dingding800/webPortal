#!/usr/bin/env bash
set -euo pipefail
BASE=${1:-http://localhost:8001/api}

ALLOWED='["white label ATM","payment processor","non profit","gambling","small business","public company","personal investment"]'

echo "[targeted] segments constrained"
SEG=$(curl -sf "$BASE/analytics/segments")
python3 - <<'PY' "$SEG" "$ALLOWED"
import json,sys
rows=json.loads(sys.argv[1]); allowed=set(json.loads(sys.argv[2]))
found={r['segment'] for r in rows}
assert found.issubset(allowed), f"unexpected segments: {found-allowed}"
print('ok')
PY

echo "[targeted] client detail has new entities"
CID=$(curl -sf "$BASE/clients?page=1&page_size=1" | jq -r '.items[0].client_id')
DET=$(curl -sf "$BASE/clients/$CID")
python3 - <<'PY' "$DET"
import json,sys
x=json.loads(sys.argv[1])
for k in ['history','world_check_hits','cases','alerts','wire_country_breakdown','risk_decisions']:
    assert k in x, f"missing {k}"
txs=x.get('transactions', [])
assert txs, 'transactions missing'
assert all('counterparty_name' in t for t in txs[:20]), 'counterparty_name missing on transactions'
print('ok')
PY

echo "[targeted] connections endpoint"
CONN=$(curl -sf "$BASE/clients/$CID/connections")
python3 - <<'PY' "$CONN"
import json,sys
x=json.loads(sys.argv[1])
for k in ['nodes','edges','linked_entities','summary']:
    assert k in x, f"missing {k}"
assert any(n.get('entity_type') == 'client' for n in x['nodes']), 'client node missing'
assert any(e.get('link_type') == 'transacted_with' for e in x['edges']), 'transaction edge missing'
cp_rows=[r for r in x['linked_entities'] if r.get('entity_type')=='counterparty']
if cp_rows:
    assert cp_rows[0].get('label'), 'counterparty label missing'
    assert cp_rows[0]['label'] != cp_rows[0].get('entity_id'), 'counterparty label should be human-readable'
edge=next((e for e in x['edges'] if e.get('link_type')=='transacted_with'), None)
if edge:
    assert edge.get('reason'), 'edge reason missing'
    md=edge.get('metadata', {})
    assert md.get('counterparty_name'), 'edge metadata counterparty_name missing'
    assert md.get('counterparty_id'), 'edge metadata counterparty_id missing'
    assert isinstance(md.get('transaction_ids'), list), 'edge metadata transaction_ids missing'
    assert md.get('direction') in {'incoming','outgoing','mixed'}, 'edge metadata direction missing'
print('ok')
PY

CP=$(echo "$CONN" | jq -r '.linked_entities[] | select(.entity_type=="counterparty") | .entity_id' | head -n 1)
if [ -n "$CP" ]; then
  curl -sf "$BASE/clients/$CID/connections/path/$CP" | jq -e '.path.hop_count >= 1' >/dev/null
fi

echo "[targeted] export endpoints"
HTTP_CSV=$(curl -s -o /tmp/aml_tx_export.csv -w '%{http_code}' "$BASE/clients/$CID/export/transactions.csv")
[ "$HTTP_CSV" = "200" ] && head -n 1 /tmp/aml_tx_export.csv | grep -q 'tx_id,timestamp,tx_type'
HTTP_JSON=$(curl -s -o /tmp/aml_dossier.json -w '%{http_code}' "$BASE/clients/$CID/export/dossier.json")
[ "$HTTP_JSON" = "200" ] && jq -e '.client.client_id == "'$CID'"' /tmp/aml_dossier.json >/dev/null

echo "[targeted] case status update endpoint"
CASE_ID=$(echo "$DET" | jq -r '.cases[0].case_id // empty')
if [ -n "$CASE_ID" ]; then
  curl -sf -X POST "$BASE/cases/$CASE_ID/status" -H 'Content-Type: application/json' \
    -d '{"status":"Investigating","reason":"targeted-api-test"}' | jq -e '.status=="ok"' >/dev/null
fi

echo "targeted tests passed"
