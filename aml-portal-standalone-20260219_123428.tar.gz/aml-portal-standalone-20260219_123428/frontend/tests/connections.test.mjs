import test from 'node:test'
import assert from 'node:assert/strict'

import {
  buildEdgeTransactionContext,
  buildGraphModel,
  buildSessionLayoutKey,
  clampGraphPosition,
  deriveDraggedPosition,
  edgeCommentBadge,
  getEntityVisual,
  hydrateLayoutOverrides,
  narrateEdge,
  narratePath,
  serializeLayoutOverrides,
  summarizePath,
  withSecondaryId,
} from '../src/connections.js'

test('buildGraphModel keeps highest-importance nodes and filters edges', () => {
  const nodes = [
    { id: 'client:C1', entity_type: 'client', importance: 1, label: 'Client 1' },
    ...Array.from({ length: 35 }).map((_, i) => ({
      id: `n-${i}`,
      entity_type: i % 2 ? 'counterparty' : 'address',
      importance: 0.8 - i * 0.01,
      label: `Node ${i}`,
    })),
  ]
  const edges = [
    { id: 'e-1', source: 'client:C1', target: 'n-0' },
    { id: 'e-2', source: 'n-0', target: 'n-1' },
    { id: 'e-3', source: 'client:C1', target: 'excluded-node' },
  ]

  const model = buildGraphModel({ nodes, edges }, 10, 20)

  assert.equal(model.sortedNodes.length, 10)
  assert.equal(model.graphEdges.length, 2)
  assert.ok(model.positions['client:C1'])
})

test('summarizePath renders readable arrow chain', () => {
  const out = summarizePath({ nodes: [{ label: 'Client A' }, { label: 'ACC-1' }, { label: 'CP-9' }] })
  assert.equal(out, 'Client A → ACC-1 → CP-9')
  assert.equal(summarizePath(null), '')
})

test('narrateEdge generates analyst-friendly dynamic relationship comments', () => {
  const edge = {
    source: 'client:C1',
    target: 'counterparty:C2',
    link_type: 'transacted_with',
    count: 7,
    amount: 187500,
    metadata: { incoming_count: 2, outgoing_count: 5 },
  }
  const nodesById = {
    'client:C1': { label: 'Alice Zhang' },
    'counterparty:C2': { label: 'Northport Trading Ltd' },
  }

  const narration = narrateEdge(edge, nodesById)
  assert.match(narration, /Alice Zhang transacted directly Northport Trading Ltd/)
  assert.match(narration, /7 linked transactions/)
  assert.match(narration, /2 incoming \/ 5 outgoing/)
  assert.match(edgeCommentBadge(edge), /7 tx/)
})

test('narratePath and icon hooks are available for rendering', () => {
  const path = {
    nodes: [{ label: 'Alice Zhang' }, { label: 'Alice external account' }, { label: 'Northport Trading Ltd' }],
    hop_count: 2,
    tx_edge_count: 1,
    cumulative_amount: 90200,
  }

  assert.match(narratePath(path), /2 hops/)
  assert.equal(getEntityVisual('counterparty').icon, '🤝')
  assert.equal(withSecondaryId('Northport Trading Ltd', 'C0000022'), 'Northport Trading Ltd (C0000022)')
})

test('deriveDraggedPosition computes pointer-delta movement and clamps to graph bounds', () => {
  const next = deriveDraggedPosition(
    { x: 100, y: 80 },
    { x: 135, y: 120 },
    { x: 110, y: 100 },
  )

  assert.deepEqual(next, { x: 125, y: 100 })

  const clamped = deriveDraggedPosition(
    { x: 20, y: 20 },
    { x: -500, y: -500 },
    { x: 20, y: 20 },
  )
  assert.equal(clamped.x, 14)
  assert.equal(clamped.y, 14)
  assert.deepEqual(clampGraphPosition({ x: 800, y: 999 }), { x: 626, y: 346 })
})

test('buildEdgeTransactionContext maps exact transaction ids from edge metadata', () => {
  const edge = {
    id: 'transacted_with:client:C1->counterparty:C2:0',
    link_type: 'transacted_with',
    first_seen: '2025-01-01T00:00:00',
    last_seen: '2025-02-01T00:00:00',
    metadata: {
      counterparty_id: 'C2',
      direction: 'mixed',
      transaction_ids: ['T-1', 'T-3'],
    },
  }

  const txs = [
    { tx_id: 'T-1', counterparty_id: 'C2', direction: 'incoming', timestamp: '2025-01-05T00:00:00' },
    { tx_id: 'T-2', counterparty_id: 'C2', direction: 'outgoing', timestamp: '2025-01-07T00:00:00' },
    { tx_id: 'T-3', counterparty_id: 'C3', direction: 'incoming', timestamp: '2025-01-09T00:00:00' },
  ]

  const context = buildEdgeTransactionContext(edge, txs)
  assert.ok(context)
  assert.equal(context.counterpartyId, 'C2')
  assert.deepEqual(context.matchedTxIds, ['T-1', 'T-3'])
  assert.equal(context.matchCount, 2)
})

test('buildEdgeTransactionContext falls back to counterparty/time/direction when ids unavailable', () => {
  const edge = {
    id: 'transaction_path:account:C1:primary->account:C2:external:0',
    link_type: 'transaction_path',
    first_seen: '2025-01-01T00:00:00',
    last_seen: '2025-01-31T23:59:59',
    metadata: {
      counterparty_id: 'C2',
      direction: 'incoming',
    },
  }

  const txs = [
    { tx_id: 'T-1', counterparty_id: 'C2', direction: 'incoming', timestamp: '2025-01-02T09:00:00' },
    { tx_id: 'T-2', counterparty_id: 'C2', direction: 'outgoing', timestamp: '2025-01-03T09:00:00' },
    { tx_id: 'T-3', counterparty_id: 'C2', direction: 'incoming', timestamp: '2025-03-03T09:00:00' },
    { tx_id: 'T-4', counterparty_id: 'C9', direction: 'incoming', timestamp: '2025-01-05T09:00:00' },
  ]

  const context = buildEdgeTransactionContext(edge, txs)
  assert.deepEqual(context.matchedTxIds, ['T-1'])
  assert.equal(context.matchCount, 1)

  const noMatch = buildEdgeTransactionContext({ ...edge, metadata: { ...edge.metadata, counterparty_id: 'NOPE' } }, txs)
  assert.equal(noMatch.matchCount, 0)
})

test('layout overrides hydrate/serialize only known nodes and support reset', () => {
  const basePositions = {
    'client:C1': { x: 320, y: 180 },
    'counterparty:C2': { x: 440, y: 180 },
  }

  const key = buildSessionLayoutKey('C1')
  assert.equal(key, 'aml.connections.layout.C1')

  const hydrated = hydrateLayoutOverrides(
    JSON.stringify({
      'client:C1': { x: 40, y: 50 },
      'counterparty:C2': { x: 9000, y: 1000 },
      ghost: { x: 1, y: 1 },
    }),
    basePositions,
  )

  assert.deepEqual(hydrated, {
    'client:C1': { x: 40, y: 50 },
    'counterparty:C2': { x: 626, y: 346 },
  })

  const serialized = serializeLayoutOverrides(
    {
      ...hydrated,
      orphan: { x: 1, y: 2 },
    },
    basePositions,
  )
  assert.deepEqual(serialized, hydrated)

  const reset = serializeLayoutOverrides({}, basePositions)
  assert.deepEqual(reset, {})
})
