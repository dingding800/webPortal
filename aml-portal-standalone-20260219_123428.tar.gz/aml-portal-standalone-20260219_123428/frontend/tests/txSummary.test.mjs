import test from 'node:test'
import assert from 'node:assert/strict'

import { aggregateTransactionsBySummaryCategory } from '../src/txSummary.js'

test('aggregates transactions into requested summary categories', () => {
  const transactions = [
    { tx_type: 'wire' },
    { tx_type: 'emt' },
    { tx_type: 'card', channel: 'online' },
    { tx_type: 'debit', purpose_code: 'grocery' },
    { tx_type: 'credit', purpose_code: 'utilities' },
    { tx_type: 'debit', purpose_code: 'salary', flags: ['recurring'] },
    { tx_type: 'debit', purpose_code: 'government tax', flags: ['recurring'] },
    { tx_type: 'debit', purpose_code: 'loan repayment', flags: ['recurring'] },
    { tx_type: 'cash' },
  ]

  const summary = aggregateTransactionsBySummaryCategory(transactions)
  const counts = Object.fromEntries(summary.rows.map((row) => [row.key, row.count]))

  assert.equal(summary.total, 9)
  assert.equal(summary.categorized, 9)
  assert.equal(summary.uncategorized, 0)
  assert.equal(counts.wire, 1)
  assert.equal(counts.emt, 1)
  assert.equal(counts.online_shopping, 1)
  assert.equal(counts.grocery, 1)
  assert.equal(counts.utilities, 1)
  assert.equal(counts.preauth_salary, 1)
  assert.equal(counts.preauth_government, 1)
  assert.equal(counts.preauth_others, 1)
  assert.equal(counts.other, 1)
})

test('returns empty-safe summary for no transactions', () => {
  const summary = aggregateTransactionsBySummaryCategory([])
  assert.equal(summary.total, 0)
  assert.equal(summary.categorized, 0)
  assert.equal(summary.uncategorized, 0)
  assert.ok(summary.rows.every((row) => row.count === 0 && row.pct === 0))
})
