import axios from 'axios'

const host = typeof window !== 'undefined' ? window.location.hostname : 'localhost'
const api = axios.create({
  baseURL: `http://${host}:8001/api`,
  timeout: 15000,
})

export default api
