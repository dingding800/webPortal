#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

# Build once (or rebuild when source changed) for stable serving
cd "$ROOT/frontend"
if [ ! -d dist ]; then
  npm install
  npm run build
fi

# Serve built static assets on fixed port 5174 (production-like, no dev-server drift)
exec /opt/homebrew/bin/python3 -m http.server 5174 --directory "$ROOT/frontend/dist"
