#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [ -f .env.standalone ]; then
  export $(grep -v '^#' .env.standalone | xargs)
fi

export HOST="${HOST:-127.0.0.1}"
export API_PORT="${API_PORT:-8001}"
export WEB_PORT="${WEB_PORT:-5174}"
export DATABASE_URL="${DATABASE_URL:-sqlite:///./data/aml_portal.db}"
export REDIS_URL="${REDIS_URL:-redis://127.0.0.1:6379/0}"
export RESET_SCHEMA_ON_START="${RESET_SCHEMA_ON_START:-false}"

mkdir -p "$ROOT/data" "$ROOT/logs"

# Use project-local Python if provided, else system python3
PY_BIN="${PY_BIN:-python3}"
if [ -x "$ROOT/runtime/python/bin/python3" ]; then
  PY_BIN="$ROOT/runtime/python/bin/python3"
fi

# Create local venv on first run (inside bundle)
if [ ! -d "$ROOT/.venv" ]; then
  "$PY_BIN" -m venv "$ROOT/.venv"
  "$ROOT/.venv/bin/pip" install --upgrade pip
  "$ROOT/.venv/bin/pip" install -r "$ROOT/backend/requirements.txt"
fi

# Frontend static serving only; no Node required on target
pkill -f "uvicorn app.main:app --host $HOST --port $API_PORT" >/dev/null 2>&1 || true
pkill -f "python -m app.workers.worker" >/dev/null 2>&1 || true
pkill -f "http.server $WEB_PORT --directory $ROOT/frontend/dist" >/dev/null 2>&1 || true

export PYTHONPATH="$ROOT/backend"
nohup "$ROOT/.venv/bin/uvicorn" app.main:app --host "$HOST" --port "$API_PORT" > "$ROOT/logs/backend.log" 2>&1 &
nohup "$ROOT/.venv/bin/python" -m app.workers.worker > "$ROOT/logs/worker.log" 2>&1 &
nohup "$ROOT/.venv/bin/python" -m http.server "$WEB_PORT" --directory "$ROOT/frontend/dist" > "$ROOT/logs/frontend.log" 2>&1 &

echo "Started"
echo "API:  http://$HOST:$API_PORT"
echo "Web:  http://$HOST:$WEB_PORT"
echo "Logs: $ROOT/logs"
