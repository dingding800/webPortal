#!/usr/bin/env bash
set -euo pipefail

BASE=${1:-http://localhost:8001/api}

echo "[1] health"
curl -sf "$BASE/health" | jq .

echo "[2] summary"
curl -sf "$BASE/analytics/summary" | jq .

echo "[3] list clients"
RESP=$(curl -sf "$BASE/clients?page=1&page_size=5")
echo "$RESP" | jq '.items | length'

echo "[4] open one client and validate tabs payload"
CID=$(echo "$RESP" | jq -r '.items[0].client_id')
curl -sf "$BASE/clients/$CID" | jq '.client.client_id, (.history.names|length), (.alerts|length), (.transactions|length)'

echo "[5] outstanding alerts"
curl -sf "$BASE/alerts/outstanding?limit=5" | jq 'length'

echo "Smoke test passed"
