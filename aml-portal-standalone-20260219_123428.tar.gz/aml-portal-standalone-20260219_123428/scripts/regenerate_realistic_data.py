#!/usr/bin/env python3
import argparse
import json
from datetime import datetime

from sqlalchemy import text

from app.db.session import SessionLocal
from app.services.seed_data import bulk_seed

TABLES_TO_CLEAR = [
    'transactions',
    'risk_results',
    'client_name_history',
    'client_address_history',
    'client_phone_history',
    'world_check_hits',
    'case_notes',
    'alerts',
    'cases',
    'risk_decision_logs',
    'login_activity',
    'seed_jobs',
    'clients',
]


def compute_metrics(db):
    sql = text(
        """
        WITH client_dc AS (
          SELECT client_id, SUM(amount) AS dc_total
          FROM transactions
          WHERE tx_type IN ('debit', 'credit')
          GROUP BY client_id
        )
        SELECT
          AVG(dc_total) AS avg_dc_total,
          percentile_cont(0.5) WITHIN GROUP (ORDER BY dc_total) AS p50_dc_total,
          percentile_cont(0.9) WITHIN GROUP (ORDER BY dc_total) AS p90_dc_total,
          percentile_cont(0.99) WITHIN GROUP (ORDER BY dc_total) AS p99_dc_total,
          MAX(dc_total) AS max_dc_total
        FROM client_dc
        """
    )
    row = db.execute(sql).mappings().one()

    counts = db.execute(
        text(
            """
            SELECT
              (SELECT COUNT(*) FROM clients) AS clients,
              (SELECT COUNT(*) FROM transactions) AS transactions,
              (SELECT COUNT(*) FROM cases) AS cases,
              (SELECT COUNT(*) FROM alerts) AS alerts,
              (SELECT COUNT(*) FROM login_activity) AS login_activity,
              (SELECT MIN(timestamp) FROM transactions) AS first_tx,
              (SELECT MAX(timestamp) FROM transactions) AS last_tx
            """
        )
    ).mappings().one()

    out = {**dict(counts), **dict(row)}
    for k, v in list(out.items()):
        if isinstance(v, datetime):
            out[k] = v.isoformat()
        elif isinstance(v, float):
            out[k] = round(v, 2)
    return out


def main():
    parser = argparse.ArgumentParser(description='Regenerate AML realistic dataset')
    parser.add_argument('--clients', type=int, default=3000)
    parser.add_argument('--tx-per-client', type=int, default=64)
    parser.add_argument('--batch-size', type=int, default=300)
    args = parser.parse_args()

    db = SessionLocal()
    try:
        for table in TABLES_TO_CLEAR:
            db.execute(text(f'TRUNCATE TABLE {table} CASCADE'))
        db.commit()

        seeded = bulk_seed(db, clients=args.clients, tx_per_client=args.tx_per_client, batch_size=args.batch_size)
        metrics = compute_metrics(db)
        print(json.dumps({'seeded': seeded, 'metrics': metrics}, indent=2))
    finally:
        db.close()


if __name__ == '__main__':
    main()
