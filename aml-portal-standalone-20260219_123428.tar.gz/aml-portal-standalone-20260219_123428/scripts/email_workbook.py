#!/usr/bin/env python3
import argparse
import smtplib
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path


SMTP_ENV = Path('/Users/dingceliu/.openclaw/credentials/stock-report-smtp.env')


def load_env(path: Path):
    env = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        k, v = line.split('=', 1)
        env[k.strip()] = v.strip().strip('"').strip("'")
    return env


def main():
    parser = argparse.ArgumentParser(description='Send AML workbook by email')
    parser.add_argument('--to', required=True)
    parser.add_argument('--file', required=True)
    parser.add_argument('--subject', default='AML Portal data workbook')
    args = parser.parse_args()

    attachment = Path(args.file)
    if not attachment.exists():
        raise FileNotFoundError(f'Attachment not found: {attachment}')

    smtp = load_env(SMTP_ENV)
    host = smtp.get('SMTP_HOST', 'smtp.gmail.com')
    port = int(smtp.get('SMTP_PORT', '587'))
    user = smtp['SMTP_USER']
    pwd = smtp['SMTP_PASS']

    msg = MIMEMultipart()
    msg['Subject'] = args.subject
    msg['From'] = user
    msg['To'] = args.to
    msg.attach(MIMEText('Attached is the AML portal data workbook for review.', 'plain', 'utf-8'))

    with open(attachment, 'rb') as f:
        part = MIMEApplication(f.read(), Name=attachment.name)
    part['Content-Disposition'] = f'attachment; filename="{attachment.name}"'
    msg.attach(part)

    with smtplib.SMTP(host, port, timeout=60) as s:
        s.starttls()
        s.login(user, pwd)
        s.sendmail(user, [args.to], msg.as_string())

    print(f'EMAIL_SENT to={args.to} file={attachment} host={host}:{port}')


if __name__ == '__main__':
    main()
