#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate
export DATABASE_URL='postgresql+psycopg://aml:aml@localhost:5432/aml_portal'
export REDIS_URL='redis://localhost:6379/0'
export PYTHONPATH="$ROOT/backend"
export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES
exec python -m app.workers.worker
