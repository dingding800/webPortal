#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

if [ -f .env.standalone ]; then
  export $(grep -v '^#' .env.standalone | xargs)
fi
HOST="${HOST:-127.0.0.1}"
API_PORT="${API_PORT:-8001}"
WEB_PORT="${WEB_PORT:-5174}"

pkill -f "uvicorn app.main:app --host $HOST --port $API_PORT" >/dev/null 2>&1 || true
pkill -f "python -m app.workers.worker" >/dev/null 2>&1 || true
pkill -f "http.server $WEB_PORT --directory $ROOT/frontend/dist" >/dev/null 2>&1 || true

echo "Stopped"
