export const GRAPH_VIEWBOX = { width: 640, height: 360 }

const ENTITY_VISUALS = {
  client: { icon: '👤', typeLabel: 'Client' },
  entity: { icon: '🏢', typeLabel: 'Entity' },
  counterparty: { icon: '🤝', typeLabel: 'Counterparty' },
  account: { icon: '💳', typeLabel: 'Account' },
  address: { icon: '📍', typeLabel: 'Address' },
  phone: { icon: '📞', typeLabel: 'Phone' },
  profile: { icon: '🪪', typeLabel: 'Profile' },
}

const LINK_TYPE_LABELS = {
  owns_account: 'owns account',
  transaction_path: 'funds flowed through linked accounts',
  transacted_with: 'transacted directly',
  address_association: 'address linked',
  phone_association: 'phone linked',
  profile_attribute: 'profile attribute linked',
}

const TRANSACTION_EDGE_TYPES = new Set(['transacted_with', 'transaction_path'])

const moneyCompact = (amount) => {
  const value = Number(amount || 0)
  if (!value) return '$0'
  return `$${value.toLocaleString(undefined, { notation: 'compact', maximumFractionDigits: 1 })}`
}

export function getEntityVisual(entityType) {
  return ENTITY_VISUALS[entityType] || { icon: '🔗', typeLabel: entityType || 'Entity' }
}

export function withSecondaryId(label, entityId) {
  if (!entityId || label === entityId) return label
  return `${label} (${entityId})`
}

export function buildGraphModel(data, maxNodes = 26, maxEdges = 70) {
  const nodes = data?.nodes || []
  const edges = data?.edges || []
  const sortedNodes = [...nodes]
    .sort((a, b) => (Number(b.importance || 0) - Number(a.importance || 0)))
    .slice(0, maxNodes)

  const included = new Set(sortedNodes.map((n) => n.id))
  const graphEdges = edges.filter((e) => included.has(e.source) && included.has(e.target)).slice(0, maxEdges)
  const center = sortedNodes.find((n) => n.entity_type === 'client') || sortedNodes[0] || null
  const outerNodes = sortedNodes.filter((n) => n.id !== center?.id)

  const positions = {}
  if (center) positions[center.id] = { x: 320, y: 180 }
  outerNodes.forEach((n, idx) => {
    const ring = idx < 12 ? 0 : 1
    const ringIdx = ring === 0 ? idx : idx - 12
    const ringCount = ring === 0 ? Math.min(12, outerNodes.length) : Math.max(1, outerNodes.length - 12)
    const radius = ring === 0 ? 115 : 165
    const angle = (Math.PI * 2 * ringIdx) / ringCount
    positions[n.id] = { x: 320 + Math.cos(angle) * radius, y: 180 + Math.sin(angle) * radius }
  })

  return { sortedNodes, graphEdges, positions, center }
}

export function clampGraphPosition(point, margin = 14, viewbox = GRAPH_VIEWBOX) {
  const x = Number(point?.x)
  const y = Number(point?.y)
  const fallbackX = viewbox.width / 2
  const fallbackY = viewbox.height / 2
  return {
    x: Math.max(margin, Math.min(viewbox.width - margin, Number.isFinite(x) ? x : fallbackX)),
    y: Math.max(margin, Math.min(viewbox.height - margin, Number.isFinite(y) ? y : fallbackY)),
  }
}

export function deriveDraggedPosition(startPosition, pointerPoint, pointerDownPoint, viewbox = GRAPH_VIEWBOX) {
  if (!startPosition || !pointerPoint || !pointerDownPoint) return startPosition
  const next = {
    x: Number(startPosition.x || 0) + (Number(pointerPoint.x || 0) - Number(pointerDownPoint.x || 0)),
    y: Number(startPosition.y || 0) + (Number(pointerPoint.y || 0) - Number(pointerDownPoint.y || 0)),
  }
  return clampGraphPosition(next, 14, viewbox)
}

export function buildSessionLayoutKey(clientId) {
  if (!clientId) return null
  return `aml.connections.layout.${clientId}`
}

export function serializeLayoutOverrides(overrides = {}, basePositions = {}) {
  const out = {}
  for (const [id, point] of Object.entries(overrides || {})) {
    if (!point || !basePositions[id]) continue
    out[id] = {
      x: Number(point.x),
      y: Number(point.y),
    }
  }
  return out
}

export function hydrateLayoutOverrides(rawValue, basePositions = {}) {
  if (!rawValue) return {}
  let parsed
  try {
    parsed = typeof rawValue === 'string' ? JSON.parse(rawValue) : rawValue
  } catch {
    return {}
  }

  if (!parsed || typeof parsed !== 'object') return {}

  const out = {}
  for (const [id, point] of Object.entries(parsed)) {
    if (!basePositions[id] || !point) continue
    out[id] = clampGraphPosition({ x: Number(point.x), y: Number(point.y) })
  }
  return out
}

export function summarizePath(path) {
  if (!path) return ''
  const labels = (path.nodes || []).map((n) => n.label).filter(Boolean)
  return labels.join(' → ')
}

export function isTransactionEdge(edge) {
  return Boolean(edge && TRANSACTION_EDGE_TYPES.has(edge.link_type))
}

const toTimestamp = (value) => {
  if (!value) return Number.NaN
  const ms = Date.parse(value)
  return Number.isFinite(ms) ? ms : Number.NaN
}

export function buildEdgeTransactionContext(edge, transactions = []) {
  if (!isTransactionEdge(edge)) return null

  const metadata = edge.metadata || {}
  const rawTxIds = Array.isArray(metadata.transaction_ids) ? metadata.transaction_ids : []
  const txIds = [...new Set(rawTxIds.map((id) => String(id)).filter(Boolean))]
  const txIdSet = new Set(txIds)

  const counterpartyId = metadata.counterparty_id || metadata.counterpartyId || null
  const direction = String(metadata.direction || 'any').toLowerCase()
  const firstSeen = edge.first_seen || metadata.time_start || null
  const lastSeen = edge.last_seen || metadata.time_end || null
  const startMs = toTimestamp(firstSeen)
  const endMs = toTimestamp(lastSeen)

  const matchedTxIds = []
  for (const tx of transactions || []) {
    const txId = String(tx?.tx_id || '')
    if (!txId) continue

    let matched = false
    if (txIdSet.size) {
      matched = txIdSet.has(txId)
    } else {
      matched = true
      if (counterpartyId && tx.counterparty_id !== counterpartyId) matched = false

      const ts = toTimestamp(tx.timestamp)
      if (matched && Number.isFinite(startMs) && Number.isFinite(ts) && ts < startMs) matched = false
      if (matched && Number.isFinite(endMs) && Number.isFinite(ts) && ts > endMs) matched = false

      if (matched && direction !== 'any' && direction !== 'mixed' && tx.direction !== direction) matched = false
    }

    if (matched) matchedTxIds.push(txId)
  }

  const dedupedMatches = [...new Set(matchedTxIds)]

  return {
    edgeId: edge.id,
    linkType: edge.link_type,
    counterpartyId,
    direction,
    firstSeen,
    lastSeen,
    reason: edge.reason || '',
    transactionIds: txIds,
    matchedTxIds: dedupedMatches,
    matchCount: dedupedMatches.length,
  }
}

export function narrateEdge(edge, nodesById = {}) {
  if (!edge) return ''
  const src = nodesById?.[edge.source]?.label || edge.source
  const dst = nodesById?.[edge.target]?.label || edge.target
  const linkLabel = LINK_TYPE_LABELS[edge.link_type] || (edge.link_type || 'linked').replaceAll('_', ' ')

  if (isTransactionEdge(edge)) {
    const txCount = Number(edge.count || 0)
    const amountText = moneyCompact(edge.amount)
    const incoming = Number(edge.metadata?.incoming_count || 0)
    const outgoing = Number(edge.metadata?.outgoing_count || 0)
    return `${src} ${linkLabel} ${dst}: ${txCount} linked transactions (${incoming} incoming / ${outgoing} outgoing), total ${amountText}.`
  }

  return `${src} ${linkLabel} ${dst}. ${edge.reason || ''}`.trim()
}

export function edgeCommentBadge(edge) {
  if (!edge) return ''
  if (isTransactionEdge(edge)) {
    return `${edge.count || 0} tx • ${moneyCompact(edge.amount)}`
  }
  return LINK_TYPE_LABELS[edge.link_type] || (edge.link_type || '').replaceAll('_', ' ')
}

export function narratePath(path) {
  if (!path) return ''
  const chain = summarizePath(path)
  const hops = Number(path.hop_count || 0)
  const txEdges = Number(path.tx_edge_count || 0)
  const amount = moneyCompact(path.cumulative_amount)
  return `${chain}. ${hops} hops across ${txEdges} transactional links with cumulative exposure of ${amount}.`
}
