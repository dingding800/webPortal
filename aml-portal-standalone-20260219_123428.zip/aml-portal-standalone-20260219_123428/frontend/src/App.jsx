import { useEffect, useMemo, useRef, useState } from 'react'
import api from './api/client'
import {
  buildEdgeTransactionContext,
  buildGraphModel,
  buildSessionLayoutKey,
  deriveDraggedPosition,
  edgeCommentBadge,
  getEntityVisual,
  GRAPH_VIEWBOX,
  hydrateLayoutOverrides,
  narrateEdge,
  narratePath,
  serializeLayoutOverrides,
  summarizePath,
  withSecondaryId,
} from './connections'
import { aggregateTransactionsBySummaryCategory } from './txSummary'

const SEGMENT_ALL = 'all'
const RATING_ALL = 'all'
const TABS = ['Demographics', 'Client History', 'Transactions', 'Login Activity', 'Connections', 'Evidence & Workflow']
const SAMPLE_SEED = { clients: 6000, tx_per_client: 60, batch_size: 600 }
const TABLEAU_COLORS = ['#4E79A7', '#F28E2B', '#E15759', '#76B7B2', '#59A14F', '#EDC948', '#B07AA1', '#FF9DA7', '#9C755F', '#BAB0AC']

const fmtMoney = (v) => `$${Number(v || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}`
const riskColor = (risk) => ({ low: '#38a169', medium: '#d69e2e', high: '#e53e3e' }[risk] || '#718096')
const txBadgeClass = (tx) => `${tx.tx_type} ${tx.direction}`
const REGION_NAMES = typeof Intl !== 'undefined' && Intl.DisplayNames ? new Intl.DisplayNames(['en'], { type: 'region' }) : null
const countryLabel = (row) => row?.country_name || row?.ip_country_name || (row?.country ? (REGION_NAMES?.of(row.country) || row.country) : '')

function CountryPie({ rows = [], title, directionKey, onPickCountry }) {
  const top = rows
    .map((r) => ({ ...r, value: Number(r?.[directionKey] || 0), label: countryLabel(r) }))
    .filter((r) => r.value > 0)
    .sort((a, b) => b.value - a.value)
    .slice(0, 8)

  const total = top.reduce((a, r) => a + r.value, 0)
  let cursor = 0
  const stops = top.map((r, i) => {
    const pct = total > 0 ? (r.value / total) * 100 : 0
    const start = cursor
    cursor += pct
    return { ...r, color: TABLEAU_COLORS[i % TABLEAU_COLORS.length], start, end: cursor, pct: Number(pct.toFixed(2)) }
  })

  return (
    <div>
      <h4>{title}</h4>
      <div className='pie-wrap'>
        <div
          className='pie'
          style={{
            background: `conic-gradient(${stops.map((s) => `${s.color} ${s.start}% ${s.end}%`).join(', ') || '#edf2f7 0% 100%'})`,
            boxShadow: stops.some((s) => s.risk_tier === 'high') ? '0 0 0 3px #e53e3e inset' : undefined,
          }}
        />
        <div className='legend'>
          {stops.map((s) => (
            <button key={`${directionKey}-${s.country}`} className='legend-row legend-btn' onClick={() => onPickCountry?.(s.country)}>
              <span className='dot' style={{ background: s.color, outline: s.risk_tier === 'high' ? '2px solid #e53e3e' : 'none' }} />
              <small>{s.label} • {s.pct}% {s.risk_tier === 'high' ? '⚠ high risk' : ''}</small>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

function CountryDirectionPies({ rows = [], onPickCountry }) {
  return (
    <div className='two-col'>
      <CountryPie rows={rows} title='Incoming wires by country' directionKey='inbound' onPickCountry={onPickCountry} />
      <CountryPie rows={rows} title='Outgoing wires by country' directionKey='outbound' onPickCountry={onPickCountry} />
    </div>
  )
}

function TransactionTypeSummaryPie({ transactions = [] }) {
  const summary = aggregateTransactionsBySummaryCategory(transactions)
  const slices = summary.rows.filter((row) => row.count > 0)
  let cursor = 0
  const gradientStops = slices.map((row, i) => {
    const start = cursor
    cursor += row.pct
    return {
      ...row,
      color: TABLEAU_COLORS[i % TABLEAU_COLORS.length],
      start,
      end: cursor,
    }
  })

  return (
    <div className='card tx-type-summary' aria-label='Transaction type summary'>
      <h4>Overall transaction type composition</h4>
      <p className='muted'>Aggregated over currently visible transactions in this tab ({summary.total}).</p>
      <div className='pie-wrap'>
        <div
          className='pie'
          aria-label='Transaction summary pie chart'
          style={{
            background: `conic-gradient(${gradientStops.map((s) => `${s.color} ${s.start}% ${s.end}%`).join(', ') || '#edf2f7 0% 100%'})`,
          }}
        />
        <div className='legend tx-summary-legend'>
          {summary.rows.map((row, i) => (
            <div key={row.key} className='legend-row'>
              <span className='dot' style={{ background: row.count > 0 ? TABLEAU_COLORS[i % TABLEAU_COLORS.length] : '#cbd5e0' }} />
              <small>{row.label} • {row.pct}% ({row.count})</small>
            </div>
          ))}
        </div>
      </div>
      {summary.total === 0 && <p className='muted'>No transactions available for summary.</p>}
    </div>
  )
}

const ENTITY_COLORS = {
  client: '#2b6cb0',
  counterparty: '#805ad5',
  address: '#2f855a',
  phone: '#d69e2e',
  profile: '#4a5568',
  account: '#0f766e',
}

const titleCase = (v = '') => (v ? `${v[0].toUpperCase()}${v.slice(1)}` : '')

const renderEntityName = (row) => withSecondaryId(row?.label || row?.counterparty_name || row?.entity_id || row?.counterparty_id || '-', row?.entity_id || row?.counterparty_id)

function ConnectionsGraph({ data, clientId, onPickEvidence }) {
  const { sortedNodes, graphEdges, positions: basePositions } = useMemo(() => buildGraphModel(data), [data])
  const [layoutOverrides, setLayoutOverrides] = useState({})
  const [draggingNodeId, setDraggingNodeId] = useState(null)
  const svgRef = useRef(null)
  const dragStateRef = useRef(null)
  const suppressClickRef = useRef(false)
  const rafStateRef = useRef({ id: null, nodeId: null, point: null })
  const storageKey = useMemo(() => buildSessionLayoutKey(clientId), [clientId])

  const positions = useMemo(() => ({ ...basePositions, ...layoutOverrides }), [basePositions, layoutOverrides])

  useEffect(() => {
    setLayoutOverrides((current) => {
      const next = serializeLayoutOverrides(current, basePositions)
      const changed = Object.keys(next).length !== Object.keys(current || {}).length
        || Object.entries(next).some(([id, p]) => !current?.[id] || current[id].x !== p.x || current[id].y !== p.y)
      return changed ? next : current
    })
  }, [basePositions])

  useEffect(() => {
    if (!storageKey || typeof window === 'undefined') {
      setLayoutOverrides({})
      return
    }
    const raw = window.sessionStorage.getItem(storageKey)
    setLayoutOverrides(hydrateLayoutOverrides(raw, basePositions))
  }, [storageKey, basePositions])

  useEffect(() => {
    if (!storageKey || typeof window === 'undefined') return
    if (!Object.keys(layoutOverrides).length) {
      window.sessionStorage.removeItem(storageKey)
      return
    }
    window.sessionStorage.setItem(storageKey, JSON.stringify(serializeLayoutOverrides(layoutOverrides, basePositions)))
  }, [layoutOverrides, storageKey, basePositions])

  useEffect(() => {
    return () => {
      if (rafStateRef.current.id) window.cancelAnimationFrame(rafStateRef.current.id)
    }
  }, [])

  const toSvgPoint = (event) => {
    const rect = svgRef.current?.getBoundingClientRect()
    if (!rect || !rect.width || !rect.height) return null
    return {
      x: ((event.clientX - rect.left) / rect.width) * GRAPH_VIEWBOX.width,
      y: ((event.clientY - rect.top) / rect.height) * GRAPH_VIEWBOX.height,
    }
  }

  const queueNodeMove = (nodeId, point) => {
    rafStateRef.current.nodeId = nodeId
    rafStateRef.current.point = point
    if (rafStateRef.current.id) return
    rafStateRef.current.id = window.requestAnimationFrame(() => {
      const queuedNodeId = rafStateRef.current.nodeId
      const queuedPoint = rafStateRef.current.point
      rafStateRef.current.id = null
      if (!queuedNodeId || !queuedPoint) return
      setLayoutOverrides((current) => ({ ...current, [queuedNodeId]: queuedPoint }))
    })
  }

  const onNodePointerDown = (event, nodeId) => {
    if (event.button != null && event.button !== 0) return
    const pointerPoint = toSvgPoint(event)
    const startPosition = positions[nodeId]
    if (!pointerPoint || !startPosition) return

    event.preventDefault()
    dragStateRef.current = {
      pointerId: event.pointerId,
      nodeId,
      pointerDownPoint: pointerPoint,
      startPosition,
      moved: false,
    }
    setDraggingNodeId(nodeId)
    event.currentTarget.setPointerCapture?.(event.pointerId)
  }

  const onGraphPointerMove = (event) => {
    const drag = dragStateRef.current
    if (!drag || drag.pointerId !== event.pointerId) return
    const pointerPoint = toSvgPoint(event)
    if (!pointerPoint) return
    const nextPoint = deriveDraggedPosition(drag.startPosition, pointerPoint, drag.pointerDownPoint)
    const movedDistance = Math.abs(nextPoint.x - drag.startPosition.x) + Math.abs(nextPoint.y - drag.startPosition.y)
    drag.moved = drag.moved || movedDistance > 2
    queueNodeMove(drag.nodeId, nextPoint)
  }

  const endDrag = (event) => {
    const drag = dragStateRef.current
    if (!drag || drag.pointerId !== event.pointerId) return
    if (drag.moved) suppressClickRef.current = true
    dragStateRef.current = null
    setDraggingNodeId(null)
  }

  const onNodeClick = (node) => {
    if (suppressClickRef.current) {
      suppressClickRef.current = false
      return
    }
    onPickEvidence?.({ kind: 'node', payload: node })
  }

  const hasCustomLayout = Object.keys(layoutOverrides).length > 0

  return (
    <div className='connections-graph-wrap' data-testid='connections-graph'>
      <div className='connections-graph-toolbar'>
        <small className='muted'>Tip: drag nodes to rearrange graph during review.</small>
        <button disabled={!hasCustomLayout} onClick={() => setLayoutOverrides({})}>Reset to auto-layout</button>
      </div>

      <svg
        ref={svgRef}
        viewBox='0 0 640 360'
        className='connections-graph'
        onPointerMove={onGraphPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
      >
        <defs>
          <marker id='graph-arrow' viewBox='0 0 10 10' refX='8' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'>
            <path d='M 0 0 L 10 5 L 0 10 z' fill='#a0aec0' />
          </marker>
        </defs>

        {graphEdges.map((e) => {
          const p1 = positions[e.source]
          const p2 = positions[e.target]
          if (!p1 || !p2) return null
          const amountWidth = Math.min(6, 1 + Number(e.amount || 0) / 250000)
          const midX = (p1.x + p2.x) / 2
          const midY = (p1.y + p2.y) / 2
          return (
            <g key={e.id}>
              <line
                x1={p1.x}
                y1={p1.y}
                x2={p2.x}
                y2={p2.y}
                stroke='#a0aec0'
                strokeWidth={amountWidth}
                strokeLinecap='round'
                markerEnd='url(#graph-arrow)'
                className='graph-edge'
                onClick={() => onPickEvidence?.({ kind: 'edge', payload: e })}
              />
              <text
                x={midX}
                y={midY - 4}
                textAnchor='middle'
                className='graph-edge-comment'
                onClick={() => onPickEvidence?.({ kind: 'edge', payload: e })}
              >
                {edgeCommentBadge(e)}
              </text>
            </g>
          )
        })}

        {sortedNodes.map((n) => {
          const p = positions[n.id]
          if (!p) return null
          const radius = n.entity_type === 'client' ? 13 : 9
          const visual = getEntityVisual(n.entity_type)
          return (
            <g
              key={n.id}
              onClick={() => onNodeClick(n)}
              onPointerDown={(event) => onNodePointerDown(event, n.id)}
              className={`graph-node ${draggingNodeId === n.id ? 'dragging' : ''}`}
            >
              <circle cx={p.x} cy={p.y} r={radius} fill={ENTITY_COLORS[n.entity_type] || '#718096'} />
              <text x={p.x} y={p.y + 3} textAnchor='middle' className='graph-node-icon'>{visual.icon}</text>
              <text x={p.x} y={p.y + (n.entity_type === 'client' ? 26 : 19)} textAnchor='middle' className='graph-node-label'>
                {renderEntityName(n)}
              </text>
            </g>
          )
        })}
      </svg>
    </div>
  )
}

export default function App() {
  const [summary, setSummary] = useState(null)
  const [segments, setSegments] = useState([])
  const [clients, setClients] = useState([])
  const [alertsQueue, setAlertsQueue] = useState([])
  const [clientMeta, setClientMeta] = useState({ page: 1, pages: 1, total: 0 })

  const [q, setQ] = useState('')
  const [segment, setSegment] = useState(SEGMENT_ALL)
  const [riskRating, setRiskRating] = useState(RATING_ALL)
  const [minRisk, setMinRisk] = useState(0)
  const [sortBy, setSortBy] = useState('risk_score')
  const [sortDir, setSortDir] = useState('desc')
  const [page, setPage] = useState(1)

  const [selected, setSelected] = useState(null)
  const [countryFlow, setCountryFlow] = useState(null)
  const [txFeatures, setTxFeatures] = useState(null)
  const [tab, setTab] = useState(TABS[0])
  const [cpFilter, setCpFilter] = useState(null)
  const [countryFilter, setCountryFilter] = useState(null)
  const [txPage, setTxPage] = useState(1)
  const [txPageSize, setTxPageSize] = useState(100)
  const [decisionReason, setDecisionReason] = useState('')
  const [caseReason, setCaseReason] = useState('')
  const [error, setError] = useState('')
  const [loginActivity, setLoginActivity] = useState({ records: [], total: 0 })
  const [loginFilters, setLoginFilters] = useState({ from: '', to: '', country: '' })
  const [connectionsData, setConnectionsData] = useState(null)
  const [connectionPath, setConnectionPath] = useState(null)
  const [pathCounterparty, setPathCounterparty] = useState('')
  const [evidenceSelection, setEvidenceSelection] = useState(null)
  const [edgeTxContext, setEdgeTxContext] = useState(null)
  const [showOnlyEdgeMatches, setShowOnlyEdgeMatches] = useState(false)

  const loadDashboard = async () => {
    const [s, segs, oq] = await Promise.all([
      api.get('/analytics/summary'),
      api.get('/analytics/segments'),
      api.get('/alerts/outstanding?limit=20'),
    ])
    setSummary(s.data)
    setSegments(segs.data)
    setAlertsQueue(oq.data)
  }

  const loadClients = async (targetPage = 1) => {
    const res = await api.get('/clients', {
      params: {
        q: q || undefined,
        segment: segment === SEGMENT_ALL ? undefined : segment,
        risk_rating: riskRating === RATING_ALL ? undefined : riskRating,
        min_risk: minRisk,
        sort_by: sortBy,
        sort_dir: sortDir,
        page: targetPage,
        page_size: 20,
      },
    })
    setClients(res.data.items)
    setClientMeta(res.data)
    setPage(res.data.page)
  }

  const loadLoginActivity = async (clientId, filters = loginFilters) => {
    const params = {
      from_date: filters.from || undefined,
      to_date: filters.to || undefined,
      ip_country: filters.country || undefined,
      limit: 1200,
    }
    const res = await api.get(`/clients/${clientId}/login-activity`, { params })
    setLoginActivity(res.data)
  }

  const openClient = async (id) => {
    const defaultFilters = { from: '', to: '', country: '' }
    setLoginFilters(defaultFilters)
    const [detail, flow, features, logins, connections] = await Promise.all([
      api.get(`/clients/${id}`),
      api.get(`/analytics/country-flow/${id}`),
      api.get(`/analytics/transaction-features/${id}`),
      api.get(`/clients/${id}/login-activity`, { params: { limit: 1200 } }),
      api.get(`/clients/${id}/connections`),
    ])
    setSelected(detail.data)
    setCountryFlow(flow.data)
    setTxFeatures(features.data)
    setLoginActivity(logins.data)
    setConnectionsData(connections.data)
    setConnectionPath(null)
    setPathCounterparty('')
    setEvidenceSelection(null)
    clearEdgeTxContext()
    setTab(TABS[0])
    setCpFilter(null)
    setCountryFilter(null)
    setTxPage(1)
  }

  const queueSeed = async () => {
    await api.post('/seed', SAMPLE_SEED)
    setTimeout(loadDashboard, 1000)
  }

  const submitDecision = async (action) => {
    if (!selected || !decisionReason.trim()) return
    await api.post(`/clients/${selected.client.client_id}/risk-decision`, {
      action,
      reason: decisionReason,
    })
    setDecisionReason('')
    await openClient(selected.client.client_id)
  }

  const updateCaseStatus = async (caseId, status) => {
    if (!selected || !caseReason.trim()) return
    await api.post(`/cases/${caseId}/status`, { status, reason: caseReason })
    setCaseReason('')
    await openClient(selected.client.client_id)
  }

  const downloadForClient = (path, filename) => {
    if (!selected) return
    const a = document.createElement('a')
    a.href = `${api.defaults.baseURL}/clients/${selected.client.client_id}/export/${path}`
    a.download = filename
    document.body.appendChild(a)
    a.click()
    a.remove()
  }

  const traceConnectionPath = async (counterpartyId) => {
    if (!selected || !counterpartyId) return
    const res = await api.get(`/clients/${selected.client.client_id}/connections/path/${counterpartyId}`)
    setConnectionPath(res.data.path)
    setEvidenceSelection({
      kind: 'path',
      payload: {
        counterpartyId,
        counterpartyName: res.data.counterparty_name,
        ...res.data.path,
      },
    })
  }

  const clearEdgeTxContext = () => {
    setEdgeTxContext(null)
    setShowOnlyEdgeMatches(false)
  }

  const handleEvidenceSelection = (selection) => {
    setEvidenceSelection(selection)
    if (selection?.kind === 'edge') {
      const context = buildEdgeTransactionContext(selection.payload, selected?.transactions || [])
      setEdgeTxContext(context)
      setShowOnlyEdgeMatches(false)
    }
  }

  useEffect(() => {
    ;(async () => {
      try {
        await loadDashboard()
        await loadClients(1)
      } catch (e) {
        setError(e?.response?.data?.detail || e.message)
      }
    })()
  }, [])

  const counterparties = useMemo(() => {
    if (!selected) return []
    const map = new Map()
    for (const t of selected.transactions) {
      const key = t.counterparty_id
      if (!map.has(key)) {
        map.set(key, {
          counterparty_id: key,
          name: t.counterparty_name || key,
          country: t.country,
          country_name: t.country_name,
          tx_count: 0,
          total_amount: 0,
        })
      }
      const row = map.get(key)
      row.tx_count += 1
      row.total_amount += Number(t.amount)
    }
    return [...map.values()].sort((a, b) => b.total_amount - a.total_amount)
  }, [selected])

  const connectionCounterparties = useMemo(() => {
    return (connectionsData?.linked_entities || []).filter((e) => e.entity_type === 'counterparty').slice(0, 200)
  }, [connectionsData])

  const counterpartyNameById = useMemo(() => {
    const out = {}
    for (const t of selected?.transactions || []) {
      if (t.counterparty_id) out[t.counterparty_id] = t.counterparty_name || t.counterparty_id
    }
    for (const row of connectionsData?.linked_entities || []) {
      if (row.entity_type === 'counterparty') out[row.entity_id] = row.label || out[row.entity_id] || row.entity_id
    }
    return out
  }, [selected, connectionsData])

  const highlightedTxIds = useMemo(() => new Set((edgeTxContext?.matchedTxIds || []).map((id) => String(id))), [edgeTxContext])

  const filteredTx = useMemo(() => {
    if (!selected) return []
    const base = selected.transactions
    return base.filter((t) => {
      if (cpFilter && t.counterparty_id !== cpFilter) return false
      if (countryFilter && t.country !== countryFilter) return false
      if (showOnlyEdgeMatches && edgeTxContext && !highlightedTxIds.has(String(t.tx_id))) return false
      return true
    })
  }, [selected, cpFilter, countryFilter, showOnlyEdgeMatches, edgeTxContext, highlightedTxIds])

  const pagedTx = useMemo(() => {
    const start = (txPage - 1) * txPageSize
    return filteredTx.slice(start, start + txPageSize)
  }, [filteredTx, txPage, txPageSize])

  const txPages = Math.max(1, Math.ceil(filteredTx.length / txPageSize))

  useEffect(() => {
    setTxPage(1)
  }, [cpFilter, countryFilter, txPageSize, showOnlyEdgeMatches, edgeTxContext?.edgeId, selected?.client?.client_id])

  const flagCards = useMemo(() => {
    if (!selected || !countryFlow || !txFeatures) return []
    const highRiskCountries = (countryFlow.countries || []).filter((c) => c.risk_tier === 'high' && (c.inbound > 0 || c.outbound > 0))
    const highRiskExposure = highRiskCountries.reduce((sum, c) => sum + Number(c.total || 0), 0)
    const totalWire = Number(countryFlow?.totals?.wire_total || 0)
    const highRiskRatio = totalWire > 0 ? (highRiskExposure / totalWire) * 100 : 0

    const totalTx = Number(txFeatures.total_transactions || 0)
    const velocitySignal = Number(txFeatures.suspicious_ratios_pct?.recurring || 0) + Number(txFeatures.suspicious_ratios_pct?.night || 0)

    return [
      {
        title: 'High wire from/to high-risk countries',
        severity: highRiskRatio >= 25 ? 'High' : highRiskRatio >= 10 ? 'Medium' : 'Low',
        text: highRiskCountries.length
          ? `${highRiskCountries.length} high-risk country corridors detected. ${highRiskRatio.toFixed(1)}% of wire value touches high-risk jurisdictions.`
          : 'No meaningful high-risk corridor exposure observed in current wire history.',
      },
      {
        title: 'PEP related',
        severity: selected.client.pep_flag || (selected.world_check_hits || []).some((h) => h.category === 'pep') ? 'High' : 'Low',
        text: selected.client.pep_flag
          ? 'Client is marked PEP; enhanced due diligence and source-of-funds validation are recommended.'
          : (selected.world_check_hits || []).some((h) => h.category === 'pep')
            ? 'PEP-related watchlist hit exists. Validate match quality and beneficial ownership context.'
            : 'No direct PEP marker currently present in profile/watchlist records.',
      },
      {
        title: 'High txn volume / velocity',
        severity: totalTx >= 120 || velocitySignal >= 40 ? 'High' : totalTx >= 60 || velocitySignal >= 25 ? 'Medium' : 'Low',
        text: `${totalTx} recent transactions analyzed. Recurring+night activity composite signal at ${velocitySignal.toFixed(1)}%.`,
      },
      {
        title: 'High-risk profile signals',
        severity: selected.client.sanctions_flag || selected.client.risk_rating.startsWith('High') ? 'High' : selected.client.risk_rating === 'Medium' ? 'Medium' : 'Low',
        text: `Risk rating ${selected.client.risk_rating}. Segment: ${selected.client.segment}. Sanctions flag: ${selected.client.sanctions_flag ? 'Yes' : 'No'}.`,
      },
    ]
  }, [selected, countryFlow, txFeatures])

  return (
    <div className='app'>
      <header className='topbar'>
        <div>
          <h1>AML Portal</h1>
          <p>Client risk review workspace</p>
        </div>
        <div className='top-actions'>
          <button onClick={queueSeed}>Queue Seed</button>
          <button onClick={() => { loadDashboard(); loadClients(page) }}>Refresh</button>
        </div>
      </header>

      {error && <div className='error'>{error}</div>}

      {summary && (
        <section className='summary-grid'>
          <div className='mini-kpi'><span>Total clients</span><b>{summary.clients?.toLocaleString?.() || summary.clients}</b></div>
          <div className='mini-kpi'><span>Transactions</span><b>{summary.transactions?.toLocaleString?.() || summary.transactions}</b></div>
          <div className='mini-kpi'><span>High-risk clients</span><b>{summary.high_risk?.toLocaleString?.() || summary.high_risk}</b></div>
          <div className='mini-kpi'><span>Open alerts</span><b>{summary.open_alerts?.toLocaleString?.() || summary.open_alerts}</b></div>
        </section>
      )}

      <section className='layout'>
        <aside className='left'>
          <div className='card'>
            <h3>Filters</h3>
            <input placeholder='Search name/client/city' value={q} onChange={(e) => setQ(e.target.value)} />
            <select value={segment} onChange={(e) => setSegment(e.target.value)}>
              <option value={SEGMENT_ALL}>All segments</option>
              {segments.map((s) => <option key={s.segment} value={s.segment}>{s.segment} ({s.count})</option>)}
            </select>
            <select value={riskRating} onChange={(e) => setRiskRating(e.target.value)}>
              <option value={RATING_ALL}>All risk ratings</option>
              {['Standard', 'Medium', 'High1', 'High2', 'High3'].map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
            <input type='number' value={minRisk} onChange={(e) => setMinRisk(Number(e.target.value || 0))} />
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
              <option value='risk_score'>Sort: Risk score</option>
              <option value='full_name'>Sort: Name</option>
              <option value='annual_income'>Sort: Annual income</option>
              <option value='city'>Sort: City</option>
              <option value='risk_rating'>Sort: Risk rating</option>
            </select>
            <select value={sortDir} onChange={(e) => setSortDir(e.target.value)}>
              <option value='desc'>Descending</option>
              <option value='asc'>Ascending</option>
            </select>
            <button onClick={() => loadClients(1)}>Apply</button>
          </div>

          <div className='card'>
            <h3>Clients</h3>
            <div className='client-list'>
              {clients.map((c) => (
                <button key={c.client_id} className='client-item' onClick={() => openClient(c.client_id)}>
                  <div className='client-item-head'>
                    <b>{c.full_name}</b>
                    <span className={`pill ${c.risk_rating}`}>{c.risk_rating}</span>
                  </div>
                  <small>{c.client_id} • {c.segment}</small>
                </button>
              ))}
            </div>
            <div className='pager'>
              <button disabled={page <= 1} onClick={() => loadClients(page - 1)}>Prev</button>
              <span>{clientMeta.page}/{clientMeta.pages}</span>
              <button disabled={page >= clientMeta.pages} onClick={() => loadClients(page + 1)}>Next</button>
            </div>
          </div>

          <div className='card'>
            <h3>Outstanding alerts queue</h3>
            <ul className='compact-list'>
              {alertsQueue.slice(0, 8).map((a) => (
                <li key={a.alert_id}>
                  <button
                    className='link-btn'
                    onClick={() => openClient(a.client_id)}
                    title='Open linked client detail'
                  >
                    {a.severity} • {a.client_id} • {a.status}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        <section className='detail card'>
          {!selected ? <p>Select a client to open the detail panel.</p> : (
            <>
              <div className='detail-header'>
                <div>
                  <h2>{selected.client.full_name} <small>({selected.client.client_id})</small></h2>
                  <p>{selected.client.city}, {countryLabel(selected.client)} • {selected.client.segment} • {fmtMoney(selected.client.annual_income)}</p>
                </div>
                <div>
                  <div className={`pill ${selected.client.risk_rating}`}>{selected.client.risk_rating}</div>
                  <p>Risk score: <b>{selected.risk.risk_score}</b></p>
                </div>
              </div>

              <div className='card flag-panel'>
                <h3>Why flagged</h3>
                <p className='muted'>Analyst-readable indicators driving this client’s current risk posture.</p>
                <div className='flag-grid'>
                  {flagCards.map((f) => (
                    <div key={f.title} className='flag-card'>
                      <div className='flag-title-row'>
                        <b>{f.title}</b>
                        <span className={`severity ${f.severity.toLowerCase()}`}>{f.severity}</span>
                      </div>
                      <p>{f.text}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className='tabs'>
                {TABS.map((t) => <button key={t} className={t === tab ? 'active' : ''} onClick={() => setTab(t)}>{t}</button>)}
              </div>

              {tab === 'Demographics' && <div><p>{selected.client.profile_text}</p></div>}

              {tab === 'Client History' && (
                <div className='two-col'>
                  <div>
                    <h4>Name history</h4>
                    <ul className='compact-list'>{selected.history.names.map((n, i) => <li key={i}>{n.full_name} ({n.from_date} → {n.to_date || 'current'})</li>)}</ul>
                    <h4>Phone history</h4>
                    <ul className='compact-list'>{selected.history.phones.map((p, i) => <li key={i}>{p.phone} ({p.from_date} → {p.to_date || 'current'})</li>)}</ul>
                  </div>
                  <div>
                    <h4>Address history</h4>
                    <ul className='compact-list'>{selected.history.addresses.map((a, i) => <li key={i}>{a.address_line}, {a.city}, {countryLabel(a)} ({a.from_date} → {a.to_date || 'current'})</li>)}</ul>
                  </div>
                </div>
              )}

              {tab === 'Transactions' && (
                <div>
                  <CountryDirectionPies rows={countryFlow?.countries || []} onPickCountry={(countryCode) => setCountryFilter(countryCode)} />
                  <TransactionTypeSummaryPie transactions={filteredTx} />

                  <div className='analytics-grid'>
                    <div className='mini-kpi'><span>High-risk wire exposure</span><b>{countryFlow?.totals?.high_risk_ratio_pct || 0}%</b></div>
                    <div className='mini-kpi'><span>Inbound wire</span><b>{fmtMoney(countryFlow?.totals?.inbound)}</b></div>
                    <div className='mini-kpi'><span>Outbound wire</span><b>{fmtMoney(countryFlow?.totals?.outbound)}</b></div>
                    <div className='mini-kpi'><span>Inflow/Outflow imbalance</span><b>{fmtMoney(countryFlow?.totals?.inflow_outflow_imbalance)}</b></div>
                  </div>

                  <div className='two-col'>
                    <div>
                      <h4>Top cross-border corridors</h4>
                      <table><thead><tr><th>Corridor</th><th>Risk</th><th>Tx</th><th>Amount</th></tr></thead><tbody>
                        {(countryFlow?.top_corridors || []).map((c) => (
                          <tr key={c.corridor}>
                            <td>{c.corridor_display || `${c.source_country_name || c.source_country} → ${c.destination_country_name || c.destination_country}`}</td>
                            <td style={{ color: riskColor(c.risk_tag), fontWeight: 700 }}>{c.risk_tag}</td>
                            <td>{c.tx_count}</td>
                            <td>{fmtMoney(c.amount)}</td>
                          </tr>
                        ))}
                      </tbody></table>
                    </div>

                    <div>
                      <h4>Transaction flag summary</h4>
                      <ul className='compact-list'>
                        {Object.entries(txFeatures?.suspicious_flags || {}).map(([k, v]) => (
                          <li key={k}>{k.replaceAll('_', ' ')}: {v} ({txFeatures?.suspicious_ratios_pct?.[k] || 0}%)</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <h4>Wire countries (click country to drill down)</h4>
                  <table><thead><tr><th>Country</th><th>Inbound</th><th>Outbound</th><th>Share</th><th>Risk</th></tr></thead><tbody>
                    {(countryFlow?.countries || []).map((w) => (
                      <tr key={w.country}>
                        <td><button onClick={() => setCountryFilter(w.country)}>{countryLabel(w)}</button></td>
                        <td>{fmtMoney(w.inbound)}</td>
                        <td>{fmtMoney(w.outbound)}</td>
                        <td>{w.share_pct}%</td>
                        <td><span style={{ color: riskColor(w.risk_tier), fontWeight: 700 }}>{w.risk_tier}</span></td>
                      </tr>
                    ))}
                  </tbody></table>

                  {edgeTxContext && (
                    <div className={`card tx-edge-highlight ${edgeTxContext.matchCount ? '' : 'empty'}`} data-testid='edge-tx-highlight-banner'>
                      <b>Connection-edge transaction context active</b>
                      <p className='muted'>
                        {edgeTxContext.matchCount > 0
                          ? `${edgeTxContext.matchCount} transaction(s) matched the selected ${titleCase((edgeTxContext.linkType || '').replaceAll('_', ' '))} edge${edgeTxContext.counterpartyId ? ` for ${counterpartyNameById[edgeTxContext.counterpartyId] || edgeTxContext.counterpartyId}` : ''}.`
                          : 'No transactions matched this selected edge in the currently loaded transaction history.'}
                      </p>
                      <div className='actions'>
                        <button disabled={!edgeTxContext.matchCount} onClick={() => setShowOnlyEdgeMatches((v) => !v)}>
                          {showOnlyEdgeMatches ? 'Show all transactions' : 'Filter to highlighted transactions'}
                        </button>
                        <button onClick={clearEdgeTxContext}>Clear highlight/filter</button>
                      </div>
                    </div>
                  )}

                  <h4>
                    All transactions ({filteredTx.length})
                    {cpFilter ? ` (counterparty: ${counterpartyNameById[cpFilter] || cpFilter})` : ''}
                    {countryFilter ? ` (country: ${countryLabel({ country: countryFilter })})` : ''}
                    {edgeTxContext ? ` (edge matches: ${edgeTxContext.matchCount}${showOnlyEdgeMatches ? ', filtered view' : ''})` : ''}
                  </h4>
                  <div className='actions'>
                    <button onClick={() => setCpFilter(null)}>Clear counterparty filter</button>
                    <button onClick={() => setCountryFilter(null)}>Clear country filter</button>
                    {edgeTxContext && <button onClick={clearEdgeTxContext}>Clear edge highlight/filter</button>}
                    <label>Rows/page
                      <select value={txPageSize} onChange={(e) => setTxPageSize(Number(e.target.value))}>
                        {[50, 100, 200, 300].map((s) => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </label>
                    <button disabled={txPage <= 1} onClick={() => setTxPage((p) => Math.max(1, p - 1))}>Prev</button>
                    <span>{txPage}/{txPages}</span>
                    <button disabled={txPage >= txPages} onClick={() => setTxPage((p) => Math.min(txPages, p + 1))}>Next</button>
                  </div>
                  <div className='tx-scroll'>
                    <table><thead><tr><th>Date</th><th>Type</th><th>Direction</th><th>Amount</th><th>Country</th><th>Counterparty</th><th>Channel</th><th>Purpose</th><th>Flags/Tags</th></tr></thead><tbody>
                      {pagedTx.map((t) => (
                        <tr key={t.tx_id} className={highlightedTxIds.has(String(t.tx_id)) ? 'tx-row-highlight' : ''}>
                          <td>{t.timestamp.slice(0, 19).replace('T', ' ')}</td>
                          <td><span className={`tx-pill ${txBadgeClass(t)}`}>{t.tx_type}</span></td>
                          <td>{t.direction}</td>
                          <td>{fmtMoney(t.amount)} {t.currency}</td>
                          <td>{countryLabel(t)}</td>
                          <td>{withSecondaryId(t.counterparty_name || t.counterparty_id, t.counterparty_id)}</td>
                          <td>{t.channel}</td>
                          <td>{t.purpose_code || '-'}</td>
                          <td>{(t.flags || []).join(', ') || (t.typology_tags?.typology || '-')}</td>
                        </tr>
                      ))}
                    </tbody></table>
                  </div>
                </div>
              )}

              {tab === 'Login Activity' && (
                <div>
                  <div className='three-col'>
                    <div>
                      <label>From</label>
                      <input type='date' value={loginFilters.from} onChange={(e) => setLoginFilters((f) => ({ ...f, from: e.target.value }))} />
                    </div>
                    <div>
                      <label>To</label>
                      <input type='date' value={loginFilters.to} onChange={(e) => setLoginFilters((f) => ({ ...f, to: e.target.value }))} />
                    </div>
                    <div>
                      <label>IP Country</label>
                      <select value={loginFilters.country} onChange={(e) => setLoginFilters((f) => ({ ...f, country: e.target.value }))}>
                        <option value=''>All countries</option>
                        {[...new Set((loginActivity.records || []).map((r) => r.ip_country))].map((country) => (
                          <option key={country} value={country}>{countryLabel({ country })}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className='actions'>
                    <button onClick={() => loadLoginActivity(selected.client.client_id, loginFilters)}>Apply login filters</button>
                    <button onClick={() => { const reset = { from: '', to: '', country: '' }; setLoginFilters(reset); loadLoginActivity(selected.client.client_id, reset) }}>Clear</button>
                  </div>
                  <h4>Historical login records ({loginActivity.total || 0})</h4>
                  <div className='tx-scroll'>
                    <table><thead><tr><th>Timestamp</th><th>IP</th><th>IP Country</th><th>Status</th><th>Channel</th></tr></thead><tbody>
                      {(loginActivity.records || []).map((r) => (
                        <tr key={r.login_id}>
                          <td>{r.timestamp.slice(0, 19).replace('T', ' ')}</td>
                          <td>{r.ip_address}</td>
                          <td>{countryLabel(r)}</td>
                          <td>{r.status}</td>
                          <td>{r.channel}</td>
                        </tr>
                      ))}
                    </tbody></table>
                  </div>
                </div>
              )}

              {tab === 'Connections' && (
                <div className='connections-tab'>
                  <div className='analytics-grid'>
                    <div className='mini-kpi'><span>Network nodes</span><b>{connectionsData?.summary?.node_count || 0}</b></div>
                    <div className='mini-kpi'><span>Network edges</span><b>{connectionsData?.summary?.edge_count || 0}</b></div>
                    <div className='mini-kpi'><span>Counterparties</span><b>{connectionsData?.summary?.counterparty_count || 0}</b></div>
                    <div className='mini-kpi'><span>Linked entities</span><b>{connectionsData?.summary?.linked_entities || 0}</b></div>
                  </div>

                  <h4>Connected-entity network</h4>
                  <p className='muted'>Click a node or link to open evidence details.</p>
                  <div className='connections-toprow'>
                    <ConnectionsGraph data={connectionsData} clientId={selected?.client?.client_id} onPickEvidence={handleEvidenceSelection} />
                    <div className='card evidence-drawer evidence-inline' data-testid='link-evidence-panel'>
                      <div className='detail-header'>
                        <h4>Link evidence</h4>
                        {evidenceSelection ? <button onClick={() => setEvidenceSelection(null)}>Close</button> : <span className='muted'>Select a link</span>}
                      </div>
                      {!evidenceSelection && <p className='muted'>Select a connection in the graph to see matching transaction context here.</p>}
                      {evidenceSelection?.kind === 'node' && (
                        <div>
                          <p><b>{getEntityVisual(evidenceSelection.payload.entity_type).icon} {renderEntityName(evidenceSelection.payload)}</b> ({titleCase(evidenceSelection.payload.entity_type)})</p>
                          <p className='muted'>Connected entity selected from network graph.</p>
                        </div>
                      )}
                      {evidenceSelection?.kind === 'edge' && (
                        <div>
                          <p><b>{titleCase((evidenceSelection.payload.link_type || '').replaceAll('_', ' '))}</b></p>
                          <p>{narrateEdge(evidenceSelection.payload, Object.fromEntries((connectionsData?.nodes || []).map((n) => [n.id, n])))}</p>
                          <p className='muted'>{evidenceSelection.payload.reason}</p>
                          <ul className='compact-list'>
                            <li>First seen: {evidenceSelection.payload.first_seen ? evidenceSelection.payload.first_seen.slice(0, 19).replace('T', ' ') : '-'}</li>
                            <li>Last seen: {evidenceSelection.payload.last_seen ? evidenceSelection.payload.last_seen.slice(0, 19).replace('T', ' ') : '-'}</li>
                            <li>Count: {evidenceSelection.payload.count || 0}</li>
                            <li>Amount: {fmtMoney(evidenceSelection.payload.amount || 0)}</li>
                            {edgeTxContext?.edgeId === evidenceSelection.payload.id && (
                              <li>Transaction matches in list: {edgeTxContext.matchCount}</li>
                            )}
                          </ul>
                          {edgeTxContext?.edgeId === evidenceSelection.payload.id && (
                            <div className='actions'>
                              <button onClick={() => setTab('Transactions')}>View in Transactions tab</button>
                              <button onClick={clearEdgeTxContext}>Clear highlight/filter</button>
                            </div>
                          )}
                        </div>
                      )}
                      {evidenceSelection?.kind === 'entity' && (
                        <div>
                          <p><b>{getEntityVisual(evidenceSelection.payload.entity_type).icon} {renderEntityName(evidenceSelection.payload)}</b> ({titleCase(evidenceSelection.payload.entity_type)})</p>
                          <ul className='compact-list'>
                            <li>Relationship: {evidenceSelection.payload.relationship}</li>
                            <li>First seen: {evidenceSelection.payload.first_seen ? evidenceSelection.payload.first_seen.slice(0, 19).replace('T', ' ') : '-'}</li>
                            <li>Last seen: {evidenceSelection.payload.last_seen ? evidenceSelection.payload.last_seen.slice(0, 19).replace('T', ' ') : '-'}</li>
                            <li>Count: {evidenceSelection.payload.count || 0}</li>
                            <li>Amount: {fmtMoney(evidenceSelection.payload.amount || 0)}</li>
                          </ul>
                        </div>
                      )}
                      {evidenceSelection?.kind === 'path' && (
                        <div>
                          <p><b>Path to {evidenceSelection.payload.counterpartyName || counterpartyNameById[evidenceSelection.payload.counterpartyId] || evidenceSelection.payload.counterpartyId}</b></p>
                          <ul className='compact-list'>
                            <li>Hops: {evidenceSelection.payload.hop_count}</li>
                            <li>Transactional links: {evidenceSelection.payload.tx_edge_count}</li>
                            <li>Cumulative amount: {fmtMoney(evidenceSelection.payload.cumulative_amount)}</li>
                            <li>Path: {summarizePath(evidenceSelection.payload)}</li>
                            <li>Narration: {narratePath(evidenceSelection.payload)}</li>
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>

                  <h4>Quick transaction-path tracing</h4>
                  <div className='actions'>
                    <select value={pathCounterparty} onChange={(e) => setPathCounterparty(e.target.value)}>
                      <option value=''>Select counterparty</option>
                      {connectionCounterparties.map((cp) => <option key={cp.entity_id} value={cp.entity_id}>{renderEntityName(cp)}</option>)}
                    </select>
                    <button disabled={!pathCounterparty} onClick={() => traceConnectionPath(pathCounterparty)}>Trace path</button>
                  </div>
                  {connectionPath && (
                    <div className='card'>
                      <b>Path hops: {connectionPath.hop_count} • transactional links: {connectionPath.tx_edge_count} • cumulative amount: {fmtMoney(connectionPath.cumulative_amount)}</b>
                      <p className='muted'>
                        {narratePath(connectionPath)}
                      </p>
                    </div>
                  )}

                  <h4>Unified linked entities</h4>
                  <div className='tx-scroll linked-entities-scroll'>
                    <table><thead><tr><th>Entity</th><th>Type</th><th>Relationship</th><th>First seen</th><th>Last seen</th><th>Count</th><th>Amount</th><th></th></tr></thead><tbody>
                      {(connectionsData?.linked_entities || []).map((row) => {
                        const visual = getEntityVisual(row.entity_type)
                        return (
                          <tr key={`${row.entity_type}-${row.entity_id}`}>
                            <td><span className='entity-chip'><span>{visual.icon}</span>{renderEntityName(row)}</span></td>
                            <td>{visual.typeLabel}</td>
                            <td>{row.relationship}</td>
                            <td>{row.first_seen ? row.first_seen.slice(0, 10) : '-'}</td>
                            <td>{row.last_seen ? row.last_seen.slice(0, 10) : '-'}</td>
                            <td>{row.count || 0}</td>
                            <td>{fmtMoney(row.amount || 0)}</td>
                            <td>
                              <button onClick={() => setEvidenceSelection({ kind: 'entity', payload: row })}>Evidence</button>
                              {row.entity_type === 'counterparty' && (
                                <button onClick={() => { setPathCounterparty(row.entity_id); traceConnectionPath(row.entity_id) }}>Trace</button>
                              )}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody></table>
                  </div>

                </div>
              )}

              {tab === 'Evidence & Workflow' && (
                <div className='workflow-grid'>
                  <div>
                    <h4>Case workflow</h4>
                    <textarea placeholder='Case/risk rationale note (required for updates)' value={caseReason} onChange={(e) => setCaseReason(e.target.value)} />
                    <ul className='compact-list'>
                      {selected.cases.length === 0 ? <li>No cases</li> : selected.cases.map((c) => (
                        <li key={c.case_id} className='case-item'>
                          <div><b>{c.case_id}</b> • {c.status} • age {c.age_days}d</div>
                          <div>{c.title}</div>
                          <div className='actions'>
                            {['Open', 'Investigating', 'RFI', 'Close'].map((status) => (
                              <button key={status} disabled={!caseReason.trim() || c.status === status} onClick={() => updateCaseStatus(c.case_id, status)}>{status}</button>
                            ))}
                          </div>
                        </li>
                      ))}
                    </ul>

                    <h4>Risk decision support</h4>
                    <textarea placeholder='Risk decision reason' value={decisionReason} onChange={(e) => setDecisionReason(e.target.value)} />
                    <div className='actions'>
                      <button disabled={!decisionReason.trim()} onClick={() => submitDecision('up-risk')}>up-risk</button>
                      <button disabled={!decisionReason.trim()} onClick={() => submitDecision('down-risk')}>down-risk</button>
                      <button disabled={!decisionReason.trim()} onClick={() => submitDecision('no-change')}>no change</button>
                    </div>

                    <h4>Export</h4>
                    <div className='actions'>
                      <button onClick={() => downloadForClient('transactions.csv', `${selected.client.client_id}_transactions.csv`)}>Download transactions CSV</button>
                      <button onClick={() => downloadForClient('dossier.json', `${selected.client.client_id}_dossier.json`)}>Download dossier JSON</button>
                    </div>
                  </div>

                  <div>
                    <h4>Evidence timeline</h4>
                    <ul className='compact-list evidence-list'>
                      {[
                        ...(selected.alerts || []).map((a) => ({ ts: a.created_at, type: `Alert/${a.severity}`, text: `${a.status} • ${a.description}` })),
                        ...(selected.risk_decisions || []).map((d) => ({ ts: d.created_at, type: `Risk decision/${d.action}`, text: d.reason })),
                        ...(selected.cases || []).flatMap((c) => (c.notes || []).map((n) => ({ ts: n.created_at, type: `Case note/${c.case_id}`, text: n.note }))),
                      ].sort((a, b) => (a.ts < b.ts ? 1 : -1)).slice(0, 80).map((e, i) => (
                        <li key={`${e.ts}-${e.type}-${i}`}>
                          <b>{e.type}</b>
                          <div>{e.ts.slice(0, 19).replace('T', ' ')}</div>
                          <div>{e.text}</div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </>
          )}
        </section>
      </section>
    </div>
  )
}
