import csv
import io
from collections import defaultdict, deque
from datetime import date, datetime, time

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import asc, desc, func, or_, select
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import (
    Alert,
    Case,
    CaseNote,
    Client,
    ClientAddressHistory,
    ClientNameHistory,
    ClientPhoneHistory,
    LoginActivity,
    RiskDecisionLog,
    RiskResult,
    SeedJob,
    Transaction,
    WorldCheckHit,
)
from app.schemas.client import CaseStatusUpdateRequest, RiskDecisionRequest, SeedRequest
from app.workers.queue import enqueue_seed

router = APIRouter()

ALLOWED_SEGMENTS = {
    'white label ATM',
    'payment processor',
    'non profit',
    'gambling',
    'small business',
    'public company',
    'personal investment',
}
ALLOWED_CASE_STATUSES = {'Open', 'Investigating', 'RFI', 'Close'}

COUNTRY_DISPLAY_NAMES = {
    'US': 'United States',
    'CA': 'Canada',
    'GB': 'United Kingdom',
    'DE': 'Germany',
    'FR': 'France',
    'AU': 'Australia',
    'JP': 'Japan',
    'MX': 'Mexico',
    'BR': 'Brazil',
    'TR': 'Türkiye',
    'AE': 'United Arab Emirates',
    'IN': 'India',
    'NG': 'Nigeria',
    'RU': 'Russia',
    'IR': 'Iran',
    'SY': 'Syria',
    'KP': 'North Korea',
    'AF': 'Afghanistan',
    'VE': 'Venezuela',
}


def country_name(country_code: str | None) -> str:
    if not country_code:
        return ''
    return COUNTRY_DISPLAY_NAMES.get(country_code, country_code)


def _fmt_dt(value):
    return value.isoformat() if value else None


def _safe_min(cur, incoming):
    if incoming is None:
        return cur
    if cur is None:
        return incoming
    return incoming if incoming < cur else cur


def _safe_max(cur, incoming):
    if incoming is None:
        return cur
    if cur is None:
        return incoming
    return incoming if incoming > cur else cur


def _normalize_entity_label(entity_type: str, value: str, metadata: dict | None = None):
    meta = metadata or {}
    if entity_type == 'address':
        city = meta.get('city')
        ctry = country_name(meta.get('country'))
        suffix = ', '.join([p for p in [city, ctry] if p])
        return f'{value} ({suffix})' if suffix else value
    if entity_type == 'phone':
        return value
    if entity_type == 'profile':
        return value
    if entity_type == 'account':
        return value
    return value


def _fallback_counterparty_name(counterparty_id: str) -> str:
    return f'Counterparty {counterparty_id}'


def _resolve_counterparty_names(db: Session, counterparty_ids: set[str]) -> dict[str, str]:
    if not counterparty_ids:
        return {}
    rows = db.execute(select(Client.client_id, Client.full_name).where(Client.client_id.in_(list(counterparty_ids)))).all()
    return {cid: full_name for cid, full_name in rows}


def _build_connection_payload(client: Client, txs, addresses, phones, counterparty_names: dict[str, str] | None = None):
    client_node_id = f'client:{client.client_id}'
    nodes = {
        client_node_id: {
            'id': client_node_id,
            'entity_id': client.client_id,
            'label': client.full_name,
            'entity_type': 'client',
            'importance': 1.0,
            'metadata': {
                'country': client.country,
                'country_name': country_name(client.country),
                'segment': client.segment,
                'risk_rating': client.risk_rating,
            },
        }
    }
    edges = []
    linked_entities = []

    def add_node(node_id, entity_id, label, entity_type, importance=0.5, metadata=None):
        if node_id not in nodes:
            nodes[node_id] = {
                'id': node_id,
                'entity_id': entity_id,
                'label': label,
                'entity_type': entity_type,
                'importance': importance,
                'metadata': metadata or {},
            }

    def add_edge(source, target, link_type, reason, first_seen=None, last_seen=None, count=0, amount=0.0, metadata=None):
        edge_id = f"{link_type}:{source}->{target}:{len(edges)}"
        edges.append(
            {
                'id': edge_id,
                'source': source,
                'target': target,
                'link_type': link_type,
                'reason': reason,
                'first_seen': _fmt_dt(first_seen),
                'last_seen': _fmt_dt(last_seen),
                'count': int(count or 0),
                'amount': round(float(amount or 0.0), 2),
                'metadata': metadata or {},
            }
        )

    account_node = f'account:{client.client_id}:primary'
    add_node(
        account_node,
        f'ACC-{client.client_id}-PRIMARY',
        f'ACC-{client.client_id}-PRIMARY',
        'account',
        importance=0.85,
        metadata={'owner_client_id': client.client_id, 'account_role': 'primary'},
    )
    add_edge(
        client_node_id,
        account_node,
        'owns_account',
        'Client owns primary account used as source/sink of observed transactions.',
    )
    linked_entities.append(
        {
            'entity_id': f'ACC-{client.client_id}-PRIMARY',
            'entity_type': 'account',
            'label': f'ACC-{client.client_id}-PRIMARY',
            'relationship': 'owns_account',
            'first_seen': None,
            'last_seen': None,
            'count': 0,
            'amount': 0.0,
            'metadata': {'account_role': 'primary'},
        }
    )

    profile_rows = [
        ('segment', client.segment),
        ('occupation', client.occupation),
        ('risk_rating', client.risk_rating),
    ]
    for profile_key, profile_val in profile_rows:
        if not profile_val:
            continue
        node_id = f'profile:{profile_key}:{profile_val}'
        add_node(
            node_id,
            node_id,
            f'{profile_key.replace("_", " ").title()}: {profile_val}',
            'profile',
            importance=0.45,
            metadata={'profile_key': profile_key, 'profile_value': profile_val},
        )
        add_edge(
            client_node_id,
            node_id,
            'profile_attribute',
            f'Client profile attribute {profile_key} equals {profile_val}.',
        )
        linked_entities.append(
            {
                'entity_id': node_id,
                'entity_type': 'profile',
                'label': f'{profile_key.replace("_", " ").title()}: {profile_val}',
                'relationship': 'profile_attribute',
                'first_seen': None,
                'last_seen': None,
                'count': 1,
                'amount': 0.0,
                'metadata': {'profile_key': profile_key},
            }
        )

    for idx, a in enumerate(addresses, start=1):
        entity_id = f'ADDR-{client.client_id}-{idx}'
        node_id = f'address:{client.client_id}:{idx}'
        label = _normalize_entity_label('address', a.address_line, {'city': a.city, 'country': a.country})
        add_node(node_id, entity_id, label, 'address', importance=0.4, metadata={'city': a.city, 'country': a.country})
        add_edge(
            client_node_id,
            node_id,
            'address_association',
            'Address appears in verified client address history.',
            first_seen=datetime.combine(a.from_date, time.min),
            last_seen=datetime.combine(a.to_date, time.min) if a.to_date else None,
            count=1,
        )
        linked_entities.append(
            {
                'entity_id': entity_id,
                'entity_type': 'address',
                'label': label,
                'relationship': 'address_association',
                'first_seen': a.from_date.isoformat(),
                'last_seen': a.to_date.isoformat() if a.to_date else None,
                'count': 1,
                'amount': 0.0,
                'metadata': {'city': a.city, 'country': a.country, 'country_name': country_name(a.country)},
            }
        )

    for idx, p in enumerate(phones, start=1):
        entity_id = f'PHONE-{client.client_id}-{idx}'
        node_id = f'phone:{client.client_id}:{idx}'
        add_node(node_id, entity_id, p.phone, 'phone', importance=0.35, metadata={})
        add_edge(
            client_node_id,
            node_id,
            'phone_association',
            'Phone appears in verified client phone history.',
            first_seen=datetime.combine(p.from_date, time.min),
            last_seen=datetime.combine(p.to_date, time.min) if p.to_date else None,
            count=1,
        )
        linked_entities.append(
            {
                'entity_id': entity_id,
                'entity_type': 'phone',
                'label': p.phone,
                'relationship': 'phone_association',
                'first_seen': p.from_date.isoformat(),
                'last_seen': p.to_date.isoformat() if p.to_date else None,
                'count': 1,
                'amount': 0.0,
                'metadata': {},
            }
        )

    cp_name_map = counterparty_names or {}
    cp_stats = {}
    for t in txs:
        cp_id = t.counterparty_id if t.client_id == client.client_id else t.client_id
        if not cp_id or cp_id == client.client_id:
            continue
        cp_name = cp_name_map.get(cp_id) or _fallback_counterparty_name(cp_id)
        node_id = f'counterparty:{cp_id}'
        cp_node_meta = {'country': t.country, 'country_name': country_name(t.country), 'display_name': cp_name}
        add_node(node_id, cp_id, cp_name, 'counterparty', importance=0.62, metadata=cp_node_meta)

        account_id = f'ACC-{cp_id}-EXT'
        cp_account_node = f'account:{cp_id}:external'
        add_node(
            cp_account_node,
            account_id,
            f'{cp_name} external account',
            'account',
            importance=0.45,
            metadata={'owner_counterparty_id': cp_id, 'owner_counterparty_name': cp_name, 'account_role': 'external'},
        )
        add_edge(
            node_id,
            cp_account_node,
            'owns_account',
            'Counterparty account inferred from transactional relationship.',
        )

        key = cp_id
        stat = cp_stats.setdefault(
            key,
            {
                'node_id': node_id,
                'counterparty_id': cp_id,
                'counterparty_name': cp_name,
                'country': t.country,
                'first_seen': None,
                'last_seen': None,
                'tx_count': 0,
                'total_amount': 0.0,
                'incoming': 0,
                'outgoing': 0,
                'tx_ids': [],
                'incoming_tx_ids': [],
                'outgoing_tx_ids': [],
            },
        )
        stat['first_seen'] = _safe_min(stat['first_seen'], t.timestamp)
        stat['last_seen'] = _safe_max(stat['last_seen'], t.timestamp)
        stat['tx_count'] += 1
        stat['total_amount'] += float(t.amount)
        stat['tx_ids'].append(t.tx_id)
        if t.direction == 'incoming':
            stat['incoming'] += 1
            stat['incoming_tx_ids'].append(t.tx_id)
        else:
            stat['outgoing'] += 1
            stat['outgoing_tx_ids'].append(t.tx_id)

    for cp_id, stat in cp_stats.items():
        node_id = stat['node_id']
        cp_account_node = f'account:{cp_id}:external'
        tx_direction = 'mixed' if stat['incoming'] and stat['outgoing'] else ('incoming' if stat['incoming'] else 'outgoing')
        tx_metadata = {
            'incoming_count': stat['incoming'],
            'outgoing_count': stat['outgoing'],
            'counterparty_id': cp_id,
            'counterparty_name': stat['counterparty_name'],
            'direction': tx_direction,
            'time_start': _fmt_dt(stat['first_seen']),
            'time_end': _fmt_dt(stat['last_seen']),
            'transaction_ids': stat['tx_ids'],
            'incoming_transaction_ids': stat['incoming_tx_ids'],
            'outgoing_transaction_ids': stat['outgoing_tx_ids'],
        }
        add_edge(
            account_node,
            cp_account_node,
            'transaction_path',
            f"Funds flowed between client primary account and {stat['counterparty_name']}'s external account.",
            first_seen=stat['first_seen'],
            last_seen=stat['last_seen'],
            count=stat['tx_count'],
            amount=stat['total_amount'],
            metadata=tx_metadata,
        )
        add_edge(
            client_node_id,
            node_id,
            'transacted_with',
            f"Client transacted directly with {stat['counterparty_name']}.",
            first_seen=stat['first_seen'],
            last_seen=stat['last_seen'],
            count=stat['tx_count'],
            amount=stat['total_amount'],
            metadata=tx_metadata,
        )

        linked_entities.append(
            {
                'entity_id': cp_id,
                'entity_type': 'counterparty',
                'label': stat['counterparty_name'],
                'relationship': 'transacted_with',
                'first_seen': _fmt_dt(stat['first_seen']),
                'last_seen': _fmt_dt(stat['last_seen']),
                'count': stat['tx_count'],
                'amount': round(stat['total_amount'], 2),
                'metadata': {
                    'country': stat['country'],
                    'country_name': country_name(stat['country']),
                    'incoming_count': stat['incoming'],
                    'outgoing_count': stat['outgoing'],
                    'counterparty_name': stat['counterparty_name'],
                },
            }
        )

        linked_entities.append(
            {
                'entity_id': f'ACC-{cp_id}-EXT',
                'entity_type': 'account',
                'label': f"{stat['counterparty_name']} external account",
                'relationship': 'transaction_path',
                'first_seen': _fmt_dt(stat['first_seen']),
                'last_seen': _fmt_dt(stat['last_seen']),
                'count': stat['tx_count'],
                'amount': round(stat['total_amount'], 2),
                'metadata': {'owner_counterparty_id': cp_id, 'owner_counterparty_name': stat['counterparty_name'], 'account_role': 'external'},
            }
        )

    linked_entities = sorted(
        linked_entities,
        key=lambda e: (-(e.get('amount') or 0), -(e.get('count') or 0), e.get('entity_type', ''), e.get('label', '')),
    )

    return {
        'client_id': client.client_id,
        'nodes': list(nodes.values()),
        'edges': edges,
        'linked_entities': linked_entities,
    }


def _build_path(nodes_by_id: dict, edges: list[dict], start_id: str, end_id: str):
    graph = defaultdict(list)
    edge_lookup = {}
    for e in edges:
        graph[e['source']].append((e['target'], e['id']))
        graph[e['target']].append((e['source'], e['id']))
        edge_lookup[e['id']] = e

    q = deque([[start_id]])
    seen = {start_id}
    found_path = None
    while q:
        path = q.popleft()
        cur = path[-1]
        if cur == end_id:
            found_path = path
            break
        for nxt, _ in graph.get(cur, []):
            if nxt in seen:
                continue
            seen.add(nxt)
            q.append(path + [nxt])

    if not found_path:
        return None

    path_edges = []
    cumulative_amount = 0.0
    tx_edge_count = 0
    for i in range(len(found_path) - 1):
        a, b = found_path[i], found_path[i + 1]
        edge_id = None
        for candidate, cid in graph[a]:
            if candidate == b:
                edge_id = cid
                break
        if edge_id:
            edge = edge_lookup[edge_id]
            path_edges.append(edge)
            cumulative_amount += float(edge.get('amount') or 0.0)
            if edge.get('link_type') in {'transacted_with', 'transaction_path'}:
                tx_edge_count += 1

    return {
        'nodes': [nodes_by_id[n] for n in found_path if n in nodes_by_id],
        'edges': path_edges,
        'hop_count': max(0, len(found_path) - 1),
        'tx_edge_count': tx_edge_count,
        'cumulative_amount': round(cumulative_amount, 2),
    }


@router.get('/health')
def health(db: Session = Depends(get_db)):
    db.execute(select(1))
    return {'status': 'ok', 'time': datetime.utcnow().isoformat()}


@router.get('/clients')
def list_clients(
    q: str | None = None,
    segment: str | None = None,
    min_risk: float = 0,
    risk_rating: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    sort_by: str = Query('risk_score'),
    sort_dir: str = Query('desc'),
    db: Session = Depends(get_db),
):
    base_stmt = select(Client, RiskResult).join(RiskResult, RiskResult.client_id == Client.client_id)
    if q:
        like = f'%{q.strip()}%'
        base_stmt = base_stmt.where(
            or_(Client.client_id.ilike(like), Client.full_name.ilike(like), Client.city.ilike(like))
        )
    if segment:
        base_stmt = base_stmt.where(Client.segment == segment)
    if min_risk > 0:
        base_stmt = base_stmt.where(RiskResult.risk_score >= min_risk)
    if risk_rating:
        base_stmt = base_stmt.where(Client.risk_rating == risk_rating)

    total = db.execute(select(func.count()).select_from(base_stmt.subquery())).scalar_one()

    sort_columns = {
        'risk_score': RiskResult.risk_score,
        'full_name': Client.full_name,
        'city': Client.city,
        'annual_income': Client.annual_income,
        'client_id': Client.client_id,
        'risk_rating': Client.risk_rating,
    }
    selected_column = sort_columns.get(sort_by, RiskResult.risk_score)
    order_fn = desc if sort_dir.lower() != 'asc' else asc

    offset = (page - 1) * page_size
    rows = db.execute(
        base_stmt.order_by(order_fn(selected_column), Client.client_id.asc()).offset(offset).limit(page_size)
    ).all()

    items = [
        {
            'client_id': c.client_id,
            'full_name': c.full_name,
            'segment': c.segment,
            'country': c.country,
            'country_name': country_name(c.country),
            'city': c.city,
            'annual_income': c.annual_income,
            'risk_score': r.risk_score,
            'risk_rating': c.risk_rating,
            'profile_text': c.profile_text,
        }
        for c, r in rows
    ]

    pages = max(1, (total + page_size - 1) // page_size)
    return {
        'items': items,
        'page': page,
        'page_size': page_size,
        'total': total,
        'pages': pages,
        'sort_by': sort_by,
        'sort_dir': sort_dir,
    }


@router.get('/clients/{client_id}')
def get_client(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    risk = db.get(RiskResult, client_id)
    txs = db.execute(
        select(Transaction)
        .where(Transaction.client_id == client_id)
        .order_by(Transaction.timestamp.desc())
        .limit(5000)
    ).scalars().all()

    names = db.execute(select(ClientNameHistory).where(ClientNameHistory.client_id == client_id).order_by(ClientNameHistory.from_date.desc())).scalars().all()
    addresses = db.execute(select(ClientAddressHistory).where(ClientAddressHistory.client_id == client_id).order_by(ClientAddressHistory.from_date.desc())).scalars().all()
    phones = db.execute(select(ClientPhoneHistory).where(ClientPhoneHistory.client_id == client_id).order_by(ClientPhoneHistory.from_date.desc())).scalars().all()
    wc_hits = db.execute(select(WorldCheckHit).where(WorldCheckHit.client_id == client_id)).scalars().all()
    cases = db.execute(select(Case).where(Case.client_id == client_id).order_by(Case.opened_at.desc())).scalars().all()
    notes = db.execute(select(CaseNote).where(CaseNote.case_id.in_([c.case_id for c in cases]))).scalars().all() if cases else []
    alerts = db.execute(select(Alert).where(Alert.client_id == client_id).order_by(Alert.created_at.desc())).scalars().all()
    decisions = db.execute(select(RiskDecisionLog).where(RiskDecisionLog.client_id == client_id).order_by(RiskDecisionLog.created_at.desc())).scalars().all()

    counterparty_names = _resolve_counterparty_names(db, {t.counterparty_id for t in txs if t.counterparty_id and t.counterparty_id != client_id})

    wire_stats = {}
    total_wire = 0.0
    for t in txs:
        if t.tx_type != 'wire':
            continue
        c = t.country
        total_wire += float(t.amount)
        if c not in wire_stats:
            wire_stats[c] = {
                'country': c,
                'country_name': country_name(c),
                'incoming': 0.0,
                'outgoing': 0.0,
                'risk': t.typology_tags.get('destination_country_risk_tier')
                or t.typology_tags.get('wire_country_risk', 'medium'),
            }
        wire_stats[c][t.direction] += float(t.amount)

    for c in wire_stats.values():
        c['total'] = round(c['incoming'] + c['outgoing'], 2)
        c['share_pct'] = round((c['total'] / total_wire) * 100, 2) if total_wire > 0 else 0.0

    return {
        'client': {
            'client_id': client.client_id,
            'full_name': client.full_name,
            'profile_text': client.profile_text,
            'country': client.country,
            'country_name': country_name(client.country),
            'city': client.city,
            'segment': client.segment,
            'annual_income': client.annual_income,
            'dob': client.dob.isoformat(),
            'occupation': client.occupation,
            'pep_flag': client.pep_flag,
            'sanctions_flag': client.sanctions_flag,
            'risk_rating': client.risk_rating,
        },
        'risk': {
            'risk_score': risk.risk_score if risk else None,
            'rule_hits': risk.rule_hits if risk else {},
            'model_reason': risk.model_reason if risk else '',
        },
        'transactions': [
            {
                'tx_id': t.tx_id,
                'counterparty_id': t.counterparty_id,
                'counterparty_name': counterparty_names.get(t.counterparty_id) or _fallback_counterparty_name(t.counterparty_id),
                'tx_type': t.tx_type,
                'direction': t.direction,
                'amount': t.amount,
                'country': t.country,
                'country_name': country_name(t.country),
                'timestamp': t.timestamp.isoformat(),
                'typology_tags': t.typology_tags,
                'channel': t.channel,
                'currency': t.currency,
                'purpose_code': (t.typology_tags or {}).get('purpose_code'),
                'source_country': (t.typology_tags or {}).get('source_country'),
                'source_country_name': country_name((t.typology_tags or {}).get('source_country')),
                'destination_country': (t.typology_tags or {}).get('destination_country'),
                'destination_country_name': country_name((t.typology_tags or {}).get('destination_country')),
                'flags': [
                    k for k, enabled in {
                        'cross_border': bool((t.typology_tags or {}).get('cross_border')),
                        'round_amount': bool((t.typology_tags or {}).get('round_amount_flag')),
                        'near_threshold': bool((t.typology_tags or {}).get('near_threshold_flag')),
                        'weekend': bool((t.typology_tags or {}).get('weekend_flag')),
                        'night': bool((t.typology_tags or {}).get('night_flag')),
                        'recurring': bool((t.typology_tags or {}).get('recurring_flag')),
                        'high_risk_corridor': ((t.typology_tags or {}).get('corridor_risk_tag') == 'high'),
                        'burst_signal': bool((t.typology_tags or {}).get('burst_signal')),
                    }.items() if enabled
                ],
            }
            for t in txs
        ],
        'history': {
            'names': [{'full_name': n.full_name, 'from_date': n.from_date.isoformat(), 'to_date': n.to_date.isoformat() if n.to_date else None} for n in names],
            'addresses': [{'address_line': a.address_line, 'city': a.city, 'country': a.country, 'country_name': country_name(a.country), 'from_date': a.from_date.isoformat(), 'to_date': a.to_date.isoformat() if a.to_date else None} for a in addresses],
            'phones': [{'phone': p.phone, 'from_date': p.from_date.isoformat(), 'to_date': p.to_date.isoformat() if p.to_date else None} for p in phones],
        },
        'world_check_hits': [
            {'hit_id': h.hit_id, 'category': h.category, 'match_score': h.match_score, 'source': h.source, 'notes': h.notes}
            for h in wc_hits
        ],
        'cases': [
            {
                'case_id': c.case_id,
                'status': c.status,
                'title': c.title,
                'opened_at': c.opened_at.isoformat(),
                'closed_at': c.closed_at.isoformat() if c.closed_at else None,
                'age_days': max(0, (datetime.utcnow() - c.opened_at).days),
                'notes': [
                    {'note_id': n.note_id, 'created_at': n.created_at.isoformat(), 'note': n.note}
                    for n in notes if n.case_id == c.case_id
                ],
            }
            for c in cases
        ],
        'alerts': [
            {
                'alert_id': a.alert_id,
                'case_id': a.case_id,
                'severity': a.severity,
                'status': a.status,
                'created_at': a.created_at.isoformat(),
                'description': a.description,
            }
            for a in alerts
        ],
        'wire_country_breakdown': sorted(wire_stats.values(), key=lambda x: (x['incoming'] + x['outgoing']), reverse=True),
        'risk_decisions': [
            {
                'decision_id': d.decision_id,
                'action': d.action,
                'reason': d.reason,
                'created_at': d.created_at.isoformat(),
            }
            for d in decisions
        ],
    }


@router.get('/clients/{client_id}/login-activity')
def client_login_activity(
    client_id: str,
    from_date: date | None = None,
    to_date: date | None = None,
    # backward compatibility
    from_ts: datetime | None = None,
    to_ts: datetime | None = None,
    ip_country: str | None = None,
    limit: int = Query(400, ge=1, le=3000),
    db: Session = Depends(get_db),
):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    stmt = select(LoginActivity).where(LoginActivity.client_id == client_id)

    from_boundary = from_ts
    to_boundary = to_ts
    if from_date:
        from_boundary = datetime.combine(from_date, time.min)
    if to_date:
        to_boundary = datetime.combine(to_date, time.max)

    if from_boundary:
        stmt = stmt.where(LoginActivity.logged_in_at >= from_boundary)
    if to_boundary:
        stmt = stmt.where(LoginActivity.logged_in_at <= to_boundary)
    if ip_country:
        stmt = stmt.where(LoginActivity.ip_country == ip_country)

    rows = db.execute(stmt.order_by(LoginActivity.logged_in_at.desc()).limit(limit)).scalars().all()
    return {
        'client_id': client_id,
        'total': len(rows),
        'records': [
            {
                'login_id': r.login_id,
                'timestamp': r.logged_in_at.isoformat(),
                'ip_address': r.ip_address,
                'ip_country': r.ip_country,
                'ip_country_name': country_name(r.ip_country),
                'status': r.status,
                'channel': r.channel,
            }
            for r in rows
        ],
    }


@router.post('/clients/{client_id}/risk-decision')
def add_risk_decision(client_id: str, req: RiskDecisionRequest, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    log = RiskDecisionLog(
        decision_id=f'DEC-{datetime.utcnow().timestamp()}-{client_id[-4:]}',
        client_id=client_id,
        action=req.action,
        reason=req.reason,
        created_at=datetime.utcnow(),
    )
    db.add(log)
    db.commit()
    return {'status': 'ok'}


@router.post('/cases/{case_id}/status')
def update_case_status(case_id: str, req: CaseStatusUpdateRequest, db: Session = Depends(get_db)):
    case = db.get(Case, case_id)
    if not case:
        raise HTTPException(status_code=404, detail='Case not found')
    if req.status not in ALLOWED_CASE_STATUSES:
        raise HTTPException(status_code=400, detail=f'Invalid status: {req.status}')

    case.status = req.status
    if req.status == 'Close':
        case.closed_at = datetime.utcnow()
    else:
        case.closed_at = None

    note = CaseNote(
        note_id=f'NOTE-{datetime.utcnow().timestamp()}-{case_id[-4:]}',
        case_id=case_id,
        created_at=datetime.utcnow(),
        note=f'Status updated to {req.status}: {req.reason.strip()}',
    )
    db.add(note)
    db.commit()
    return {'status': 'ok', 'case_id': case_id, 'new_status': case.status}


@router.get('/clients/{client_id}/export/transactions.csv')
def export_transactions_csv(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(Transaction.client_id == client_id)
        .order_by(Transaction.timestamp.desc())
        .limit(10000)
    ).scalars().all()

    stream = io.StringIO()
    writer = csv.writer(stream)
    writer.writerow([
        'tx_id', 'timestamp', 'tx_type', 'direction', 'amount', 'currency', 'country',
        'counterparty_id', 'channel', 'purpose_code', 'corridor_risk_tag', 'flags'
    ])

    for t in txs:
        tags = t.typology_tags or {}
        flags = [
            f for f, enabled in {
                'cross_border': bool(tags.get('cross_border')),
                'round_amount': bool(tags.get('round_amount_flag')),
                'near_threshold': bool(tags.get('near_threshold_flag')),
                'weekend': bool(tags.get('weekend_flag')),
                'night': bool(tags.get('night_flag')),
                'recurring': bool(tags.get('recurring_flag')),
                'high_risk_corridor': tags.get('corridor_risk_tag') == 'high',
                'burst_signal': bool(tags.get('burst_signal')),
            }.items() if enabled
        ]
        writer.writerow([
            t.tx_id,
            t.timestamp.isoformat(),
            t.tx_type,
            t.direction,
            t.amount,
            t.currency,
            country_name(t.country),
            t.counterparty_id,
            t.channel,
            tags.get('purpose_code', ''),
            tags.get('corridor_risk_tag', ''),
            '|'.join(flags),
        ])

    return Response(
        content=stream.getvalue(),
        media_type='text/csv',
        headers={'Content-Disposition': f'attachment; filename="{client_id}_transactions.csv"'},
    )


@router.get('/clients/{client_id}/export/dossier.json')
def export_client_dossier(client_id: str, db: Session = Depends(get_db)):
    payload = get_client(client_id, db)
    return payload


@router.get('/clients/{client_id}/connections')
def client_connections(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(or_(Transaction.client_id == client_id, Transaction.counterparty_id == client_id))
        .order_by(Transaction.timestamp.desc())
        .limit(6000)
    ).scalars().all()
    addresses = db.execute(
        select(ClientAddressHistory)
        .where(ClientAddressHistory.client_id == client_id)
        .order_by(ClientAddressHistory.from_date.desc())
        .limit(30)
    ).scalars().all()
    phones = db.execute(
        select(ClientPhoneHistory)
        .where(ClientPhoneHistory.client_id == client_id)
        .order_by(ClientPhoneHistory.from_date.desc())
        .limit(30)
    ).scalars().all()

    cp_ids = {
        t.counterparty_id if t.client_id == client_id else t.client_id
        for t in txs
        if (t.counterparty_id if t.client_id == client_id else t.client_id)
        and (t.counterparty_id if t.client_id == client_id else t.client_id) != client_id
    }
    counterparty_names = _resolve_counterparty_names(db, cp_ids)
    payload = _build_connection_payload(client, txs, addresses, phones, counterparty_names=counterparty_names)
    payload['summary'] = {
        'node_count': len(payload['nodes']),
        'edge_count': len(payload['edges']),
        'counterparty_count': sum(1 for n in payload['nodes'] if n.get('entity_type') == 'counterparty'),
        'linked_entities': len(payload['linked_entities']),
    }
    return payload


@router.get('/clients/{client_id}/connections/path/{counterparty_id}')
def client_connections_path(client_id: str, counterparty_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(or_(Transaction.client_id == client_id, Transaction.counterparty_id == client_id))
        .order_by(Transaction.timestamp.desc())
        .limit(6000)
    ).scalars().all()
    addresses = db.execute(select(ClientAddressHistory).where(ClientAddressHistory.client_id == client_id).limit(30)).scalars().all()
    phones = db.execute(select(ClientPhoneHistory).where(ClientPhoneHistory.client_id == client_id).limit(30)).scalars().all()
    cp_ids = {
        t.counterparty_id if t.client_id == client_id else t.client_id
        for t in txs
        if (t.counterparty_id if t.client_id == client_id else t.client_id)
        and (t.counterparty_id if t.client_id == client_id else t.client_id) != client_id
    }
    counterparty_names = _resolve_counterparty_names(db, cp_ids)
    payload = _build_connection_payload(client, txs, addresses, phones, counterparty_names=counterparty_names)

    start_id = f'client:{client_id}'
    end_id = f'counterparty:{counterparty_id}'
    nodes_by_id = {n['id']: n for n in payload['nodes']}
    if end_id not in nodes_by_id:
        raise HTTPException(status_code=404, detail='Counterparty not connected to client')

    path = _build_path(nodes_by_id, payload['edges'], start_id, end_id)
    if not path:
        raise HTTPException(status_code=404, detail='No path found')

    return {
        'client_id': client_id,
        'counterparty_id': counterparty_id,
        'counterparty_name': counterparty_names.get(counterparty_id) or _fallback_counterparty_name(counterparty_id),
        'path': path,
    }


@router.get('/network/{client_id}')
def network(client_id: str, depth: int = 1, db: Session = Depends(get_db)):
    base = db.execute(
        select(Transaction)
        .where(or_(Transaction.client_id == client_id, Transaction.counterparty_id == client_id))
        .order_by(Transaction.timestamp.desc())
        .limit(1000)
    ).scalars().all()

    nodes = {client_id}
    edges = []
    total_amount = 0.0
    for t in base:
        nodes.add(t.client_id)
        nodes.add(t.counterparty_id)
        total_amount += float(t.amount)
        edges.append(
            {
                'source': t.client_id,
                'target': t.counterparty_id,
                'amount': t.amount,
                'tx_type': t.tx_type,
                'timestamp': t.timestamp.isoformat(),
            }
        )

    return {
        'nodes': [{'id': n} for n in nodes],
        'edges': edges[:500],
        'depth': depth,
        'summary': {
            'counterparties': max(0, len(nodes) - 1),
            'connections': len(edges),
            'total_flow': round(total_amount, 2),
        },
    }


@router.get('/analytics/summary')
def summary(db: Session = Depends(get_db)):
    clients = db.scalar(select(func.count()).select_from(Client)) or 0
    txs = db.scalar(select(func.count()).select_from(Transaction)) or 0
    avg_risk = db.scalar(select(func.avg(RiskResult.risk_score))) or 0
    high_risk = db.scalar(select(func.count()).select_from(RiskResult).where(RiskResult.risk_score >= 70)) or 0
    by_rating = db.execute(select(Client.risk_rating, func.count()).group_by(Client.risk_rating)).all()
    open_alerts = db.scalar(select(func.count()).select_from(Alert).where(Alert.status != 'Closed')) or 0
    return {
        'clients': clients,
        'transactions': txs,
        'avg_risk': round(float(avg_risk), 2),
        'high_risk': high_risk,
        'open_alerts': open_alerts,
        'risk_rating_counts': {k: v for k, v in by_rating},
    }


@router.get('/analytics/segments')
def segments(db: Session = Depends(get_db)):
    rows = db.execute(select(Client.segment, func.count()).group_by(Client.segment).order_by(Client.segment)).all()
    # enforce allowed list only
    out = [{'segment': segment, 'count': count} for segment, count in rows if segment in ALLOWED_SEGMENTS]
    return out


@router.get('/analytics/country-flow/{client_id}')
def country_flow_analytics(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(Transaction.client_id == client_id, Transaction.tx_type == 'wire')
        .order_by(Transaction.timestamp.desc())
        .limit(5000)
    ).scalars().all()

    by_country = {}
    total_in = 0.0
    total_out = 0.0
    high_risk_total = 0.0
    risk_tier_amounts = {'low': 0.0, 'medium': 0.0, 'high': 0.0}
    corridor_map = {}

    for t in txs:
        amt = float(t.amount)
        total_in += amt if t.direction == 'incoming' else 0.0
        total_out += amt if t.direction == 'outgoing' else 0.0
        tags = t.typology_tags or {}

        row = by_country.setdefault(
            t.country,
            {
                'country': t.country,
                'country_name': country_name(t.country),
                'inbound': 0.0,
                'outbound': 0.0,
                'total': 0.0,
                'risk_tier': tags.get('destination_country_risk_tier') or tags.get('wire_country_risk', 'medium'),
            },
        )
        row['inbound'] += amt if t.direction == 'incoming' else 0.0
        row['outbound'] += amt if t.direction == 'outgoing' else 0.0
        row['total'] += amt

        tier = row['risk_tier'] if row['risk_tier'] in risk_tier_amounts else 'medium'
        risk_tier_amounts[tier] += amt
        if tier == 'high':
            high_risk_total += amt

        src = tags.get('source_country') or (client.country if t.direction == 'outgoing' else t.country)
        dst = tags.get('destination_country') or (t.country if t.direction == 'outgoing' else client.country)
        key = f'{src}->{dst}'
        c = corridor_map.setdefault(
            key,
            {
                'corridor': key,
                'corridor_display': f"{country_name(src)} → {country_name(dst)}",
                'source_country': src,
                'source_country_name': country_name(src),
                'destination_country': dst,
                'destination_country_name': country_name(dst),
                'risk_tag': tags.get('corridor_risk_tag', 'medium'),
                'amount': 0.0,
                'tx_count': 0,
            },
        )
        c['amount'] += amt
        c['tx_count'] += 1

    total_wire = total_in + total_out
    countries = sorted(by_country.values(), key=lambda x: x['total'], reverse=True)
    for c in countries:
        c['share_pct'] = round((c['total'] / total_wire) * 100, 2) if total_wire > 0 else 0.0
        c['inbound'] = round(c['inbound'], 2)
        c['outbound'] = round(c['outbound'], 2)
        c['total'] = round(c['total'], 2)

    risk_tier_share = {
        k: {
            'amount': round(v, 2),
            'share_pct': round((v / total_wire) * 100, 2) if total_wire > 0 else 0.0,
        }
        for k, v in risk_tier_amounts.items()
    }

    return {
        'client_id': client_id,
        'totals': {
            'inbound': round(total_in, 2),
            'outbound': round(total_out, 2),
            'wire_total': round(total_wire, 2),
            'high_risk_total': round(high_risk_total, 2),
            'high_risk_ratio_pct': round((high_risk_total / total_wire) * 100, 2) if total_wire > 0 else 0.0,
            'inflow_outflow_imbalance': round(total_in - total_out, 2),
        },
        'countries': countries,
        'risk_tier_aggregation': risk_tier_share,
        'top_corridors': sorted(corridor_map.values(), key=lambda x: x['amount'], reverse=True)[:10],
    }


@router.get('/analytics/transaction-features/{client_id}')
def transaction_feature_summary(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(Transaction.client_id == client_id)
        .order_by(Transaction.timestamp.desc())
        .limit(5000)
    ).scalars().all()

    type_mix = {}
    direction_mix = {'incoming': 0, 'outgoing': 0}
    channel_mix = {}
    suspicious_flags = {
        'cross_border': 0,
        'weekend': 0,
        'night': 0,
        'recurring': 0,
        'round_amount': 0,
        'high_risk_corridor': 0,
    }

    for t in txs:
        type_mix[t.tx_type] = type_mix.get(t.tx_type, 0) + 1
        direction_mix[t.direction] = direction_mix.get(t.direction, 0) + 1
        channel_mix[t.channel] = channel_mix.get(t.channel, 0) + 1
        tags = t.typology_tags or {}
        suspicious_flags['cross_border'] += int(tags.get('cross_border', 0))
        suspicious_flags['weekend'] += int(tags.get('weekend_flag', 0))
        suspicious_flags['night'] += int(tags.get('night_flag', 0))
        suspicious_flags['recurring'] += int(tags.get('recurring_flag', 0))
        suspicious_flags['round_amount'] += int(tags.get('round_amount_flag', 0))
        suspicious_flags['high_risk_corridor'] += int(tags.get('corridor_risk_tag') == 'high')

    total = len(txs)
    return {
        'client_id': client_id,
        'total_transactions': total,
        'mix': {
            'type': type_mix,
            'direction': direction_mix,
            'channel': channel_mix,
        },
        'suspicious_flags': suspicious_flags,
        'suspicious_ratios_pct': {
            k: round((v / total) * 100, 2) if total > 0 else 0.0 for k, v in suspicious_flags.items()
        },
    }


@router.get('/alerts/outstanding')
def outstanding_alerts(limit: int = Query(20, ge=1, le=200), db: Session = Depends(get_db)):
    alerts = db.execute(
        select(Alert).where(Alert.status != 'Closed').order_by(Alert.created_at.desc()).limit(limit)
    ).scalars().all()
    return [
        {
            'alert_id': a.alert_id,
            'client_id': a.client_id,
            'case_id': a.case_id,
            'severity': a.severity,
            'status': a.status,
            'created_at': a.created_at.isoformat(),
            'description': a.description,
        }
        for a in alerts
    ]


@router.post('/seed')
def seed(req: SeedRequest, db: Session = Depends(get_db)):
    job = enqueue_seed(req.clients, req.tx_per_client, req.batch_size)
    db.merge(SeedJob(job_id=job.id, status='queued', target_clients=req.clients, metadata_json=req.model_dump()))
    db.commit()
    return {'job_id': job.id, 'status': 'queued'}


@router.get('/seed/jobs')
def seed_jobs(limit: int = Query(5, ge=1, le=50), db: Session = Depends(get_db)):
    jobs = db.execute(select(SeedJob).order_by(SeedJob.updated_at.desc()).limit(limit)).scalars().all()
    return [
        {
            'job_id': j.job_id,
            'status': j.status,
            'target_clients': j.target_clients,
            'created_at': j.created_at.isoformat() if j.created_at else None,
            'updated_at': j.updated_at.isoformat() if j.updated_at else None,
            'metadata': j.metadata_json,
        }
        for j in jobs
    ]


@router.get('/seed/{job_id}')
def seed_status(job_id: str, db: Session = Depends(get_db)):
    job = db.get(SeedJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail='Seed job not found')
    return {
        'job_id': job_id,
        'status': job.status,
        'target_clients': job.target_clients,
        'created_at': job.created_at.isoformat() if job.created_at else None,
        'updated_at': job.updated_at.isoformat() if job.updated_at else None,
        'metadata': job.metadata_json,
    }
