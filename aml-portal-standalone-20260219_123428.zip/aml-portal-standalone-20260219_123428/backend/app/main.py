from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router
from app.db.base import Base
from app.core.config import settings
from app.db.session import engine
from app.models import entities  # noqa: F401

app = FastAPI(title='AML Portal API')

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=False,
    allow_methods=['*'],
    allow_headers=['*'],
)


@app.on_event('startup')
def startup():
    if settings.reset_schema_on_start and settings.env == 'local':
        Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)


app.include_router(router, prefix='/api')
