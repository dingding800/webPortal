#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export DATABASE_URL='postgresql+psycopg://aml:aml@localhost:5432/aml_portal'
export REDIS_URL='redis://localhost:6379/0'
export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES
export PYTHONPATH="$ROOT/backend"
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

while true; do
  curl -fsS http://localhost:8001/api/health >/dev/null 2>&1 || nohup "$ROOT/.venv/bin/uvicorn" app.main:app --host 0.0.0.0 --port 8001 >> "$ROOT/tmp_backend.log" 2>&1 &
  pgrep -f 'python -m app.workers.worker' >/dev/null 2>&1 || nohup "$ROOT/.venv/bin/python" -m app.workers.worker >> "$ROOT/tmp_worker.log" 2>&1 &
  curl -fsS http://localhost:5174 >/dev/null 2>&1 || nohup /opt/homebrew/bin/python3 -m http.server 5174 --directory "$ROOT/frontend/dist" >> "$ROOT/tmp_frontend.log" 2>&1 &
  sleep 30
done
