#!/usr/bin/env bash
set -euo pipefail

BASE=${1:-http://localhost:8001/api}

echo "[1] health"
curl -sf "$BASE/health" | jq .

echo "[2] summary"
curl -sf "$BASE/analytics/summary" | jq .

echo "[3] list clients"
RESP=$(curl -sf "$BASE/clients?limit=5")
echo "$RESP" | jq '.items | length'

echo "Smoke test passed"
