from collections import Counter

HIGH_RISK_COUNTRIES = {'IR', 'KP', 'SY', 'RU'}


def evaluate_client(transactions, pep_flag: int, sanctions_flag: int):
    score = 5.0
    hits = Counter()

    total_amt = sum(tx.amount for tx in transactions)
    cash_amt = sum(tx.amount for tx in transactions if tx.tx_type == 'cash')
    wire_amt = sum(tx.amount for tx in transactions if tx.tx_type == 'wire')
    high_risk_geo = sum(1 for tx in transactions if tx.country in HIGH_RISK_COUNTRIES)
    round_amounts = sum(1 for tx in transactions if abs(tx.amount % 1000) < 1e-6)

    if pep_flag:
        score += 25
        hits['pep'] += 1
    if sanctions_flag:
        score += 40
        hits['sanctions'] += 1
    if total_amt > 150000:
        score += 10
        hits['high_volume'] += 1
    if cash_amt > 60000:
        score += 12
        hits['cash_heavy'] += 1
    if wire_amt > 50000:
        score += 8
        hits['wire_heavy'] += 1
    if high_risk_geo >= 3:
        score += 18
        hits['high_risk_geo'] += 1
    if round_amounts >= 4:
        score += 15
        hits['structuring_pattern'] += 1

    score = min(100.0, score)
    explain = f"rules={dict(hits)} total_amt={total_amt:.2f} cash_amt={cash_amt:.2f} wire_amt={wire_amt:.2f}"
    return score, dict(hits), explain
