import random
import uuid
from datetime import date, datetime, timedelta

from faker import Faker
from sqlalchemy import text

from app.models.entities import Client, Transaction, RiskResult
from app.services.risk_engine import evaluate_client

fake = Faker()

TX_TYPES = ['debit', 'credit', 'wire', 'cash', 'card']
SEGMENTS = ['retail', 'mass_affluent', 'private', 'sme']
TYPOLOGIES = [
    'normal_activity',
    'structuring',
    'layering',
    'rapid_in_out',
    'high_risk_corridor',
]


def _cid(i: int) -> str:
    return f'C{i:08d}'


def bulk_seed(db, clients: int = 10000, tx_per_client: int = 8, batch_size: int = 5000):
    # pragma tuning for local bulk inserts
    db.execute(text('SET synchronous_commit TO OFF'))
    created = 0

    for start in range(1, clients + 1, batch_size):
        end = min(start + batch_size, clients + 1)
        client_rows = []
        tx_rows = []
        risk_rows = []

        for i in range(start, end):
            client_id = _cid(i)
            pep = 1 if random.random() < 0.01 else 0
            sanctions = 1 if random.random() < 0.002 else 0
            annual_income = float(max(18000, random.gauss(78000, 52000)))
            c = Client(
                client_id=client_id,
                full_name=fake.name(),
                dob=fake.date_of_birth(minimum_age=18, maximum_age=90),
                gender=random.choice(['M', 'F', 'X']),
                country=fake.country_code(),
                city=fake.city(),
                segment=random.choice(SEGMENTS),
                occupation=fake.job(),
                annual_income=annual_income,
                account_open_date=date.today() - timedelta(days=random.randint(30, 3650)),
                pep_flag=pep,
                sanctions_flag=sanctions,
                profile_text=f"Client {client_id} works as {fake.job()} with {random.choice(['stable', 'seasonal', 'volatile'])} cashflows.",
            )
            client_rows.append(c)

            tx_objs = []
            typology = random.choices(TYPOLOGIES, weights=[80, 6, 6, 5, 3])[0]
            for _ in range(tx_per_client):
                amt = abs(random.gauss(1200, 3500)) + 10
                tx_type = random.choice(TX_TYPES)
                geo = fake.country_code()
                tags = {'typology': typology}
                if typology == 'structuring':
                    amt = random.choice([9000, 9500, 9900])
                    tx_type = 'cash'
                    tags['signal'] = 'near_threshold'
                elif typology == 'layering':
                    tx_type = 'wire'
                    geo = random.choice(['RU', 'SY', 'IR', 'TR', 'AE'])
                elif typology == 'rapid_in_out':
                    tx_type = random.choice(['credit', 'debit'])
                    amt = abs(random.gauss(15000, 8000))
                elif typology == 'high_risk_corridor':
                    tx_type = 'wire'
                    geo = random.choice(['KP', 'IR', 'SY'])

                tx = Transaction(
                    tx_id=uuid.uuid4().hex,
                    client_id=client_id,
                    counterparty_id=_cid(random.randint(1, clients)),
                    tx_type=tx_type,
                    amount=float(round(amt, 2)),
                    currency='USD',
                    channel=random.choice(['branch', 'atm', 'mobile', 'online']),
                    country=geo,
                    timestamp=datetime.utcnow() - timedelta(days=random.randint(0, 365)),
                    typology_tags=tags,
                )
                tx_objs.append(tx)
                tx_rows.append(tx)

            score, hits, explain = evaluate_client(tx_objs, pep, sanctions)
            risk_rows.append(RiskResult(client_id=client_id, risk_score=score, rule_hits=hits, model_reason=explain))

        db.bulk_save_objects(client_rows)
        db.bulk_save_objects(tx_rows)
        db.bulk_save_objects(risk_rows)
        db.commit()
        created += len(client_rows)

    return {'clients': created, 'transactions': created * tx_per_client}
