from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import asc, desc, func, or_, select
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import Client, RiskResult, SeedJob, Transaction
from app.schemas.client import SeedRequest
from app.workers.queue import enqueue_seed

router = APIRouter()


@router.get('/health')
def health(db: Session = Depends(get_db)):
    db.execute(select(1))
    return {'status': 'ok', 'time': datetime.utcnow().isoformat()}


@router.get('/clients')
def list_clients(
    q: str | None = None,
    segment: str | None = None,
    min_risk: float = 0,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    sort_by: str = Query('risk_score'),
    sort_dir: str = Query('desc'),
    db: Session = Depends(get_db),
):
    base_stmt = select(Client, RiskResult).join(RiskResult, RiskResult.client_id == Client.client_id)
    if q:
        like = f'%{q.strip()}%'
        base_stmt = base_stmt.where(
            or_(Client.client_id.ilike(like), Client.full_name.ilike(like), Client.city.ilike(like))
        )
    if segment:
        base_stmt = base_stmt.where(Client.segment == segment)
    if min_risk > 0:
        base_stmt = base_stmt.where(RiskResult.risk_score >= min_risk)

    total = db.execute(select(func.count()).select_from(base_stmt.subquery())).scalar_one()

    sort_columns = {
        'risk_score': RiskResult.risk_score,
        'full_name': Client.full_name,
        'city': Client.city,
        'annual_income': Client.annual_income,
        'client_id': Client.client_id,
    }
    selected_column = sort_columns.get(sort_by, RiskResult.risk_score)
    order_fn = desc if sort_dir.lower() != 'asc' else asc

    offset = (page - 1) * page_size
    rows = db.execute(
        base_stmt.order_by(order_fn(selected_column), Client.client_id.asc()).offset(offset).limit(page_size)
    ).all()

    items = [
        {
            'client_id': c.client_id,
            'full_name': c.full_name,
            'segment': c.segment,
            'country': c.country,
            'city': c.city,
            'annual_income': c.annual_income,
            'risk_score': r.risk_score,
            'profile_text': c.profile_text,
        }
        for c, r in rows
    ]

    pages = max(1, (total + page_size - 1) // page_size)
    return {
        'items': items,
        'page': page,
        'page_size': page_size,
        'total': total,
        'pages': pages,
        'sort_by': sort_by,
        'sort_dir': sort_dir,
    }


@router.get('/clients/{client_id}')
def get_client(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    risk = db.get(RiskResult, client_id)
    txs = db.execute(
        select(Transaction)
        .where(Transaction.client_id == client_id)
        .order_by(Transaction.timestamp.desc())
        .limit(100)
    ).scalars().all()

    return {
        'client': {
            'client_id': client.client_id,
            'full_name': client.full_name,
            'profile_text': client.profile_text,
            'country': client.country,
            'city': client.city,
            'segment': client.segment,
            'annual_income': client.annual_income,
            'dob': client.dob.isoformat(),
            'occupation': client.occupation,
            'pep_flag': client.pep_flag,
            'sanctions_flag': client.sanctions_flag,
        },
        'risk': {
            'risk_score': risk.risk_score if risk else None,
            'rule_hits': risk.rule_hits if risk else {},
            'model_reason': risk.model_reason if risk else '',
        },
        'transactions': [
            {
                'tx_id': t.tx_id,
                'counterparty_id': t.counterparty_id,
                'tx_type': t.tx_type,
                'amount': t.amount,
                'country': t.country,
                'timestamp': t.timestamp.isoformat(),
                'typology_tags': t.typology_tags,
                'channel': t.channel,
                'currency': t.currency,
            }
            for t in txs
        ],
    }


@router.get('/network/{client_id}')
def network(client_id: str, depth: int = 1, db: Session = Depends(get_db)):
    base = db.execute(
        select(Transaction)
        .where(or_(Transaction.client_id == client_id, Transaction.counterparty_id == client_id))
        .order_by(Transaction.timestamp.desc())
        .limit(1000)
    ).scalars().all()

    nodes = {client_id}
    edges = []
    total_amount = 0.0
    for t in base:
        nodes.add(t.client_id)
        nodes.add(t.counterparty_id)
        total_amount += float(t.amount)
        edges.append(
            {
                'source': t.client_id,
                'target': t.counterparty_id,
                'amount': t.amount,
                'tx_type': t.tx_type,
                'timestamp': t.timestamp.isoformat(),
            }
        )

    return {
        'nodes': [{'id': n} for n in nodes],
        'edges': edges[:500],
        'depth': depth,
        'summary': {
            'counterparties': max(0, len(nodes) - 1),
            'connections': len(edges),
            'total_flow': round(total_amount, 2),
        },
    }


@router.get('/analytics/summary')
def summary(db: Session = Depends(get_db)):
    clients = db.scalar(select(func.count()).select_from(Client)) or 0
    txs = db.scalar(select(func.count()).select_from(Transaction)) or 0
    avg_risk = db.scalar(select(func.avg(RiskResult.risk_score))) or 0
    high_risk = db.scalar(select(func.count()).select_from(RiskResult).where(RiskResult.risk_score >= 70)) or 0
    return {'clients': clients, 'transactions': txs, 'avg_risk': round(float(avg_risk), 2), 'high_risk': high_risk}


@router.get('/analytics/segments')
def segments(db: Session = Depends(get_db)):
    rows = db.execute(select(Client.segment, func.count()).group_by(Client.segment).order_by(Client.segment)).all()
    return [{'segment': segment, 'count': count} for segment, count in rows]


@router.post('/seed')
def seed(req: SeedRequest, db: Session = Depends(get_db)):
    job = enqueue_seed(req.clients, req.tx_per_client, req.batch_size)
    db.merge(SeedJob(job_id=job.id, status='queued', target_clients=req.clients, metadata_json=req.model_dump()))
    db.commit()
    return {'job_id': job.id, 'status': 'queued'}


@router.get('/seed/jobs')
def seed_jobs(limit: int = Query(5, ge=1, le=50), db: Session = Depends(get_db)):
    jobs = db.execute(select(SeedJob).order_by(SeedJob.updated_at.desc()).limit(limit)).scalars().all()
    return [
        {
            'job_id': j.job_id,
            'status': j.status,
            'target_clients': j.target_clients,
            'created_at': j.created_at.isoformat() if j.created_at else None,
            'updated_at': j.updated_at.isoformat() if j.updated_at else None,
            'metadata': j.metadata_json,
        }
        for j in jobs
    ]


@router.get('/seed/{job_id}')
def seed_status(job_id: str, db: Session = Depends(get_db)):
    job = db.get(SeedJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail='Seed job not found')
    return {
        'job_id': job_id,
        'status': job.status,
        'target_clients': job.target_clients,
        'created_at': job.created_at.isoformat() if job.created_at else None,
        'updated_at': job.updated_at.isoformat() if job.updated_at else None,
        'metadata': job.metadata_json,
    }
