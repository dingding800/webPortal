from datetime import datetime, date
from sqlalchemy import (
    String, Integer, Float, DateTime, Date, ForeignKey, Text, Index, JSON
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


class Client(Base):
    __tablename__ = 'clients'

    client_id: Mapped[str] = mapped_column(String(24), primary_key=True)
    full_name: Mapped[str] = mapped_column(String(120), index=True)
    dob: Mapped[date] = mapped_column(Date)
    gender: Mapped[str] = mapped_column(String(16), index=True)
    country: Mapped[str] = mapped_column(String(64), index=True)
    city: Mapped[str] = mapped_column(String(64), index=True)
    segment: Mapped[str] = mapped_column(String(32), index=True)
    occupation: Mapped[str] = mapped_column(String(80), default='unknown')
    annual_income: Mapped[float] = mapped_column(Float)
    account_open_date: Mapped[date] = mapped_column(Date)
    pep_flag: Mapped[int] = mapped_column(Integer, default=0)
    sanctions_flag: Mapped[int] = mapped_column(Integer, default=0)
    profile_text: Mapped[str] = mapped_column(Text)

    transactions = relationship('Transaction', back_populates='client', foreign_keys='Transaction.client_id')
    risk = relationship('RiskResult', back_populates='client', uselist=False)


class Transaction(Base):
    __tablename__ = 'transactions'

    tx_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), index=True)
    counterparty_id: Mapped[str] = mapped_column(String(24), index=True)
    tx_type: Mapped[str] = mapped_column(String(16), index=True)  # debit/credit/wire/cash/card
    amount: Mapped[float] = mapped_column(Float, index=True)
    currency: Mapped[str] = mapped_column(String(8), default='USD')
    channel: Mapped[str] = mapped_column(String(24), default='mobile')
    country: Mapped[str] = mapped_column(String(64), index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, index=True)
    typology_tags: Mapped[dict] = mapped_column(JSON, default=dict)

    client = relationship('Client', back_populates='transactions', foreign_keys=[client_id])


class RiskResult(Base):
    __tablename__ = 'risk_results'

    client_id: Mapped[str] = mapped_column(ForeignKey('clients.client_id'), primary_key=True)
    risk_score: Mapped[float] = mapped_column(Float, index=True)
    rule_hits: Mapped[dict] = mapped_column(JSON, default=dict)
    model_reason: Mapped[str] = mapped_column(Text)
    last_updated: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    client = relationship('Client', back_populates='risk')


class SeedJob(Base):
    __tablename__ = 'seed_jobs'

    job_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    status: Mapped[str] = mapped_column(String(16), index=True)
    target_clients: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)


Index('idx_tx_client_time', Transaction.client_id, Transaction.timestamp)
Index('idx_tx_counterparty_time', Transaction.counterparty_id, Transaction.timestamp)
Index('idx_risk_score_desc', RiskResult.risk_score.desc())
