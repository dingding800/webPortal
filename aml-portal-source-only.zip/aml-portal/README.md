# Local AML Portal (Mac mini)

Production-style local stack:
- FastAPI backend + Postgres + Redis + RQ worker
- React frontend dashboard (search, pagination, detail, network, seed job visibility)

## Run locally (recommended on this host)

```bash
cd /Users/dingceliu/.openclaw/workspace/aml-portal
make local-up
```

Open:
- Frontend: http://localhost:5174
- API docs: http://localhost:8001/docs

## End-to-end quick test

```bash
# 1) verify API
make smoke

# 2) queue seed sample
curl -X POST http://localhost:8001/api/seed \
  -H 'Content-Type: application/json' \
  -d '{"clients":3000,"tx_per_client":10,"batch_size":1000}'

# 3) monitor job
curl http://localhost:8001/api/seed/jobs | jq .

# 4) test search/pagination
curl 'http://localhost:8001/api/clients?page=1&page_size=25&sort_by=risk_score&sort_dir=desc' | jq '.total, (.items|length)'

# 5) open one client detail
CID=$(curl -s 'http://localhost:8001/api/clients?page=1&page_size=1' | jq -r '.items[0].client_id')
curl "http://localhost:8001/api/clients/$CID" | jq '.client.client_id, (.transactions|length)'
curl "http://localhost:8001/api/network/$CID" | jq '.summary'
```

## Major API endpoints
- `GET /api/clients?q=&segment=&min_risk=&page=&page_size=&sort_by=&sort_dir=`
- `GET /api/clients/{id}`
- `GET /api/network/{id}`
- `GET /api/analytics/summary`
- `GET /api/analytics/segments`
- `POST /api/seed`
- `GET /api/seed/{job_id}`
- `GET /api/seed/jobs`

## Troubleshooting

### Frontend loads but actions look broken
Likely causes:
1. Backend was not started with app import path (`ModuleNotFoundError: app`)
2. Vite moved to another port because 5174 was occupied
3. Browser CORS blocking API requests

Fix:
```bash
# restart stack using project script
make local-up

# inspect logs
tail -n 120 tmp_backend.log
tail -n 120 tmp_worker.log
tail -n 120 tmp_frontend.log
```

### Seed job queued but no data appears
- Ensure worker is running (`tmp_worker.log` should show queue listening)
- Check latest job state: `curl http://localhost:8001/api/seed/jobs | jq .`
- Wait for status `finished`, then refresh the frontend.

### API returns empty results
- No data has been seeded yet. Queue seed from UI or `/api/seed` endpoint.

---

For Docker users:
```bash
make up
```
(then use same URLs above)
