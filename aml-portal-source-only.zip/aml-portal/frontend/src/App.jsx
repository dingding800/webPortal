import { useEffect, useMemo, useState } from 'react'
import api from './api/client'

const SEGMENT_ALL = 'all'

const SAMPLE_SEED = { clients: 3000, tx_per_client: 10, batch_size: 1000 }

const fmtMoney = (v) => `$${Number(v || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}`

function Toasts({ items, remove }) {
  return (
    <div className='toast-wrap'>
      {items.map((t) => (
        <div key={t.id} className={`toast ${t.type}`}>
          <div>{t.text}</div>
          <button onClick={() => remove(t.id)}>×</button>
        </div>
      ))}
    </div>
  )
}

export default function App() {
  const [summary, setSummary] = useState(null)
  const [segments, setSegments] = useState([])
  const [jobs, setJobs] = useState([])
  const [clients, setClients] = useState([])
  const [clientMeta, setClientMeta] = useState({ page: 1, pages: 1, total: 0, page_size: 25 })

  const [q, setQ] = useState('')
  const [segment, setSegment] = useState(SEGMENT_ALL)
  const [minRisk, setMinRisk] = useState(0)
  const [sortBy, setSortBy] = useState('risk_score')
  const [sortDir, setSortDir] = useState('desc')
  const [page, setPage] = useState(1)

  const [selected, setSelected] = useState(null)
  const [network, setNetwork] = useState(null)

  const [loadingDashboard, setLoadingDashboard] = useState(false)
  const [loadingClients, setLoadingClients] = useState(false)
  const [loadingDetail, setLoadingDetail] = useState(false)
  const [error, setError] = useState('')
  const [retryAction, setRetryAction] = useState(null)

  const [seeding, setSeeding] = useState(false)
  const [activeSeedJob, setActiveSeedJob] = useState(null)

  const [toasts, setToasts] = useState([])

  const pushToast = (type, text) => {
    const id = crypto.randomUUID()
    setToasts((t) => [...t, { id, type, text }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000)
  }

  const removeToast = (id) => setToasts((t) => t.filter((x) => x.id !== id))

  const withApi = async (fn, fallbackError, retryFn) => {
    try {
      setError('')
      return await fn()
    } catch (e) {
      const msg = e?.response?.data?.detail || e.message || fallbackError
      setError(msg)
      setRetryAction(() => retryFn)
      pushToast('error', msg)
      throw e
    }
  }

  const loadDashboard = async () => {
    setLoadingDashboard(true)
    try {
      const [s, seg, latestJobs] = await withApi(
        () => Promise.all([api.get('/analytics/summary'), api.get('/analytics/segments'), api.get('/seed/jobs?limit=5')]),
        'Failed to load dashboard',
        loadDashboard,
      )
      setSummary(s.data)
      setSegments(seg.data)
      setJobs(latestJobs.data)
    } finally {
      setLoadingDashboard(false)
    }
  }

  const loadClients = async (nextPage = page) => {
    setLoadingClients(true)
    try {
      const res = await withApi(
        () =>
          api.get('/clients', {
            params: {
              q: q || undefined,
              segment: segment === SEGMENT_ALL ? undefined : segment,
              min_risk: minRisk || 0,
              page: nextPage,
              page_size: 25,
              sort_by: sortBy,
              sort_dir: sortDir,
            },
          }),
        'Failed to load clients',
        () => loadClients(nextPage),
      )
      setClients(res.data.items)
      setClientMeta(res.data)
      setPage(res.data.page)
      if (res.data.items.length === 0) {
        setSelected(null)
        setNetwork(null)
      }
    } finally {
      setLoadingClients(false)
    }
  }

  const openClient = async (id) => {
    setLoadingDetail(true)
    try {
      const [detail, net] = await withApi(
        () => Promise.all([api.get(`/clients/${id}`), api.get(`/network/${id}`)]),
        'Failed to load client details',
        () => openClient(id),
      )
      setSelected(detail.data)
      setNetwork(net.data)
      pushToast('success', `Loaded ${detail.data.client.full_name}`)
    } finally {
      setLoadingDetail(false)
    }
  }

  const queueSeed = async () => {
    setSeeding(true)
    try {
      const res = await withApi(
        () => api.post('/seed', SAMPLE_SEED),
        'Unable to queue seed job',
        queueSeed,
      )
      setActiveSeedJob(res.data.job_id)
      pushToast('success', `Seed job queued (${res.data.job_id.slice(0, 8)})`)
      await loadDashboard()
    } finally {
      setSeeding(false)
    }
  }

  useEffect(() => {
    loadDashboard()
    loadClients(1)
  }, [])

  useEffect(() => {
    if (!activeSeedJob) return
    const timer = setInterval(async () => {
      try {
        const { data } = await api.get(`/seed/${activeSeedJob}`)
        if (['finished', 'failed'].includes(data.status)) {
          setActiveSeedJob(null)
          pushToast(data.status === 'finished' ? 'success' : 'error', `Seed job ${data.status}`)
          await loadDashboard()
          await loadClients(1)
        }
      } catch {
        // quiet polling
      }
    }, 3000)
    return () => clearInterval(timer)
  }, [activeSeedJob])

  const latestJob = useMemo(() => jobs[0], [jobs])

  return (
    <div className='app'>
      <Toasts items={toasts} remove={removeToast} />
      <header className='topbar'>
        <div>
          <h1>AML Investigation Console</h1>
          <p>Client risk screening, transaction review, and network monitoring</p>
        </div>
        <div className='top-actions'>
          <button className='primary' onClick={queueSeed} disabled={seeding}>{seeding ? 'Queueing…' : 'Queue Sample Seed'}</button>
          <button onClick={() => { loadDashboard(); loadClients(page) }}>Refresh</button>
        </div>
      </header>

      {error && (
        <div className='alert error'>
          <span>{error}</span>
          {retryAction && <button onClick={() => retryAction()}>Retry</button>}
        </div>
      )}

      <div className='layout'>
        <aside className='sidebar'>
          <h3>Navigation</h3>
          <ul>
            <li>Dashboard</li>
            <li>Client Search</li>
            <li>Risk Cases</li>
            <li>Seed Jobs</li>
          </ul>

          <div className='card'>
            <h4>Seed Job Status</h4>
            {loadingDashboard && !latestJob ? <p>Loading…</p> : latestJob ? (
              <>
                <p><b>Status:</b> <span className={`badge ${latestJob.status}`}>{latestJob.status}</span></p>
                <p><b>Target Clients:</b> {latestJob.target_clients}</p>
                <p><b>Updated:</b> {latestJob.updated_at?.replace('T', ' ').slice(0, 19)}</p>
              </>
            ) : <p>No jobs yet.</p>}
            {activeSeedJob && <p>Polling active job…</p>}
          </div>
        </aside>

        <main className='content'>
          <section className='kpis'>
            {['clients', 'transactions', 'avg_risk', 'high_risk'].map((k) => (
              <div key={k} className='card kpi'>
                <div className='muted'>{k.replace('_', ' ').toUpperCase()}</div>
                <div className='kpi-value'>
                  {loadingDashboard && !summary ? '—' : summary ? (k.includes('risk') ? summary[k] : Number(summary[k]).toLocaleString()) : 0}
                </div>
              </div>
            ))}
          </section>

          <section className='card filters'>
            <h3>Search & Filters</h3>
            <div className='grid'>
              <input placeholder='Search name, ID, city' value={q} onChange={(e) => setQ(e.target.value)} />
              <select value={segment} onChange={(e) => setSegment(e.target.value)}>
                <option value={SEGMENT_ALL}>All segments</option>
                {segments.map((s) => <option key={s.segment} value={s.segment}>{s.segment} ({s.count})</option>)}
              </select>
              <input type='number' min='0' max='100' value={minRisk} onChange={(e) => setMinRisk(Number(e.target.value || 0))} placeholder='Min risk' />
              <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
                <option value='risk_score'>Sort: Risk</option>
                <option value='full_name'>Sort: Name</option>
                <option value='city'>Sort: City</option>
                <option value='annual_income'>Sort: Income</option>
              </select>
              <select value={sortDir} onChange={(e) => setSortDir(e.target.value)}>
                <option value='desc'>Desc</option>
                <option value='asc'>Asc</option>
              </select>
              <button className='primary' onClick={() => loadClients(1)}>Apply</button>
            </div>
          </section>

          <section className='split'>
            <div className='card'>
              <h3>Client Results</h3>
              {loadingClients ? <p>Loading clients…</p> : clients.length === 0 ? <p>No clients match filters. Try lowering min risk or clearing query.</p> : (
                <>
                  <table>
                    <thead><tr><th>ID</th><th>Name</th><th>Segment</th><th>City</th><th>Risk</th><th /></tr></thead>
                    <tbody>
                      {clients.map((c) => (
                        <tr key={c.client_id}>
                          <td>{c.client_id}</td>
                          <td>{c.full_name}</td>
                          <td>{c.segment}</td>
                          <td>{c.city}, {c.country}</td>
                          <td>{c.risk_score}</td>
                          <td><button onClick={() => openClient(c.client_id)}>Open</button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <div className='pager'>
                    <button disabled={page <= 1} onClick={() => loadClients(page - 1)}>Prev</button>
                    <span>Page {clientMeta.page} / {clientMeta.pages} ({clientMeta.total.toLocaleString()} total)</span>
                    <button disabled={page >= clientMeta.pages} onClick={() => loadClients(page + 1)}>Next</button>
                  </div>
                </>
              )}
            </div>

            <div className='card'>
              <h3>Client Detail</h3>
              {loadingDetail ? <p>Loading detail…</p> : !selected ? <p>Select a client from results to inspect profile and activity.</p> : (
                <>
                  <p><b>{selected.client.full_name}</b> ({selected.client.client_id})</p>
                  <p>{selected.client.city}, {selected.client.country} • {selected.client.segment} • {fmtMoney(selected.client.annual_income)} income</p>
                  <p>{selected.client.profile_text}</p>
                  <p><b>Risk Score:</b> {selected.risk.risk_score} | <b>Explainability:</b> {selected.risk.model_reason || 'Rule-based risk blend'}</p>
                  <p><b>Rule Hits:</b> {JSON.stringify(selected.risk.rule_hits)}</p>

                  <h4>Recent Transactions</h4>
                  <ul className='tx-list'>
                    {selected.transactions.slice(0, 12).map((t) => (
                      <li key={t.tx_id}>
                        <span className={`badge tx ${t.tx_type}`}>{t.tx_type}</span> {fmtMoney(t.amount)} {t.currency} to {t.counterparty_id} ({t.country})
                      </li>
                    ))}
                  </ul>

                  <h4>Network Summary</h4>
                  {network ? (
                    <p>
                      Nodes: {network.nodes.length} • Connections: {network.summary?.connections ?? network.edges.length} • Total flow: {fmtMoney(network.summary?.total_flow)}
                    </p>
                  ) : <p>No network data available.</p>}
                </>
              )}
            </div>
          </section>
        </main>
      </div>
    </div>
  )
}
