export const TX_SUMMARY_CATEGORIES = [
  { key: 'wire', label: 'wire' },
  { key: 'emt', label: 'emt' },
  { key: 'grocery', label: 'grocery' },
  { key: 'online_shopping', label: 'online shopping' },
  { key: 'utilities', label: 'utilities' },
  { key: 'preauth_government', label: 'pre authorized transactions- government' },
  { key: 'preauth_salary', label: 'pre authorized transaction-salary' },
  { key: 'preauth_others', label: 'pre authorized transaction-others' },
  { key: 'other', label: 'Other' },
]

const normalize = (value) => String(value || '').toLowerCase().replace(/[_-]+/g, ' ').trim()

const hasAnyToken = (haystack, tokens) => tokens.some((token) => haystack.includes(token))

export function classifyTransactionSummaryCategory(tx = {}) {
  const txType = normalize(tx.tx_type)
  const channel = normalize(tx.channel)
  const purpose = normalize(tx.purpose_code || tx.typology_tags?.purpose_code)
  const flags = Array.isArray(tx.flags) ? tx.flags.map(normalize).join(' ') : ''
  const counterparty = normalize(tx.counterparty_id)
  const text = `${purpose} ${flags} ${counterparty} ${channel}`

  if (txType === 'wire') return 'wire'
  if (txType === 'emt') return 'emt'

  const isPreAuthorized = hasAnyToken(text, ['pre authorized', 'pre-authorized', 'preauthorized', 'pad', 'autopay', 'recurring'])

  if (isPreAuthorized && hasAnyToken(text, ['government', 'tax', 'cra', 'service canada', 'benefit', 'cpp', 'ei'])) {
    return 'preauth_government'
  }

  if (isPreAuthorized && hasAnyToken(text, ['salary', 'payroll', 'wage', 'pension'])) {
    return 'preauth_salary'
  }

  if (hasAnyToken(text, ['grocery', 'supermarket', 'food market', 'grocer'])) {
    return 'grocery'
  }

  const cardLike = ['card', 'credit', 'debit'].includes(txType)
  if (hasAnyToken(text, ['online shopping', 'online purchase', 'ecommerce', 'e commerce', 'amazon', 'shopify']) || (cardLike && channel === 'online')) {
    return 'online_shopping'
  }

  if (hasAnyToken(text, ['utility', 'utilities', 'hydro', 'electric', 'water', 'gas', 'internet', 'phone', 'mobile', 'cable'])) {
    return 'utilities'
  }

  if (isPreAuthorized) return 'preauth_others'
  return null
}

export function aggregateTransactionsBySummaryCategory(transactions = []) {
  const counts = Object.fromEntries(TX_SUMMARY_CATEGORIES.map((row) => [row.key, 0]))
  for (const tx of transactions) {
    const category = classifyTransactionSummaryCategory(tx)
    const bucket = category && category in counts ? category : 'other'
    counts[bucket] += 1
  }

  const total = transactions.length
  const rows = TX_SUMMARY_CATEGORIES.map((row) => {
    const count = counts[row.key]
    const pct = total > 0 ? Number(((count / total) * 100).toFixed(2)) : 0
    return { ...row, count, pct }
  })
  const categorized = rows.reduce((sum, row) => sum + row.count, 0)

  return {
    total,
    categorized,
    uncategorized: Math.max(0, total - categorized),
    rows,
  }
}
