#!/usr/bin/env python3
"""
Sync production AML data into local aml_portal.db.

Usage example:
  python bridge_production_to_aml_portal.py \
    --source-url "postgresql+psycopg://user:pass@host:5432/prod_aml" \
    --target-url "sqlite:///./backend/data/aml_portal.db"

Notes:
- Copies rows for matching tables/columns only.
- Performs UPSERT on target PK.
- Safe to rerun incrementally (idempotent by primary key).
"""

from __future__ import annotations

import argparse
from typing import Iterable

from sqlalchemy import MetaData, Table, create_engine, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

DEFAULT_TABLES = [
    "clients",
    "transactions",
    "risk_results",
    "client_name_history",
    "client_address_history",
    "client_phone_history",
    "world_check_hits",
    "cases",
    "case_notes",
    "alerts",
    "segment_codes",
    "review_decisions",
    "risk_decision_logs",
    "login_activity",
]


def batched(iterable: Iterable[dict], n: int):
    batch = []
    for item in iterable:
        batch.append(item)
        if len(batch) >= n:
            yield batch
            batch = []
    if batch:
        yield batch


def upsert_rows(conn, table: Table, rows: list[dict]):
    if not rows:
        return 0

    pk_cols = [c.name for c in table.primary_key.columns]
    if not pk_cols:
        conn.execute(table.insert(), rows)
        return len(rows)

    dialect = conn.engine.dialect.name
    mutable_cols = [c.name for c in table.columns if c.name not in pk_cols]

    if dialect == "sqlite":
        stmt = sqlite_insert(table).values(rows)
        update_map = {c: getattr(stmt.excluded, c) for c in mutable_cols}
        stmt = stmt.on_conflict_do_update(index_elements=pk_cols, set_=update_map)
        conn.execute(stmt)
        return len(rows)

    if dialect in {"postgres", "postgresql"}:
        stmt = pg_insert(table).values(rows)
        update_map = {c: getattr(stmt.excluded, c) for c in mutable_cols}
        stmt = stmt.on_conflict_do_update(index_elements=pk_cols, set_=update_map)
        conn.execute(stmt)
        return len(rows)

    # Fallback for other dialects: delete+insert by PK
    for row in rows:
        where = [table.c[k] == row[k] for k in pk_cols if k in row]
        if where:
            conn.execute(table.delete().where(*where))
        conn.execute(table.insert().values(**row))
    return len(rows)


def sync_table(source_conn, target_conn, source_tbl: Table, target_tbl: Table, batch_size: int) -> int:
    source_cols = {c.name for c in source_tbl.columns}
    target_cols = {c.name for c in target_tbl.columns}
    common_cols = [c for c in target_tbl.columns.keys() if c in source_cols and c in target_cols]

    if not common_cols:
        return 0

    stmt = select(*[source_tbl.c[c] for c in common_cols])
    total = 0
    result = source_conn.execute(stmt)

    def row_iter():
        for row in result:
            yield {k: row[k] for k in common_cols}

    for chunk in batched(row_iter(), batch_size):
        total += upsert_rows(target_conn, target_tbl, chunk)

    return total


def main():
    parser = argparse.ArgumentParser(description="Bridge production AML data into aml_portal.db")
    parser.add_argument("--source-url", required=True, help="SQLAlchemy URL for production/source DB")
    parser.add_argument(
        "--target-url",
        default="sqlite:///./backend/data/aml_portal.db",
        help="SQLAlchemy URL for target AML portal DB (default: sqlite:///./backend/data/aml_portal.db)",
    )
    parser.add_argument(
        "--tables",
        default=",".join(DEFAULT_TABLES),
        help="Comma-separated table list to sync",
    )
    parser.add_argument("--batch-size", type=int, default=1000)
    args = parser.parse_args()

    table_names = [t.strip() for t in args.tables.split(",") if t.strip()]

    source_engine = create_engine(args.source_url)
    target_engine = create_engine(args.target_url)

    source_md = MetaData()
    target_md = MetaData()

    with source_engine.connect() as source_conn, target_engine.begin() as target_conn:
        source_md.reflect(bind=source_conn)
        target_md.reflect(bind=target_conn)

        print(f"Source dialect: {source_engine.dialect.name}")
        print(f"Target dialect: {target_engine.dialect.name}")

        for name in table_names:
            if name not in source_md.tables:
                print(f"[SKIP] {name}: missing in source")
                continue
            if name not in target_md.tables:
                print(f"[SKIP] {name}: missing in target")
                continue

            count = sync_table(
                source_conn,
                target_conn,
                source_md.tables[name],
                target_md.tables[name],
                args.batch_size,
            )
            print(f"[OK] {name}: upserted {count} rows")

    print("Done.")


if __name__ == "__main__":
    main()
