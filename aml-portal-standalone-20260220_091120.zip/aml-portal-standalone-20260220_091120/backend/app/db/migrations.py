from __future__ import annotations

from sqlalchemy import inspect, text

SEGMENT_CODE_SEED = [
    ('FSRPEP', 'Foreign senior political exposure'),
    ('GAMBLE', 'Gambling / gaming exposure'),
    ('CASHINTENSIVE', 'Cash-intensive business behavior'),
    ('PPP', 'Public-private partnership exposure'),
    ('NONPROFIT', 'Non-profit organization'),
    ('ARMSDEALER', 'Arms / defense dealer'),
    ('AUTODEALER', 'Auto dealer profile'),
    ('WLATM', 'White-label ATM operator'),
    ('EMBASSY', 'Embassy / diplomatic links'),
    ('MSB', 'Money services business'),
    ('CRYPTO', 'Crypto-fiat activity'),
    ('HIGHRISKGEO', 'High-risk geography corridor'),
]


def _column_names(conn, table_name: str) -> set[str]:
    insp = inspect(conn)
    if table_name not in insp.get_table_names():
        return set()
    return {c['name'] for c in insp.get_columns(table_name)}


def ensure_schema_compatibility(engine) -> None:
    """Lightweight runtime migration helper for local/dev compatibility."""
    with engine.begin() as conn:
        dialect = conn.dialect.name

        client_columns = _column_names(conn, 'clients')
        if client_columns:
            client_additions = {
                'client_type': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN client_type VARCHAR(32)",
                    'sqlite': "ALTER TABLE clients ADD COLUMN client_type TEXT",
                    'default': "ALTER TABLE clients ADD COLUMN client_type VARCHAR(32)",
                },
                'resident_country': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN resident_country VARCHAR(64)",
                    'sqlite': "ALTER TABLE clients ADD COLUMN resident_country TEXT",
                    'default': "ALTER TABLE clients ADD COLUMN resident_country VARCHAR(64)",
                },
                'profile_ids': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN profile_ids JSON",
                    'sqlite': "ALTER TABLE clients ADD COLUMN profile_ids JSON",
                    'default': "ALTER TABLE clients ADD COLUMN profile_ids JSON",
                },
                'current_segment_codes': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN current_segment_codes JSON",
                    'sqlite': "ALTER TABLE clients ADD COLUMN current_segment_codes JSON",
                    'default': "ALTER TABLE clients ADD COLUMN current_segment_codes JSON",
                },
                'entity_bsc_code': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN entity_bsc_code VARCHAR(40)",
                    'sqlite': "ALTER TABLE clients ADD COLUMN entity_bsc_code TEXT",
                    'default': "ALTER TABLE clients ADD COLUMN entity_bsc_code VARCHAR(40)",
                },
                'entity_aml_business_type_code': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN entity_aml_business_type_code VARCHAR(40)",
                    'sqlite': "ALTER TABLE clients ADD COLUMN entity_aml_business_type_code TEXT",
                    'default': "ALTER TABLE clients ADD COLUMN entity_aml_business_type_code VARCHAR(40)",
                },
                'entity_sic_code': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN entity_sic_code VARCHAR(40)",
                    'sqlite': "ALTER TABLE clients ADD COLUMN entity_sic_code TEXT",
                    'default': "ALTER TABLE clients ADD COLUMN entity_sic_code VARCHAR(40)",
                },
                'registration_country': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN registration_country VARCHAR(64)",
                    'sqlite': "ALTER TABLE clients ADD COLUMN registration_country TEXT",
                    'default': "ALTER TABLE clients ADD COLUMN registration_country VARCHAR(64)",
                },
                'domicile_country': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN domicile_country VARCHAR(64)",
                    'sqlite': "ALTER TABLE clients ADD COLUMN domicile_country TEXT",
                    'default': "ALTER TABLE clients ADD COLUMN domicile_country VARCHAR(64)",
                },
                'incorporation_country': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN incorporation_country VARCHAR(64)",
                    'sqlite': "ALTER TABLE clients ADD COLUMN incorporation_country TEXT",
                    'default': "ALTER TABLE clients ADD COLUMN incorporation_country VARCHAR(64)",
                },
                'signing_officer': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN signing_officer VARCHAR(120)",
                    'sqlite': "ALTER TABLE clients ADD COLUMN signing_officer TEXT",
                    'default': "ALTER TABLE clients ADD COLUMN signing_officer VARCHAR(120)",
                },
                'entity_owners': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN entity_owners JSON",
                    'sqlite': "ALTER TABLE clients ADD COLUMN entity_owners JSON",
                    'default': "ALTER TABLE clients ADD COLUMN entity_owners JSON",
                },
                'entity_risk_profile': {
                    'postgresql': "ALTER TABLE clients ADD COLUMN entity_risk_profile JSON",
                    'sqlite': "ALTER TABLE clients ADD COLUMN entity_risk_profile JSON",
                    'default': "ALTER TABLE clients ADD COLUMN entity_risk_profile JSON",
                },
            }
            for column_name, ddl_map in client_additions.items():
                if column_name not in client_columns:
                    conn.execute(text(ddl_map.get(dialect, ddl_map['default'])))

        alert_columns = _column_names(conn, 'alerts')
        if alert_columns and 'flags' not in alert_columns:
            if dialect == 'sqlite':
                conn.execute(text('ALTER TABLE alerts ADD COLUMN flags JSON'))
            else:
                conn.execute(text('ALTER TABLE alerts ADD COLUMN flags JSON'))

        conn.execute(text(
            """
            CREATE TABLE IF NOT EXISTS segment_codes (
                code VARCHAR(40) PRIMARY KEY,
                description VARCHAR(200) NOT NULL,
                active INTEGER DEFAULT 1,
                display_order INTEGER DEFAULT 0
            )
            """
        ))

        conn.execute(text(
            """
            CREATE TABLE IF NOT EXISTS review_decisions (
                decision_id VARCHAR(48) PRIMARY KEY,
                client_id VARCHAR(24) NOT NULL,
                username VARCHAR(80) NOT NULL,
                risk_level VARCHAR(16) NOT NULL,
                segment_codes JSON,
                description TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        ))

        conn.execute(text(
            'CREATE INDEX IF NOT EXISTS idx_review_decision_client_time '
            'ON review_decisions (client_id, created_at DESC)'
        ))



def ensure_segment_code_seed(conn) -> None:
    for idx, (code, description) in enumerate(SEGMENT_CODE_SEED, start=1):
        conn.execute(
            text(
                """
                INSERT INTO segment_codes (code, description, active, display_order)
                VALUES (:code, :description, 1, :display_order)
                ON CONFLICT (code) DO UPDATE
                SET description = EXCLUDED.description,
                    active = EXCLUDED.active,
                    display_order = EXCLUDED.display_order
                """
            ),
            {'code': code, 'description': description, 'display_order': idx},
        )
