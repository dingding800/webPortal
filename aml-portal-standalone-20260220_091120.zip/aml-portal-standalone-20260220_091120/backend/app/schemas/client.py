from datetime import date, datetime
from pydantic import BaseModel, Field


class ClientOut(BaseModel):
    client_id: str
    full_name: str
    dob: date
    gender: str
    country: str
    city: str
    segment: str
    annual_income: float
    profile_text: str

    class Config:
        from_attributes = True


class TransactionOut(BaseModel):
    tx_id: str
    client_id: str
    counterparty_id: str
    tx_type: str
    amount: float
    currency: str
    channel: str
    country: str
    timestamp: datetime
    typology_tags: dict

    class Config:
        from_attributes = True


class RiskOut(BaseModel):
    client_id: str
    risk_score: float
    rule_hits: dict
    model_reason: str

    class Config:
        from_attributes = True


class SeedRequest(BaseModel):
    clients: int = 6000
    tx_per_client: int = 24
    batch_size: int = 600


class RiskDecisionRequest(BaseModel):
    action: str
    reason: str


class ReviewDecisionRequest(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    risk_level: str
    segment_codes: list[str] = Field(default_factory=list)
    description: str = Field(min_length=1)


class CaseStatusUpdateRequest(BaseModel):
    status: str
    reason: str
