import csv
import io
import uuid
from collections import defaultdict, deque
from datetime import date, datetime, time

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import asc, case, desc, func, or_, select
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.entities import (
    Alert,
    Case,
    CaseNote,
    Client,
    ClientAddressHistory,
    ClientNameHistory,
    ClientPhoneHistory,
    LoginActivity,
    ReviewDecision,
    RiskDecisionLog,
    RiskResult,
    SeedJob,
    SegmentCode,
    Transaction,
    WorldCheckHit,
)
from app.schemas.client import CaseStatusUpdateRequest, ReviewDecisionRequest, RiskDecisionRequest, SeedRequest
from app.workers.queue import enqueue_seed

router = APIRouter()

ALLOWED_SEGMENTS = {
    'white label ATM',
    'payment processor',
    'non profit',
    'gambling',
    'small business',
    'public company',
    'personal investment',
}
ALLOWED_CASE_STATUSES = {'Open', 'Investigating', 'RFI', 'Close'}
ALLOWED_RISK_LEVELS = ['Standard', 'Medium', 'High1', 'High2', 'High3']
ALLOWED_CLIENT_TYPES = ['personal', 'professional', 'small_business', 'commercial']
RISK_LEVEL_SORT_ORDER = {'Standard': 1, 'Medium': 2, 'High1': 3, 'High2': 4, 'High3': 5}
INDIVIDUAL_CLIENT_TYPES = {'personal', 'professional'}

COUNTRY_DISPLAY_NAMES = {
    'US': 'United States',
    'CA': 'Canada',
    'GB': 'United Kingdom',
    'DE': 'Germany',
    'FR': 'France',
    'AU': 'Australia',
    'JP': 'Japan',
    'MX': 'Mexico',
    'BR': 'Brazil',
    'TR': 'Türkiye',
    'AE': 'United Arab Emirates',
    'IN': 'India',
    'NG': 'Nigeria',
    'RU': 'Russia',
    'IR': 'Iran',
    'SY': 'Syria',
    'KP': 'North Korea',
    'AF': 'Afghanistan',
    'VE': 'Venezuela',
}


def country_name(country_code: str | None) -> str:
    if not country_code:
        return ''
    return COUNTRY_DISPLAY_NAMES.get(country_code, country_code)


def _fmt_dt(value):
    return value.isoformat() if value else None


def _age_from_dob(dob: date | None) -> int | None:
    if not dob:
        return None
    today = date.today()
    years = today.year - dob.year
    if (today.month, today.day) < (dob.month, dob.day):
        years -= 1
    return max(0, years)


def _risk_rating_order_expr(column):
    whens = {level: order for level, order in RISK_LEVEL_SORT_ORDER.items()}
    return case(whens, value=column, else_=999)


def _normalize_segment_codes(raw_codes) -> list[str]:
    seen = set()
    out = []
    for raw in raw_codes or []:
        code = (raw or '').strip().upper()
        if not code or code in seen:
            continue
        seen.add(code)
        out.append(code)
    return out


def _group_login_country_runs(rows: list[LoginActivity]) -> list[dict]:
    if not rows:
        return []

    grouped = []
    current = None
    for row in rows:
        ctry = row.ip_country
        if current and current['country'] == ctry:
            current['end_at'] = row.logged_in_at
            current['login_count'] += 1
            current['failed_count'] += int((row.status or '').lower() == 'failed')
            current['channels'].add(row.channel)
            continue

        if current:
            grouped.append(current)
        current = {
            'country': ctry,
            'country_name': country_name(ctry),
            'start_at': row.logged_in_at,
            'end_at': row.logged_in_at,
            'login_count': 1,
            'failed_count': int((row.status or '').lower() == 'failed'),
            'channels': {row.channel} if row.channel else set(),
        }

    if current:
        grouped.append(current)

    out = []
    for idx, g in enumerate(grouped, start=1):
        out.append(
            {
                'run_id': f'country-run-{idx}',
                'country': g['country'],
                'country_name': g['country_name'],
                'start_at': g['start_at'].isoformat(),
                'end_at': g['end_at'].isoformat(),
                'start_date': g['start_at'].date().isoformat(),
                'end_date': g['end_at'].date().isoformat(),
                'period': f"{g['start_at'].date().isoformat()} - {g['end_at'].date().isoformat()}",
                'login_count': g['login_count'],
                'failed_count': g['failed_count'],
                'channels': sorted([c for c in g['channels'] if c]),
            }
        )
    return out


def _aggregate_alert_flags(alerts: list[Alert]) -> dict:
    transaction_flags: dict[str, dict] = {}
    profile_flags: dict[str, dict] = {}

    severity_order = {'Low': 1, 'Medium': 2, 'High': 3}

    def merge(target: dict[str, dict], row: dict):
        code = row.get('code') or row.get('label') or 'UNKNOWN'
        existing = target.get(code)
        severity = row.get('severity', 'Medium')
        payload = {
            'code': code,
            'label': row.get('label') or code,
            'severity': severity,
            'source_alerts': [row.get('source_alert_id')] if row.get('source_alert_id') else [],
        }
        if not existing:
            target[code] = payload
            return
        if severity_order.get(severity, 0) > severity_order.get(existing.get('severity', ''), 0):
            existing['severity'] = severity
        if row.get('source_alert_id') and row.get('source_alert_id') not in existing['source_alerts']:
            existing['source_alerts'].append(row['source_alert_id'])

    for alert in alerts:
        flags = alert.flags or {}
        for f in flags.get('transaction_flags', []):
            merge(transaction_flags, {**f, 'source_alert_id': alert.alert_id})
        for f in flags.get('profile_flags', []):
            merge(profile_flags, {**f, 'source_alert_id': alert.alert_id})

    severity_order = {'High': 0, 'Medium': 1, 'Low': 2}
    return {
        'transaction_flags': sorted(transaction_flags.values(), key=lambda x: (severity_order.get(x['severity'], 9), x['label'])),
        'profile_flags': sorted(profile_flags.values(), key=lambda x: (severity_order.get(x['severity'], 9), x['label'])),
    }


def _derive_flag_summary_from_profile_and_transactions(client: Client, txs: list[Transaction]) -> dict:
    tx_flags = []
    profile_flags = []

    # Derive robust transaction flags from typology_tags (works even when alert.flags is empty).
    counters = {
        'cross_border': 0,
        'round_amount': 0,
        'near_threshold': 0,
        'weekend': 0,
        'night': 0,
        'recurring': 0,
        'high_risk_corridor': 0,
        'burst_signal': 0,
    }

    for t in txs:
        tags = t.typology_tags or {}
        counters['cross_border'] += int(bool(tags.get('cross_border')))
        counters['round_amount'] += int(bool(tags.get('round_amount_flag')))
        counters['near_threshold'] += int(bool(tags.get('near_threshold_flag')))
        counters['weekend'] += int(bool(tags.get('weekend_flag')))
        counters['night'] += int(bool(tags.get('night_flag')))
        counters['recurring'] += int(bool(tags.get('recurring_flag')))
        counters['high_risk_corridor'] += int(tags.get('corridor_risk_tag') == 'high' or tags.get('wire_country_risk') == 'high')
        counters['burst_signal'] += int(bool(tags.get('burst_signal')))

    def add_tx(code: str, label: str, severity: str):
        tx_flags.append({'code': code, 'label': label, 'severity': severity})

    if counters['high_risk_corridor'] > 0:
        add_tx('HIGH_RISK_COUNTRY_WIRE', 'High risk country wire', 'High')
    if counters['cross_border'] >= 3:
        add_tx('CROSS_BORDER_PATTERN', 'Frequent cross-border activity', 'Medium')
    if counters['near_threshold'] >= 2:
        add_tx('THRESHOLD_PATTERN', 'Near-threshold transaction pattern', 'Medium')
    if counters['round_amount'] >= 2:
        add_tx('ROUND_AMOUNT_PATTERN', 'Round-amount structuring pattern', 'Medium')
    if counters['night'] >= 2 or counters['weekend'] >= 2:
        add_tx('OFF_HOURS_ACTIVITY', 'Frequent off-hours activity', 'Medium')
    if counters['recurring'] >= 3:
        add_tx('RECURRING_FLOW', 'Recurring transfer flow', 'Low')
    if counters['burst_signal'] >= 1:
        add_tx('BURST_ACTIVITY', 'Burst activity detected', 'High')

    if int(client.pep_flag or 0) == 1:
        profile_flags.append({'code': 'PEP', 'label': 'PEP exposure', 'severity': 'High'})
    if int(client.sanctions_flag or 0) == 1:
        profile_flags.append({'code': 'RAI', 'label': 'RAI / sanctions indicator', 'severity': 'High'})

    high_risk_profile_countries = {'IR', 'KP', 'SY', 'AF', 'RU'}
    if (client.country or '').upper() in high_risk_profile_countries or (client.resident_country or '').upper() in high_risk_profile_countries:
        profile_flags.append({'code': 'COUNTRY', 'label': 'High-risk profile country', 'severity': 'High'})

    if (client.risk_rating or '').lower().startswith('high'):
        profile_flags.append({'code': 'RISK_PROFILE', 'label': 'Client risk profile elevated', 'severity': 'Medium'})

    related_parties = len({t.counterparty_id for t in txs if t.counterparty_id})
    if related_parties >= 10:
        profile_flags.append({'code': 'RELATED_PARTIES', 'label': 'Related parties elevated risk', 'severity': 'Medium'})

    return {
        'transaction_flags': tx_flags,
        'profile_flags': profile_flags,
    }


def _safe_min(cur, incoming):
    if incoming is None:
        return cur
    if cur is None:
        return incoming
    return incoming if incoming < cur else cur


def _safe_max(cur, incoming):
    if incoming is None:
        return cur
    if cur is None:
        return incoming
    return incoming if incoming > cur else cur


def _normalize_entity_label(entity_type: str, value: str, metadata: dict | None = None):
    meta = metadata or {}
    if entity_type == 'address':
        city = meta.get('city')
        ctry = country_name(meta.get('country'))
        suffix = ', '.join([p for p in [city, ctry] if p])
        return f'{value} ({suffix})' if suffix else value
    if entity_type == 'phone':
        return value
    if entity_type == 'profile':
        return value
    if entity_type == 'account':
        return value
    return value


def _fallback_counterparty_name(counterparty_id: str) -> str:
    return f'Counterparty {counterparty_id}'


def _resolve_counterparty_names(db: Session, counterparty_ids: set[str]) -> dict[str, str]:
    if not counterparty_ids:
        return {}
    rows = db.execute(select(Client.client_id, Client.full_name).where(Client.client_id.in_(list(counterparty_ids)))).all()
    return {cid: full_name for cid, full_name in rows}


def _build_connection_payload(client: Client, txs, addresses, phones, counterparty_names: dict[str, str] | None = None):
    client_node_id = f'client:{client.client_id}'
    nodes = {
        client_node_id: {
            'id': client_node_id,
            'entity_id': client.client_id,
            'label': client.full_name,
            'entity_type': 'client',
            'importance': 1.0,
            'metadata': {
                'country': client.country,
                'country_name': country_name(client.country),
                'segment': client.segment,
                'risk_rating': client.risk_rating,
            },
        }
    }
    edges = []
    linked_entities = []

    def add_node(node_id, entity_id, label, entity_type, importance=0.5, metadata=None):
        if node_id not in nodes:
            nodes[node_id] = {
                'id': node_id,
                'entity_id': entity_id,
                'label': label,
                'entity_type': entity_type,
                'importance': importance,
                'metadata': metadata or {},
            }

    def add_edge(source, target, link_type, reason, first_seen=None, last_seen=None, count=0, amount=0.0, metadata=None):
        edge_id = f"{link_type}:{source}->{target}:{len(edges)}"
        edges.append(
            {
                'id': edge_id,
                'source': source,
                'target': target,
                'link_type': link_type,
                'reason': reason,
                'first_seen': _fmt_dt(first_seen),
                'last_seen': _fmt_dt(last_seen),
                'count': int(count or 0),
                'amount': round(float(amount or 0.0), 2),
                'metadata': metadata or {},
            }
        )

    account_node = f'account:{client.client_id}:primary'
    add_node(
        account_node,
        f'ACC-{client.client_id}-PRIMARY',
        f'ACC-{client.client_id}-PRIMARY',
        'account',
        importance=0.85,
        metadata={'owner_client_id': client.client_id, 'account_role': 'primary'},
    )
    add_edge(
        client_node_id,
        account_node,
        'owns_account',
        'Client owns primary account used as source/sink of observed transactions.',
    )
    linked_entities.append(
        {
            'entity_id': f'ACC-{client.client_id}-PRIMARY',
            'entity_type': 'account',
            'label': f'ACC-{client.client_id}-PRIMARY',
            'relationship': 'owns_account',
            'first_seen': None,
            'last_seen': None,
            'count': 0,
            'amount': 0.0,
            'metadata': {'account_role': 'primary'},
        }
    )

    profile_rows = [
        ('segment', client.segment),
        ('occupation', client.occupation),
        ('risk_rating', client.risk_rating),
    ]
    for profile_key, profile_val in profile_rows:
        if not profile_val:
            continue
        node_id = f'profile:{profile_key}:{profile_val}'
        add_node(
            node_id,
            node_id,
            f'{profile_key.replace("_", " ").title()}: {profile_val}',
            'profile',
            importance=0.45,
            metadata={'profile_key': profile_key, 'profile_value': profile_val},
        )
        add_edge(
            client_node_id,
            node_id,
            'profile_attribute',
            f'Client profile attribute {profile_key} equals {profile_val}.',
        )
        linked_entities.append(
            {
                'entity_id': node_id,
                'entity_type': 'profile',
                'label': f'{profile_key.replace("_", " ").title()}: {profile_val}',
                'relationship': 'profile_attribute',
                'first_seen': None,
                'last_seen': None,
                'count': 1,
                'amount': 0.0,
                'metadata': {'profile_key': profile_key},
            }
        )

    for idx, a in enumerate(addresses, start=1):
        entity_id = f'ADDR-{client.client_id}-{idx}'
        node_id = f'address:{client.client_id}:{idx}'
        label = _normalize_entity_label('address', a.address_line, {'city': a.city, 'country': a.country})
        add_node(node_id, entity_id, label, 'address', importance=0.4, metadata={'city': a.city, 'country': a.country})
        add_edge(
            client_node_id,
            node_id,
            'address_association',
            'Address appears in verified client address history.',
            first_seen=datetime.combine(a.from_date, time.min),
            last_seen=datetime.combine(a.to_date, time.min) if a.to_date else None,
            count=1,
        )
        linked_entities.append(
            {
                'entity_id': entity_id,
                'entity_type': 'address',
                'label': label,
                'relationship': 'address_association',
                'first_seen': a.from_date.isoformat(),
                'last_seen': a.to_date.isoformat() if a.to_date else None,
                'count': 1,
                'amount': 0.0,
                'metadata': {'city': a.city, 'country': a.country, 'country_name': country_name(a.country)},
            }
        )

    for idx, p in enumerate(phones, start=1):
        entity_id = f'PHONE-{client.client_id}-{idx}'
        node_id = f'phone:{client.client_id}:{idx}'
        add_node(node_id, entity_id, p.phone, 'phone', importance=0.35, metadata={})
        add_edge(
            client_node_id,
            node_id,
            'phone_association',
            'Phone appears in verified client phone history.',
            first_seen=datetime.combine(p.from_date, time.min),
            last_seen=datetime.combine(p.to_date, time.min) if p.to_date else None,
            count=1,
        )
        linked_entities.append(
            {
                'entity_id': entity_id,
                'entity_type': 'phone',
                'label': p.phone,
                'relationship': 'phone_association',
                'first_seen': p.from_date.isoformat(),
                'last_seen': p.to_date.isoformat() if p.to_date else None,
                'count': 1,
                'amount': 0.0,
                'metadata': {},
            }
        )

    cp_name_map = counterparty_names or {}
    cp_stats = {}
    for t in txs:
        cp_id = t.counterparty_id if t.client_id == client.client_id else t.client_id
        if not cp_id or cp_id == client.client_id:
            continue
        cp_name = cp_name_map.get(cp_id) or _fallback_counterparty_name(cp_id)
        node_id = f'counterparty:{cp_id}'
        cp_node_meta = {'country': t.country, 'country_name': country_name(t.country), 'display_name': cp_name}
        add_node(node_id, cp_id, cp_name, 'counterparty', importance=0.62, metadata=cp_node_meta)

        account_id = f'ACC-{cp_id}-EXT'
        cp_account_node = f'account:{cp_id}:external'
        add_node(
            cp_account_node,
            account_id,
            f'{cp_name} external account',
            'account',
            importance=0.45,
            metadata={'owner_counterparty_id': cp_id, 'owner_counterparty_name': cp_name, 'account_role': 'external'},
        )
        add_edge(
            node_id,
            cp_account_node,
            'owns_account',
            'Counterparty account inferred from transactional relationship.',
        )

        key = cp_id
        stat = cp_stats.setdefault(
            key,
            {
                'node_id': node_id,
                'counterparty_id': cp_id,
                'counterparty_name': cp_name,
                'country': t.country,
                'first_seen': None,
                'last_seen': None,
                'tx_count': 0,
                'total_amount': 0.0,
                'incoming': 0,
                'outgoing': 0,
                'tx_ids': [],
                'incoming_tx_ids': [],
                'outgoing_tx_ids': [],
            },
        )
        stat['first_seen'] = _safe_min(stat['first_seen'], t.timestamp)
        stat['last_seen'] = _safe_max(stat['last_seen'], t.timestamp)
        stat['tx_count'] += 1
        stat['total_amount'] += float(t.amount)
        stat['tx_ids'].append(t.tx_id)
        if t.direction == 'incoming':
            stat['incoming'] += 1
            stat['incoming_tx_ids'].append(t.tx_id)
        else:
            stat['outgoing'] += 1
            stat['outgoing_tx_ids'].append(t.tx_id)

    for cp_id, stat in cp_stats.items():
        node_id = stat['node_id']
        cp_account_node = f'account:{cp_id}:external'
        tx_direction = 'mixed' if stat['incoming'] and stat['outgoing'] else ('incoming' if stat['incoming'] else 'outgoing')
        tx_metadata = {
            'incoming_count': stat['incoming'],
            'outgoing_count': stat['outgoing'],
            'counterparty_id': cp_id,
            'counterparty_name': stat['counterparty_name'],
            'direction': tx_direction,
            'time_start': _fmt_dt(stat['first_seen']),
            'time_end': _fmt_dt(stat['last_seen']),
            'transaction_ids': stat['tx_ids'],
            'incoming_transaction_ids': stat['incoming_tx_ids'],
            'outgoing_transaction_ids': stat['outgoing_tx_ids'],
        }
        add_edge(
            account_node,
            cp_account_node,
            'transaction_path',
            f"Funds flowed between client primary account and {stat['counterparty_name']}'s external account.",
            first_seen=stat['first_seen'],
            last_seen=stat['last_seen'],
            count=stat['tx_count'],
            amount=stat['total_amount'],
            metadata=tx_metadata,
        )
        add_edge(
            client_node_id,
            node_id,
            'transacted_with',
            f"Client transacted directly with {stat['counterparty_name']}.",
            first_seen=stat['first_seen'],
            last_seen=stat['last_seen'],
            count=stat['tx_count'],
            amount=stat['total_amount'],
            metadata=tx_metadata,
        )

        linked_entities.append(
            {
                'entity_id': cp_id,
                'entity_type': 'counterparty',
                'label': stat['counterparty_name'],
                'relationship': 'transacted_with',
                'first_seen': _fmt_dt(stat['first_seen']),
                'last_seen': _fmt_dt(stat['last_seen']),
                'count': stat['tx_count'],
                'amount': round(stat['total_amount'], 2),
                'metadata': {
                    'country': stat['country'],
                    'country_name': country_name(stat['country']),
                    'incoming_count': stat['incoming'],
                    'outgoing_count': stat['outgoing'],
                    'counterparty_name': stat['counterparty_name'],
                },
            }
        )

        linked_entities.append(
            {
                'entity_id': f'ACC-{cp_id}-EXT',
                'entity_type': 'account',
                'label': f"{stat['counterparty_name']} external account",
                'relationship': 'transaction_path',
                'first_seen': _fmt_dt(stat['first_seen']),
                'last_seen': _fmt_dt(stat['last_seen']),
                'count': stat['tx_count'],
                'amount': round(stat['total_amount'], 2),
                'metadata': {'owner_counterparty_id': cp_id, 'owner_counterparty_name': stat['counterparty_name'], 'account_role': 'external'},
            }
        )

    linked_entities = sorted(
        linked_entities,
        key=lambda e: (-(e.get('amount') or 0), -(e.get('count') or 0), e.get('entity_type', ''), e.get('label', '')),
    )

    return {
        'client_id': client.client_id,
        'nodes': list(nodes.values()),
        'edges': edges,
        'linked_entities': linked_entities,
    }


def _build_path(nodes_by_id: dict, edges: list[dict], start_id: str, end_id: str):
    graph = defaultdict(list)
    edge_lookup = {}
    for e in edges:
        graph[e['source']].append((e['target'], e['id']))
        graph[e['target']].append((e['source'], e['id']))
        edge_lookup[e['id']] = e

    q = deque([[start_id]])
    seen = {start_id}
    found_path = None
    while q:
        path = q.popleft()
        cur = path[-1]
        if cur == end_id:
            found_path = path
            break
        for nxt, _ in graph.get(cur, []):
            if nxt in seen:
                continue
            seen.add(nxt)
            q.append(path + [nxt])

    if not found_path:
        return None

    path_edges = []
    cumulative_amount = 0.0
    tx_edge_count = 0
    for i in range(len(found_path) - 1):
        a, b = found_path[i], found_path[i + 1]
        edge_id = None
        for candidate, cid in graph[a]:
            if candidate == b:
                edge_id = cid
                break
        if edge_id:
            edge = edge_lookup[edge_id]
            path_edges.append(edge)
            cumulative_amount += float(edge.get('amount') or 0.0)
            if edge.get('link_type') in {'transacted_with', 'transaction_path'}:
                tx_edge_count += 1

    return {
        'nodes': [nodes_by_id[n] for n in found_path if n in nodes_by_id],
        'edges': path_edges,
        'hop_count': max(0, len(found_path) - 1),
        'tx_edge_count': tx_edge_count,
        'cumulative_amount': round(cumulative_amount, 2),
    }


@router.get('/health')
def health(db: Session = Depends(get_db)):
    db.execute(select(1))
    return {'status': 'ok', 'time': datetime.utcnow().isoformat()}


@router.get('/clients')
def list_clients(
    q: str | None = None,
    segment: str | None = None,
    min_risk: float = 0,
    risk_rating: str | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    sort_by: str = Query('risk_score'),
    sort_dir: str = Query('desc'),
    db: Session = Depends(get_db),
):
    base_stmt = select(Client, RiskResult).join(RiskResult, RiskResult.client_id == Client.client_id)
    if q:
        like = f'%{q.strip()}%'
        base_stmt = base_stmt.where(
            or_(Client.client_id.ilike(like), Client.full_name.ilike(like), Client.city.ilike(like))
        )
    if segment:
        base_stmt = base_stmt.where(Client.segment == segment)
    if min_risk > 0:
        base_stmt = base_stmt.where(RiskResult.risk_score >= min_risk)
    if risk_rating:
        base_stmt = base_stmt.where(Client.risk_rating == risk_rating)

    total = db.execute(select(func.count()).select_from(base_stmt.subquery())).scalar_one()

    sort_columns = {
        'risk_score': RiskResult.risk_score,
        'full_name': Client.full_name,
        'city': Client.city,
        'annual_income': Client.annual_income,
        'client_id': Client.client_id,
        'risk_rating': _risk_rating_order_expr(Client.risk_rating),
        'risk_level': _risk_rating_order_expr(Client.risk_rating),
        'client_type': Client.client_type,
    }
    selected_column = sort_columns.get(sort_by, RiskResult.risk_score)
    order_fn = desc if sort_dir.lower() != 'asc' else asc

    offset = (page - 1) * page_size
    rows = db.execute(
        base_stmt.order_by(order_fn(selected_column), Client.client_id.asc()).offset(offset).limit(page_size)
    ).all()

    items = [
        {
            'client_id': c.client_id,
            'full_name': c.full_name,
            'segment': c.segment,
            'country': c.country,
            'country_name': country_name(c.country),
            'city': c.city,
            'client_type': c.client_type or 'personal',
            'annual_income': c.annual_income,
            'risk_score': r.risk_score,
            'risk_rating': c.risk_rating,
            'profile_text': c.profile_text,
        }
        for c, r in rows
    ]

    pages = max(1, (total + page_size - 1) // page_size)
    return {
        'items': items,
        'page': page,
        'page_size': page_size,
        'total': total,
        'pages': pages,
        'sort_by': sort_by,
        'sort_dir': sort_dir,
    }


@router.get('/segment-codes')
def list_segment_codes(db: Session = Depends(get_db)):
    rows = db.execute(
        select(SegmentCode)
        .where(SegmentCode.active == 1)
        .order_by(SegmentCode.display_order.asc(), SegmentCode.code.asc())
    ).scalars().all()
    return [
        {
            'code': row.code,
            'description': row.description,
            'active': row.active,
            'display_order': row.display_order,
        }
        for row in rows
    ]


@router.get('/clients/{client_id}')
def get_client(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    risk = db.get(RiskResult, client_id)
    txs = db.execute(
        select(Transaction)
        .where(Transaction.client_id == client_id)
        .order_by(Transaction.timestamp.desc())
        .limit(5000)
    ).scalars().all()

    names = db.execute(select(ClientNameHistory).where(ClientNameHistory.client_id == client_id).order_by(ClientNameHistory.from_date.desc())).scalars().all()
    addresses = db.execute(select(ClientAddressHistory).where(ClientAddressHistory.client_id == client_id).order_by(ClientAddressHistory.from_date.desc())).scalars().all()
    phones = db.execute(select(ClientPhoneHistory).where(ClientPhoneHistory.client_id == client_id).order_by(ClientPhoneHistory.from_date.desc())).scalars().all()
    wc_hits = db.execute(select(WorldCheckHit).where(WorldCheckHit.client_id == client_id)).scalars().all()
    cases = db.execute(select(Case).where(Case.client_id == client_id).order_by(Case.opened_at.desc())).scalars().all()
    notes = db.execute(select(CaseNote).where(CaseNote.case_id.in_([c.case_id for c in cases]))).scalars().all() if cases else []
    alerts = db.execute(select(Alert).where(Alert.client_id == client_id).order_by(Alert.created_at.desc())).scalars().all()
    decisions = db.execute(select(ReviewDecision).where(ReviewDecision.client_id == client_id).order_by(ReviewDecision.created_at.desc())).scalars().all()
    legacy_decisions = db.execute(select(RiskDecisionLog).where(RiskDecisionLog.client_id == client_id).order_by(RiskDecisionLog.created_at.desc())).scalars().all()

    counterparty_names = _resolve_counterparty_names(db, {t.counterparty_id for t in txs if t.counterparty_id and t.counterparty_id != client_id})

    wire_stats = {}
    total_wire = 0.0
    for t in txs:
        if t.tx_type != 'wire':
            continue
        c = t.country
        total_wire += float(t.amount)
        if c not in wire_stats:
            wire_stats[c] = {
                'country': c,
                'country_name': country_name(c),
                'incoming': 0.0,
                'outgoing': 0.0,
                'risk': t.typology_tags.get('destination_country_risk_tier')
                or t.typology_tags.get('wire_country_risk', 'medium'),
            }
        wire_stats[c][t.direction] += float(t.amount)

    for c in wire_stats.values():
        c['total'] = round(c['incoming'] + c['outgoing'], 2)
        c['share_pct'] = round((c['total'] / total_wire) * 100, 2) if total_wire > 0 else 0.0

    client_type = (client.client_type or 'personal').lower()
    current_segment_codes = _normalize_segment_codes(client.current_segment_codes or [])
    current_risk_profile = {
        'risk_level': client.risk_rating,
        'segment_codes': current_segment_codes,
    }

    individual_profile = None
    entity_profile = None
    if client_type in INDIVIDUAL_CLIENT_TYPES:
        individual_profile = {
            'dob': client.dob.isoformat() if client.dob else None,
            'age': _age_from_dob(client.dob),
            'occupation': client.occupation,
            'resident_country': client.resident_country or client.country,
            'resident_country_name': country_name(client.resident_country or client.country),
            'risk_profile': current_risk_profile,
            'ids': client.profile_ids or [],
        }
    else:
        entity_profile = {
            'bsc_code': client.entity_bsc_code,
            'aml_business_type_code': client.entity_aml_business_type_code,
            'sic_code': client.entity_sic_code,
            'registration_country': client.registration_country,
            'registration_country_name': country_name(client.registration_country),
            'domicile_country': client.domicile_country,
            'domicile_country_name': country_name(client.domicile_country),
            'incorporation_country': client.incorporation_country,
            'incorporation_country_name': country_name(client.incorporation_country),
            'signing_officer': client.signing_officer,
            'owners': client.entity_owners or [],
            'entity_risk_profile': client.entity_risk_profile or current_risk_profile,
            'ids': client.profile_ids or [],
        }

    review_decisions = [
        {
            'decision_id': d.decision_id,
            'username': d.username,
            'risk_level': d.risk_level,
            'segment_codes': d.segment_codes or [],
            'description': d.description,
            'created_at': d.created_at.isoformat(),
            'source': 'review_decision',
        }
        for d in decisions
    ]
    review_decisions.extend(
        {
            'decision_id': d.decision_id,
            'username': 'legacy',
            'risk_level': None,
            'segment_codes': [],
            'description': d.reason,
            'created_at': d.created_at.isoformat(),
            'source': 'legacy_risk_decision',
            'action': d.action,
        }
        for d in legacy_decisions
    )
    review_decisions = sorted(review_decisions, key=lambda x: x['created_at'], reverse=True)

    return {
        'client': {
            'client_id': client.client_id,
            'full_name': client.full_name,
            'client_type': client_type,
            'profile_text': client.profile_text,
            'country': client.country,
            'country_name': country_name(client.country),
            'city': client.city,
            'segment': client.segment,
            'annual_income': client.annual_income,
            'dob': client.dob.isoformat() if client.dob else None,
            'occupation': client.occupation,
            'pep_flag': client.pep_flag,
            'sanctions_flag': client.sanctions_flag,
            'risk_rating': client.risk_rating,
            'resident_country': client.resident_country or client.country,
            'resident_country_name': country_name(client.resident_country or client.country),
            'profile_ids': client.profile_ids or [],
            'current_risk_profile': current_risk_profile,
            'individual_profile': individual_profile,
            'entity_profile': entity_profile,
        },
        'risk': {
            'risk_score': risk.risk_score if risk else None,
            'rule_hits': risk.rule_hits if risk else {},
            'model_reason': risk.model_reason if risk else '',
        },
        'transactions': [
            {
                'tx_id': t.tx_id,
                'counterparty_id': t.counterparty_id,
                'counterparty_name': counterparty_names.get(t.counterparty_id) or _fallback_counterparty_name(t.counterparty_id),
                'tx_type': t.tx_type,
                'direction': t.direction,
                'amount': t.amount,
                'country': t.country,
                'country_name': country_name(t.country),
                'timestamp': t.timestamp.isoformat(),
                'typology_tags': t.typology_tags,
                'channel': t.channel,
                'currency': t.currency,
                'purpose_code': (t.typology_tags or {}).get('purpose_code'),
                'source_country': (t.typology_tags or {}).get('source_country'),
                'source_country_name': country_name((t.typology_tags or {}).get('source_country')),
                'destination_country': (t.typology_tags or {}).get('destination_country'),
                'destination_country_name': country_name((t.typology_tags or {}).get('destination_country')),
                'flags': [
                    k for k, enabled in {
                        'cross_border': bool((t.typology_tags or {}).get('cross_border')),
                        'round_amount': bool((t.typology_tags or {}).get('round_amount_flag')),
                        'near_threshold': bool((t.typology_tags or {}).get('near_threshold_flag')),
                        'weekend': bool((t.typology_tags or {}).get('weekend_flag')),
                        'night': bool((t.typology_tags or {}).get('night_flag')),
                        'recurring': bool((t.typology_tags or {}).get('recurring_flag')),
                        'high_risk_corridor': ((t.typology_tags or {}).get('corridor_risk_tag') == 'high'),
                        'burst_signal': bool((t.typology_tags or {}).get('burst_signal')),
                    }.items() if enabled
                ],
            }
            for t in txs
        ],
        'history': {
            'names': [{'full_name': n.full_name, 'from_date': n.from_date.isoformat(), 'to_date': n.to_date.isoformat() if n.to_date else None} for n in names],
            'addresses': [{'address_line': a.address_line, 'city': a.city, 'country': a.country, 'country_name': country_name(a.country), 'from_date': a.from_date.isoformat(), 'to_date': a.to_date.isoformat() if a.to_date else None} for a in addresses],
            'phones': [{'phone': p.phone, 'from_date': p.from_date.isoformat(), 'to_date': p.to_date.isoformat() if p.to_date else None} for p in phones],
        },
        'world_check_hits': [
            {'hit_id': h.hit_id, 'category': h.category, 'match_score': h.match_score, 'source': h.source, 'notes': h.notes}
            for h in wc_hits
        ],
        'cases': [
            {
                'case_id': c.case_id,
                'status': c.status,
                'title': c.title,
                'opened_at': c.opened_at.isoformat(),
                'closed_at': c.closed_at.isoformat() if c.closed_at else None,
                'age_days': max(0, (datetime.utcnow() - c.opened_at).days),
                'notes': [
                    {'note_id': n.note_id, 'created_at': n.created_at.isoformat(), 'note': n.note}
                    for n in notes if n.case_id == c.case_id
                ],
            }
            for c in cases
        ],
        'alerts': [
            {
                'alert_id': a.alert_id,
                'case_id': a.case_id,
                'severity': a.severity,
                'status': a.status,
                'created_at': a.created_at.isoformat(),
                'description': a.description,
                'flags': a.flags or {},
            }
            for a in alerts
        ],
        'flag_summary': (lambda from_alerts, derived: {
            'transaction_flags': from_alerts['transaction_flags'] if from_alerts.get('transaction_flags') else derived.get('transaction_flags', []),
            'profile_flags': from_alerts['profile_flags'] if from_alerts.get('profile_flags') else derived.get('profile_flags', []),
        })(_aggregate_alert_flags(alerts), _derive_flag_summary_from_profile_and_transactions(client, txs)),
        'wire_country_breakdown': sorted(wire_stats.values(), key=lambda x: (x['incoming'] + x['outgoing']), reverse=True),
        'risk_decisions': review_decisions,
    }


@router.get('/clients/{client_id}/login-activity')
def client_login_activity(
    client_id: str,
    from_date: date | None = None,
    to_date: date | None = None,
    # backward compatibility
    from_ts: datetime | None = None,
    to_ts: datetime | None = None,
    ip_country: str | None = None,
    limit: int = Query(400, ge=1, le=3000),
    db: Session = Depends(get_db),
):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    stmt = select(LoginActivity).where(LoginActivity.client_id == client_id)

    from_boundary = from_ts
    to_boundary = to_ts
    if from_date:
        from_boundary = datetime.combine(from_date, time.min)
    if to_date:
        to_boundary = datetime.combine(to_date, time.max)

    if from_boundary:
        stmt = stmt.where(LoginActivity.logged_in_at >= from_boundary)
    if to_boundary:
        stmt = stmt.where(LoginActivity.logged_in_at <= to_boundary)
    if ip_country:
        stmt = stmt.where(LoginActivity.ip_country == ip_country)

    rows = db.execute(stmt.order_by(LoginActivity.logged_in_at.asc()).limit(limit)).scalars().all()
    grouped_runs = _group_login_country_runs(rows)
    return {
        'client_id': client_id,
        'total': len(rows),
        'country_runs': grouped_runs,
        'records': [
            {
                'login_id': r.login_id,
                'timestamp': r.logged_in_at.isoformat(),
                'ip_address': r.ip_address,
                'ip_country': r.ip_country,
                'ip_country_name': country_name(r.ip_country),
                'status': r.status,
                'channel': r.channel,
            }
            for r in reversed(rows)
        ],
    }


@router.post('/clients/{client_id}/review-decision')
def add_review_decision(client_id: str, req: ReviewDecisionRequest, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    normalized_risk = (req.risk_level or '').strip()
    if normalized_risk not in ALLOWED_RISK_LEVELS:
        raise HTTPException(status_code=400, detail=f'Invalid risk level: {normalized_risk}')

    selected_codes = _normalize_segment_codes(req.segment_codes)
    if selected_codes:
        valid_codes = {
            code for code, in db.execute(
                select(SegmentCode.code).where(SegmentCode.active == 1, SegmentCode.code.in_(selected_codes))
            ).all()
        }
        invalid = [code for code in selected_codes if code not in valid_codes]
        if invalid:
            raise HTTPException(status_code=400, detail=f'Invalid segment codes: {", ".join(invalid)}')

    now = datetime.utcnow()
    decision = ReviewDecision(
        decision_id=f'RVW-{uuid.uuid4().hex[:20]}',
        client_id=client_id,
        username=req.username.strip(),
        risk_level=normalized_risk,
        segment_codes=selected_codes,
        description=req.description.strip(),
        created_at=now,
    )
    db.add(decision)

    client.risk_rating = normalized_risk
    client.current_segment_codes = selected_codes

    db.commit()
    return {
        'status': 'ok',
        'decision_id': decision.decision_id,
    }


@router.post('/clients/{client_id}/risk-decision')
def add_risk_decision(client_id: str, req: RiskDecisionRequest, db: Session = Depends(get_db)):
    """Backward-compatible endpoint retained for legacy UI actions."""
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    action_to_level = {
        'up-risk': 'High1',
        'down-risk': 'Standard',
        'no-change': client.risk_rating,
    }
    mapped_level = action_to_level.get((req.action or '').strip(), client.risk_rating)

    log = RiskDecisionLog(
        decision_id=f'DEC-{datetime.utcnow().timestamp()}-{client_id[-4:]}',
        client_id=client_id,
        action=req.action,
        reason=req.reason,
        created_at=datetime.utcnow(),
    )
    db.add(log)
    db.add(
        ReviewDecision(
            decision_id=f'RVW-{uuid.uuid4().hex[:20]}',
            client_id=client_id,
            username='legacy-ui',
            risk_level=mapped_level,
            segment_codes=_normalize_segment_codes(client.current_segment_codes or []),
            description=req.reason,
            created_at=datetime.utcnow(),
        )
    )
    client.risk_rating = mapped_level
    db.commit()
    return {'status': 'ok'}


@router.post('/cases/{case_id}/status')
def update_case_status(case_id: str, req: CaseStatusUpdateRequest, db: Session = Depends(get_db)):
    case = db.get(Case, case_id)
    if not case:
        raise HTTPException(status_code=404, detail='Case not found')
    if req.status not in ALLOWED_CASE_STATUSES:
        raise HTTPException(status_code=400, detail=f'Invalid status: {req.status}')

    case.status = req.status
    if req.status == 'Close':
        case.closed_at = datetime.utcnow()
    else:
        case.closed_at = None

    note = CaseNote(
        note_id=f'NOTE-{datetime.utcnow().timestamp()}-{case_id[-4:]}',
        case_id=case_id,
        created_at=datetime.utcnow(),
        note=f'Status updated to {req.status}: {req.reason.strip()}',
    )
    db.add(note)
    db.commit()
    return {'status': 'ok', 'case_id': case_id, 'new_status': case.status}


@router.get('/clients/{client_id}/export/transactions.csv')
def export_transactions_csv(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(Transaction.client_id == client_id)
        .order_by(Transaction.timestamp.desc())
        .limit(10000)
    ).scalars().all()

    stream = io.StringIO()
    writer = csv.writer(stream)
    writer.writerow([
        'tx_id', 'timestamp', 'tx_type', 'direction', 'amount', 'currency', 'country',
        'counterparty_id', 'channel', 'purpose_code', 'corridor_risk_tag', 'flags'
    ])

    for t in txs:
        tags = t.typology_tags or {}
        flags = [
            f for f, enabled in {
                'cross_border': bool(tags.get('cross_border')),
                'round_amount': bool(tags.get('round_amount_flag')),
                'near_threshold': bool(tags.get('near_threshold_flag')),
                'weekend': bool(tags.get('weekend_flag')),
                'night': bool(tags.get('night_flag')),
                'recurring': bool(tags.get('recurring_flag')),
                'high_risk_corridor': tags.get('corridor_risk_tag') == 'high',
                'burst_signal': bool(tags.get('burst_signal')),
            }.items() if enabled
        ]
        writer.writerow([
            t.tx_id,
            t.timestamp.isoformat(),
            t.tx_type,
            t.direction,
            t.amount,
            t.currency,
            country_name(t.country),
            t.counterparty_id,
            t.channel,
            tags.get('purpose_code', ''),
            tags.get('corridor_risk_tag', ''),
            '|'.join(flags),
        ])

    return Response(
        content=stream.getvalue(),
        media_type='text/csv',
        headers={'Content-Disposition': f'attachment; filename="{client_id}_transactions.csv"'},
    )


@router.get('/clients/{client_id}/export/dossier.json')
def export_client_dossier(client_id: str, db: Session = Depends(get_db)):
    payload = get_client(client_id, db)
    return payload

@router.get('/clients/{client_id}/export/summary.pdf')
def export_client_summary_pdf(client_id: str, db: Session = Depends(get_db)):
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.graphics.charts.barcharts import VerticalBarChart
        from reportlab.graphics.charts.piecharts import Pie
        from reportlab.graphics.shapes import Drawing, String
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    except Exception as e:
        raise HTTPException(status_code=500, detail=f'PDF export dependency missing: {e}')

    payload = get_client(client_id, db)
    client = payload.get('client', {})
    risk = payload.get('risk', {})
    flags = payload.get('flag_summary', {})
    txs = payload.get('transactions', [])
    decisions = payload.get('risk_decisions', [])

    tx_total = sum(float(t.get('amount') or 0) for t in txs)
    wire_total = sum(float(t.get('amount') or 0) for t in txs if (t.get('tx_type') or '').lower() == 'wire')

    top_countries: dict[str, float] = {}
    type_totals: dict[str, float] = {}
    month_totals: dict[str, float] = {}
    for t in txs:
        c = t.get('country_name') or t.get('country') or 'Unknown'
        a = float(t.get('amount') or 0)
        top_countries[c] = top_countries.get(c, 0.0) + a

        typ = (t.get('tx_type') or 'other').lower()
        if typ == 'card':
            typ = 'credit card'
        type_totals[typ] = type_totals.get(typ, 0.0) + a

        ts = (t.get('timestamp') or '')
        m = ts[:7] if len(ts) >= 7 else 'Unknown'
        month_totals[m] = month_totals.get(m, 0.0) + a

    final_decision = decisions[0] if decisions else {}
    final_risk = final_decision.get('risk_level') or client.get('risk_rating') or 'Standard'
    final_reason = final_decision.get('description') or final_decision.get('reason') or risk.get('model_reason') or '-'

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter, rightMargin=0.6 * inch, leftMargin=0.6 * inch, topMargin=0.5 * inch, bottomMargin=0.5 * inch)
    styles = getSampleStyleSheet()
    title = ParagraphStyle('title', parent=styles['Heading1'], fontSize=16, textColor=colors.HexColor('#1a365d'), spaceAfter=8)
    h = ParagraphStyle('h', parent=styles['Heading3'], fontSize=11, textColor=colors.HexColor('#2d3748'), spaceBefore=8, spaceAfter=4)
    body = ParagraphStyle('body', parent=styles['BodyText'], fontSize=9, leading=12)

    story = []
    story.append(Paragraph('AML Client Investigation Summary', title))
    story.append(Paragraph(f"Client: <b>{client.get('full_name','-')}</b> ({client.get('client_id','-')})", body))
    story.append(Paragraph(f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}", body))
    story.append(Spacer(1, 8))

    demo_data = [
        ['Field', 'Value'],
        ['Client type', str(client.get('client_type') or '-')],
        ['Country / City', f"{client.get('country_name') or client.get('country') or '-'} / {client.get('city') or '-'}"],
        ['Segment', str(client.get('segment') or '-')],
        ['Annual income', f"${float(client.get('annual_income') or 0):,.2f}"],
        ['Profile IDs', str(len(client.get('profile_ids') or []))],
    ]
    tx_data = [
        ['Metric', 'Value'],
        ['Total transactions', str(len(txs))],
        ['Total amount', f"${tx_total:,.2f}"],
        ['Total wire amount', f"${wire_total:,.2f}"],
        ['Top countries', ', '.join([f"{k} (${v:,.0f})" for k, v in sorted(top_countries.items(), key=lambda x: x[1], reverse=True)[:5]]) or '-'],
    ]
    flag_data = [
        ['Type', 'Details'],
        ['Transaction flags', ', '.join([f.get('label', f.get('code','-')) for f in (flags.get('transaction_flags') or [])]) or 'None'],
        ['Profile flags', ', '.join([f.get('label', f.get('code','-')) for f in (flags.get('profile_flags') or [])]) or 'None'],
    ]
    decision_data = [
        ['Field', 'Value'],
        ['Final risk level', str(final_risk)],
        ['Analyst', str(final_decision.get('username') or 'N/A')],
        ['Decision time', str(final_decision.get('created_at') or 'N/A')],
        ['Rationale', str(final_reason)],
    ]

    def styled_table(data, widths=(1.7*inch, 5.0*inch)):
        t = Table(data, colWidths=list(widths), hAlign='LEFT')
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a365d')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e0')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f7fafc')]),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
            ('RIGHTPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        return t

    story.append(Paragraph('Client Demographics', h)); story.append(styled_table(demo_data)); story.append(Spacer(1, 6))
    story.append(Paragraph('Transaction Summary', h)); story.append(styled_table(tx_data)); story.append(Spacer(1, 6))

    # Pie chart: transaction amount mix by type
    if type_totals:
        pie_data = sorted(type_totals.items(), key=lambda x: x[1], reverse=True)[:6]
        drawing = Drawing(520, 220)
        drawing.add(String(0, 205, 'Transaction amount mix by type', fontSize=10, fillColor=colors.HexColor('#2d3748')))
        pie = Pie()
        pie.x = 40
        pie.y = 20
        pie.width = 180
        pie.height = 160
        pie.data = [v for _, v in pie_data]
        pie.labels = [k for k, _ in pie_data]
        pie.slices.strokeWidth = 0.3
        palette = ['#4E79A7', '#F28E2B', '#E15759', '#76B7B2', '#59A14F', '#EDC948']
        for i in range(len(pie_data)):
            pie.slices[i].fillColor = colors.HexColor(palette[i % len(palette)])
        drawing.add(pie)
        story.append(drawing)
        story.append(Spacer(1, 6))

    # Chart: monthly total transaction amount
    if month_totals:
        month_items = sorted(month_totals.items(), key=lambda x: x[0])[-6:]
        drawing2 = Drawing(520, 220)
        drawing2.add(String(0, 205, 'Monthly total transaction amount (last 6 months)', fontSize=10, fillColor=colors.HexColor('#2d3748')))
        bc = VerticalBarChart()
        bc.x = 40
        bc.y = 35
        bc.height = 140
        bc.width = 430
        bc.data = [[v for _, v in month_items]]
        bc.categoryAxis.categoryNames = [k for k, _ in month_items]
        bc.valueAxis.valueMin = 0
        bc.valueAxis.valueMax = max(v for _, v in month_items) * 1.1 if month_items else 1
        bc.valueAxis.valueStep = max(1, bc.valueAxis.valueMax / 4)
        bc.bars[0].fillColor = colors.HexColor('#4E79A7')
        drawing2.add(bc)
        story.append(drawing2)
        story.append(Spacer(1, 6))

    story.append(Paragraph('Flag Summary', h)); story.append(styled_table(flag_data)); story.append(Spacer(1, 6))
    story.append(Paragraph('Final Risk Decision', h)); story.append(styled_table(decision_data)); story.append(Spacer(1, 6))

    doc.build(story)
    data = buf.getvalue()
    return Response(content=data, media_type='application/pdf', headers={'Content-Disposition': f'attachment; filename="{client_id}_summary.pdf"'})


@router.get('/clients/{client_id}/connections')
def client_connections(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(or_(Transaction.client_id == client_id, Transaction.counterparty_id == client_id))
        .order_by(Transaction.timestamp.desc())
        .limit(6000)
    ).scalars().all()
    addresses = db.execute(
        select(ClientAddressHistory)
        .where(ClientAddressHistory.client_id == client_id)
        .order_by(ClientAddressHistory.from_date.desc())
        .limit(30)
    ).scalars().all()
    phones = db.execute(
        select(ClientPhoneHistory)
        .where(ClientPhoneHistory.client_id == client_id)
        .order_by(ClientPhoneHistory.from_date.desc())
        .limit(30)
    ).scalars().all()

    cp_ids = {
        t.counterparty_id if t.client_id == client_id else t.client_id
        for t in txs
        if (t.counterparty_id if t.client_id == client_id else t.client_id)
        and (t.counterparty_id if t.client_id == client_id else t.client_id) != client_id
    }
    counterparty_names = _resolve_counterparty_names(db, cp_ids)
    payload = _build_connection_payload(client, txs, addresses, phones, counterparty_names=counterparty_names)
    payload['summary'] = {
        'node_count': len(payload['nodes']),
        'edge_count': len(payload['edges']),
        'counterparty_count': sum(1 for n in payload['nodes'] if n.get('entity_type') == 'counterparty'),
        'linked_entities': len(payload['linked_entities']),
    }
    return payload


@router.get('/clients/{client_id}/connections/path/{counterparty_id}')
def client_connections_path(client_id: str, counterparty_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(or_(Transaction.client_id == client_id, Transaction.counterparty_id == client_id))
        .order_by(Transaction.timestamp.desc())
        .limit(6000)
    ).scalars().all()
    addresses = db.execute(select(ClientAddressHistory).where(ClientAddressHistory.client_id == client_id).limit(30)).scalars().all()
    phones = db.execute(select(ClientPhoneHistory).where(ClientPhoneHistory.client_id == client_id).limit(30)).scalars().all()
    cp_ids = {
        t.counterparty_id if t.client_id == client_id else t.client_id
        for t in txs
        if (t.counterparty_id if t.client_id == client_id else t.client_id)
        and (t.counterparty_id if t.client_id == client_id else t.client_id) != client_id
    }
    counterparty_names = _resolve_counterparty_names(db, cp_ids)
    payload = _build_connection_payload(client, txs, addresses, phones, counterparty_names=counterparty_names)

    start_id = f'client:{client_id}'
    end_id = f'counterparty:{counterparty_id}'
    nodes_by_id = {n['id']: n for n in payload['nodes']}
    if end_id not in nodes_by_id:
        raise HTTPException(status_code=404, detail='Counterparty not connected to client')

    path = _build_path(nodes_by_id, payload['edges'], start_id, end_id)
    if not path:
        raise HTTPException(status_code=404, detail='No path found')

    return {
        'client_id': client_id,
        'counterparty_id': counterparty_id,
        'counterparty_name': counterparty_names.get(counterparty_id) or _fallback_counterparty_name(counterparty_id),
        'path': path,
    }


@router.get('/network/{client_id}')
def network(client_id: str, depth: int = 1, db: Session = Depends(get_db)):
    base = db.execute(
        select(Transaction)
        .where(or_(Transaction.client_id == client_id, Transaction.counterparty_id == client_id))
        .order_by(Transaction.timestamp.desc())
        .limit(1000)
    ).scalars().all()

    nodes = {client_id}
    edges = []
    total_amount = 0.0
    for t in base:
        nodes.add(t.client_id)
        nodes.add(t.counterparty_id)
        total_amount += float(t.amount)
        edges.append(
            {
                'source': t.client_id,
                'target': t.counterparty_id,
                'amount': t.amount,
                'tx_type': t.tx_type,
                'timestamp': t.timestamp.isoformat(),
            }
        )

    return {
        'nodes': [{'id': n} for n in nodes],
        'edges': edges[:500],
        'depth': depth,
        'summary': {
            'counterparties': max(0, len(nodes) - 1),
            'connections': len(edges),
            'total_flow': round(total_amount, 2),
        },
    }


@router.get('/analytics/summary')
def summary(db: Session = Depends(get_db)):
    clients = db.scalar(select(func.count()).select_from(Client)) or 0
    txs = db.scalar(select(func.count()).select_from(Transaction)) or 0
    avg_risk = db.scalar(select(func.avg(RiskResult.risk_score))) or 0
    high_risk = db.scalar(select(func.count()).select_from(RiskResult).where(RiskResult.risk_score >= 70)) or 0
    by_rating = db.execute(select(Client.risk_rating, func.count()).group_by(Client.risk_rating)).all()

    alert_rows = db.execute(select(Alert.status, func.count()).group_by(Alert.status)).all()
    alert_status_counts = {status: count for status, count in alert_rows}

    return {
        'clients': clients,
        'transactions': txs,
        'avg_risk': round(float(avg_risk), 2),
        'high_risk': high_risk,
        'risk_rating_counts': {k: v for k, v in by_rating},
        'alert_status_counts': alert_status_counts,
    }


@router.get('/analytics/segments')
def segments(db: Session = Depends(get_db)):
    rows = db.execute(select(Client.segment, func.count()).group_by(Client.segment).order_by(Client.segment)).all()
    # enforce allowed list only
    out = [{'segment': segment, 'count': count} for segment, count in rows if segment in ALLOWED_SEGMENTS]
    return out


@router.get('/analytics/country-flow/{client_id}')
def country_flow_analytics(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(Transaction.client_id == client_id, Transaction.tx_type == 'wire')
        .order_by(Transaction.timestamp.desc())
        .limit(5000)
    ).scalars().all()

    by_country = {}
    total_in = 0.0
    total_out = 0.0
    high_risk_total = 0.0
    risk_tier_amounts = {'low': 0.0, 'medium': 0.0, 'high': 0.0}
    corridor_map = {}

    for t in txs:
        amt = float(t.amount)
        total_in += amt if t.direction == 'incoming' else 0.0
        total_out += amt if t.direction == 'outgoing' else 0.0
        tags = t.typology_tags or {}

        row = by_country.setdefault(
            t.country,
            {
                'country': t.country,
                'country_name': country_name(t.country),
                'inbound': 0.0,
                'outbound': 0.0,
                'total': 0.0,
                'risk_tier': tags.get('destination_country_risk_tier') or tags.get('wire_country_risk', 'medium'),
            },
        )
        row['inbound'] += amt if t.direction == 'incoming' else 0.0
        row['outbound'] += amt if t.direction == 'outgoing' else 0.0
        row['total'] += amt

        tier = row['risk_tier'] if row['risk_tier'] in risk_tier_amounts else 'medium'
        risk_tier_amounts[tier] += amt
        if tier == 'high':
            high_risk_total += amt

        src = tags.get('source_country') or (client.country if t.direction == 'outgoing' else t.country)
        dst = tags.get('destination_country') or (t.country if t.direction == 'outgoing' else client.country)
        key = f'{src}->{dst}'
        c = corridor_map.setdefault(
            key,
            {
                'corridor': key,
                'corridor_display': f"{country_name(src)} → {country_name(dst)}",
                'source_country': src,
                'source_country_name': country_name(src),
                'destination_country': dst,
                'destination_country_name': country_name(dst),
                'risk_tag': tags.get('corridor_risk_tag', 'medium'),
                'amount': 0.0,
                'tx_count': 0,
            },
        )
        c['amount'] += amt
        c['tx_count'] += 1

    total_wire = total_in + total_out
    countries = sorted(by_country.values(), key=lambda x: x['total'], reverse=True)
    for c in countries:
        c['share_pct'] = round((c['total'] / total_wire) * 100, 2) if total_wire > 0 else 0.0
        c['inbound'] = round(c['inbound'], 2)
        c['outbound'] = round(c['outbound'], 2)
        c['total'] = round(c['total'], 2)

    risk_tier_share = {
        k: {
            'amount': round(v, 2),
            'share_pct': round((v / total_wire) * 100, 2) if total_wire > 0 else 0.0,
        }
        for k, v in risk_tier_amounts.items()
    }

    return {
        'client_id': client_id,
        'totals': {
            'inbound': round(total_in, 2),
            'outbound': round(total_out, 2),
            'wire_total': round(total_wire, 2),
            'high_risk_total': round(high_risk_total, 2),
            'high_risk_ratio_pct': round((high_risk_total / total_wire) * 100, 2) if total_wire > 0 else 0.0,
            'inflow_outflow_imbalance': round(total_in - total_out, 2),
        },
        'countries': countries,
        'risk_tier_aggregation': risk_tier_share,
        'top_corridors': sorted(corridor_map.values(), key=lambda x: x['amount'], reverse=True)[:10],
    }


@router.get('/analytics/transaction-features/{client_id}')
def transaction_feature_summary(client_id: str, db: Session = Depends(get_db)):
    client = db.get(Client, client_id)
    if not client:
        raise HTTPException(status_code=404, detail='Client not found')

    txs = db.execute(
        select(Transaction)
        .where(Transaction.client_id == client_id)
        .order_by(Transaction.timestamp.desc())
        .limit(5000)
    ).scalars().all()

    type_mix = {}
    direction_mix = {'incoming': 0, 'outgoing': 0}
    channel_mix = {}
    suspicious_flags = {
        'cross_border': 0,
        'weekend': 0,
        'night': 0,
        'recurring': 0,
        'round_amount': 0,
        'high_risk_corridor': 0,
    }

    for t in txs:
        type_mix[t.tx_type] = type_mix.get(t.tx_type, 0) + 1
        direction_mix[t.direction] = direction_mix.get(t.direction, 0) + 1
        channel_mix[t.channel] = channel_mix.get(t.channel, 0) + 1
        tags = t.typology_tags or {}
        suspicious_flags['cross_border'] += int(tags.get('cross_border', 0))
        suspicious_flags['weekend'] += int(tags.get('weekend_flag', 0))
        suspicious_flags['night'] += int(tags.get('night_flag', 0))
        suspicious_flags['recurring'] += int(tags.get('recurring_flag', 0))
        suspicious_flags['round_amount'] += int(tags.get('round_amount_flag', 0))
        suspicious_flags['high_risk_corridor'] += int(tags.get('corridor_risk_tag') == 'high')

    total = len(txs)
    return {
        'client_id': client_id,
        'total_transactions': total,
        'mix': {
            'type': type_mix,
            'direction': direction_mix,
            'channel': channel_mix,
        },
        'suspicious_flags': suspicious_flags,
        'suspicious_ratios_pct': {
            k: round((v / total) * 100, 2) if total > 0 else 0.0 for k, v in suspicious_flags.items()
        },
    }


@router.get('/alerts/outstanding')
def outstanding_alerts(
    limit: int = Query(500, ge=1, le=5000),
    sort_by: str = Query('alert_age'),
    sort_dir: str = Query('desc'),
    db: Session = Depends(get_db),
):
    stmt = (
        select(Alert, Case, Client)
        .outerjoin(Case, Case.case_id == Alert.case_id)
        .outerjoin(Client, Client.client_id == Alert.client_id)
    )

    order_fn = desc if sort_dir.lower() != 'asc' else asc
    sort_expr = {
        'alert_age': Alert.created_at,
        'case_age': Case.opened_at,
        'status': Alert.status,
        'risk_level': _risk_rating_order_expr(Client.risk_rating),
    }.get(sort_by, Alert.created_at)

    rows = db.execute(stmt.order_by(order_fn(sort_expr), Alert.created_at.desc()).limit(limit)).all()
    now = datetime.utcnow()

    return [
        {
            'alert_id': a.alert_id,
            'client_id': a.client_id,
            'case_id': a.case_id,
            'severity': a.severity,
            'status': a.status,
            'created_at': a.created_at.isoformat(),
            'description': a.description,
            'flags': a.flags or {},
            'client_risk_level': client.risk_rating if client else None,
            'client_type': (client.client_type if client and client.client_type else None),
            'case_status': case_row.status if case_row else None,
            'case_opened_at': case_row.opened_at.isoformat() if case_row and case_row.opened_at else None,
            'alert_age_days': max(0, (now - a.created_at).days) if a.created_at else None,
            'case_age_days': max(0, (now - case_row.opened_at).days) if case_row and case_row.opened_at else None,
        }
        for a, case_row, client in rows
    ]


@router.post('/seed')
def seed(req: SeedRequest, db: Session = Depends(get_db)):
    job = enqueue_seed(req.clients, req.tx_per_client, req.batch_size)
    db.merge(SeedJob(job_id=job.id, status='queued', target_clients=req.clients, metadata_json=req.model_dump()))
    db.commit()
    return {'job_id': job.id, 'status': 'queued'}


@router.get('/seed/jobs')
def seed_jobs(limit: int = Query(5, ge=1, le=50), db: Session = Depends(get_db)):
    jobs = db.execute(select(SeedJob).order_by(SeedJob.updated_at.desc()).limit(limit)).scalars().all()
    return [
        {
            'job_id': j.job_id,
            'status': j.status,
            'target_clients': j.target_clients,
            'created_at': j.created_at.isoformat() if j.created_at else None,
            'updated_at': j.updated_at.isoformat() if j.updated_at else None,
            'metadata': j.metadata_json,
        }
        for j in jobs
    ]


@router.get('/seed/{job_id}')
def seed_status(job_id: str, db: Session = Depends(get_db)):
    job = db.get(SeedJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail='Seed job not found')
    return {
        'job_id': job_id,
        'status': job.status,
        'target_clients': job.target_clients,
        'created_at': job.created_at.isoformat() if job.created_at else None,
        'updated_at': job.updated_at.isoformat() if job.updated_at else None,
        'metadata': job.metadata_json,
    }
