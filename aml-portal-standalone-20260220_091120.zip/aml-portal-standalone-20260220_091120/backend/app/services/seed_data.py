import random
import uuid
from datetime import date, datetime, timedelta

from faker import Faker
from sqlalchemy import func, select, text

from app.models.entities import (
    Alert,
    Case,
    CaseNote,
    Client,
    ClientAddressHistory,
    ClientNameHistory,
    ClientPhoneHistory,
    LoginActivity,
    ReviewDecision,
    RiskDecisionLog,
    RiskResult,
    Transaction,
    WorldCheckHit,
)
from app.services.risk_engine import evaluate_client

fake = Faker()

# Keep explicit transaction type coverage for analyst workflows.
TX_TYPES = ['debit', 'credit', 'wire', 'cash', 'emt', 'card']
CHANNELS = ['branch', 'atm', 'mobile', 'online', 'api', 'swift', 'interac', 'agent']
SEGMENTS = [
    'white label ATM',
    'payment processor',
    'non profit',
    'gambling',
    'small business',
    'public company',
    'personal investment',
]
CLIENT_TYPES = ['personal', 'professional', 'small_business', 'commercial']
INDIVIDUAL_TYPES = {'personal', 'professional'}
SEGMENT_CODE_OPTIONS = [
    'FSRPEP',
    'GAMBLE',
    'CASHINTENSIVE',
    'PPP',
    'NONPROFIT',
    'ARMSDEALER',
    'AUTODEALER',
    'WLATM',
    'EMBASSY',
    'MSB',
    'CRYPTO',
    'HIGHRISKGEO',
]
CASE_STATUSES = ['Open', 'Close', 'Investigating', 'RFI']
TYPOLOGIES = [
    'normal_activity',
    'structuring',
    'layering',
    'rapid_in_out',
    'high_risk_corridor',
    'cash_intensive',
    'mule_flow',
    'trade_based',
]
PURPOSE_CODES = [
    'salary',
    'invoice',
    'loan_repayment',
    'charity',
    'trade_settlement',
    'family_support',
    'property',
    'crypto_fiat',
    'gaming_settlement',
    'atm_replenishment',
    'cash_pickup',
    'cross_border_support',
]

COUNTRY_RISK = {
    'US': 'low', 'CA': 'low', 'GB': 'low', 'DE': 'low', 'FR': 'low', 'AU': 'low', 'JP': 'low',
    'MX': 'medium', 'BR': 'medium', 'TR': 'medium', 'AE': 'medium', 'IN': 'medium', 'NG': 'medium',
    'RU': 'high', 'IR': 'high', 'SY': 'high', 'KP': 'high', 'AF': 'high', 'VE': 'high',
}
HIGH_RISK = {c for c, r in COUNTRY_RISK.items() if r == 'high'}
LOW_POOL = [c for c, r in COUNTRY_RISK.items() if r == 'low']
MED_POOL = [c for c, r in COUNTRY_RISK.items() if r == 'medium']
HIGH_POOL = list(HIGH_RISK)

SEGMENT_FLOW_FACTOR = {
    'white label ATM': 1.25,
    'payment processor': 1.55,
    'non profit': 0.72,
    'gambling': 1.45,
    'small business': 1.0,
    'public company': 1.7,
    'personal investment': 1.15,
}

TYPOLOGY_FLOW_FACTOR = {
    'normal_activity': 0.95,
    'structuring': 1.05,
    'layering': 1.35,
    'rapid_in_out': 1.22,
    'high_risk_corridor': 1.4,
    'cash_intensive': 0.9,
    'mule_flow': 1.15,
    'trade_based': 1.55,
}


def _cid(i: int) -> str:
    return f'C{i:08d}'


def _case_id(i: int) -> str:
    return f'CASE{i:08d}'


def _risk_rating(score: float) -> str:
    if score >= 90:
        return 'High3'
    if score >= 80:
        return 'High2'
    if score >= 70:
        return 'High1'
    if score >= 45:
        return 'Medium'
    return 'Standard'


def _sample_segment_codes(min_n: int = 1, max_n: int = 4) -> list[str]:
    count = random.randint(min_n, max_n)
    return random.sample(SEGMENT_CODE_OPTIONS, k=count)


def _build_individual_ids(country: str) -> list[dict]:
    return [
        {
            'id_type': 'passport',
            'id_number': f'P-{uuid.uuid4().hex[:9].upper()}',
            'issuing_country': country,
            'expiry_date': (date.today() + timedelta(days=random.randint(365, 3650))).isoformat(),
        },
        {
            'id_type': 'national_id',
            'id_number': f'NID-{uuid.uuid4().hex[:10].upper()}',
            'issuing_country': country,
            'expiry_date': (date.today() + timedelta(days=random.randint(365, 3650))).isoformat(),
        },
    ]


def _build_entity_ids(country: str) -> list[dict]:
    return [
        {
            'id_type': 'registration_number',
            'id_number': f'REG-{uuid.uuid4().hex[:10].upper()}',
            'issuing_country': country,
        },
        {
            'id_type': 'tax_id',
            'id_number': f'TAX-{uuid.uuid4().hex[:10].upper()}',
            'issuing_country': country,
        },
    ]


def _owner_profile() -> dict:
    return {
        'owner_name': fake.name(),
        'ownership_pct': round(random.uniform(10.0, 70.0), 2),
        'risk_profile': {
            'risk_level': random.choices(['Standard', 'Medium', 'High1', 'High2'], weights=[45, 30, 20, 5])[0],
            'segment_codes': _sample_segment_codes(1, 3),
        },
    }


def _build_alert_flags(client: Client, typology: str, tx_objs: list[Transaction]) -> dict:
    transaction_flags = []
    profile_flags = []

    high_risk_wire = any(
        (tx.tx_type in {'wire', 'emt'}) and ((tx.typology_tags or {}).get('corridor_risk_tag') == 'high')
        for tx in tx_objs
    )
    high_volume_cash = sum(float(tx.amount) for tx in tx_objs if tx.tx_type == 'cash') >= 90000
    high_total_dc = sum(float(tx.amount) for tx in tx_objs if tx.tx_type in {'debit', 'credit'}) >= 900000
    high_emt = sum(float(tx.amount) for tx in tx_objs if tx.tx_type == 'emt') >= 140000

    if high_risk_wire:
        transaction_flags.append({'code': 'HIGH_RISK_COUNTRY_WIRE', 'label': 'High risk country wire', 'severity': 'High'})
    if high_volume_cash:
        transaction_flags.append({'code': 'HIGH_VOLUME_CASH', 'label': 'High volume cash', 'severity': 'High'})
    if high_total_dc:
        transaction_flags.append({'code': 'HIGH_TOTAL_DEBIT_CREDIT', 'label': 'High total debit/credit', 'severity': 'Medium'})
    if high_emt:
        transaction_flags.append({'code': 'HIGH_EMT', 'label': 'High EMT', 'severity': 'Medium'})

    if client.pep_flag:
        profile_flags.append({'code': 'PEP', 'label': 'PEP exposure', 'severity': 'High'})
    if client.sanctions_flag:
        profile_flags.append({'code': 'RAI', 'label': 'RAI / sanctions indicator', 'severity': 'High'})
    if client.country in HIGH_RISK:
        profile_flags.append({'code': 'COUNTRY', 'label': 'High-risk profile country', 'severity': 'High'})
    if client.client_type not in INDIVIDUAL_TYPES and (client.entity_owners or []):
        owner_high = any((o.get('risk_profile') or {}).get('risk_level') in {'High1', 'High2', 'High3'} for o in client.entity_owners)
        if owner_high:
            profile_flags.append({'code': 'RELATED_PARTIES', 'label': 'Related parties elevated risk', 'severity': 'Medium'})

    if typology in {'layering', 'mule_flow', 'high_risk_corridor'} and not transaction_flags:
        transaction_flags.append({'code': 'TYPOLOGY_PATTERN', 'label': f'{typology.replace("_", " ").title()} pattern', 'severity': 'Medium'})

    return {
        'transaction_flags': transaction_flags,
        'profile_flags': profile_flags,
    }


def _pick_counter_country(home_country: str, tx_type: str, typology: str) -> str:
    cross_border_prob = 0.45
    if tx_type in {'wire', 'emt'}:
        cross_border_prob = 0.82
    if typology in {'layering', 'high_risk_corridor', 'mule_flow'}:
        cross_border_prob = 0.95

    if random.random() > cross_border_prob:
        return home_country

    if typology in {'high_risk_corridor', 'mule_flow'}:
        return random.choice(HIGH_POOL + MED_POOL)

    bucket = random.choices(['low', 'medium', 'high'], weights=[30, 42, 28])[0]
    pool = LOW_POOL if bucket == 'low' else MED_POOL if bucket == 'medium' else HIGH_POOL
    return random.choice(pool)


def _build_typology_flags(ts: datetime, amount: float, source_country: str, destination_country: str, tx_type: str, typology: str):
    src_risk = COUNTRY_RISK.get(source_country, 'medium')
    dst_risk = COUNTRY_RISK.get(destination_country, 'medium')
    corridor_high = src_risk == 'high' or dst_risk == 'high'
    corridor_med = src_risk == 'medium' or dst_risk == 'medium'
    corridor_risk_tag = 'high' if corridor_high else 'medium' if corridor_med else 'low'

    return {
        'typology': typology,
        'purpose_code': random.choice(PURPOSE_CODES),
        'source_country': source_country,
        'destination_country': destination_country,
        'source_country_risk_tier': src_risk,
        'destination_country_risk_tier': dst_risk,
        'corridor_risk_tag': corridor_risk_tag,
        'cross_border': int(source_country != destination_country),
        'round_amount_flag': int(abs(amount % 1000) < 0.01 or abs(amount % 5000) < 0.01),
        'near_threshold_flag': int(9800 <= amount <= 10000),
        'weekend_flag': int(ts.weekday() >= 5),
        'night_flag': int(ts.hour < 6 or ts.hour >= 22),
        'recurring_flag': int(random.random() < 0.24),
        'velocity_24h_count': random.randint(1, 12 if tx_type in {'wire', 'emt'} else 20),
        'velocity_7d_count': random.randint(3, 40 if tx_type in {'wire', 'emt'} else 55),
        'velocity_24h_amount': round(max(0.0, amount * random.uniform(1.2, 6.5)), 2),
        'velocity_7d_amount': round(max(0.0, amount * random.uniform(2.5, 14.0)), 2),
        'wire_country_risk': dst_risk if tx_type in {'wire', 'emt'} else src_risk,
    }


def _tx_count_for_client(base: int, typology: str) -> int:
    multiplier = random.uniform(1.35, 2.7)
    if typology in {'layering', 'mule_flow', 'rapid_in_out'}:
        multiplier = random.uniform(2.2, 4.2)
    if typology == 'trade_based':
        multiplier = random.uniform(1.8, 3.2)
    return max(base, int(base * multiplier))


def _client_debit_credit_target(segment: str, typology: str, annual_income: float) -> float:
    # Median around 800k, mean around ~1M once factors + outliers are applied.
    base = random.lognormvariate(13.6, 0.72)
    income_factor = max(0.7, min(1.65, (annual_income / 90000.0) ** 0.22))
    segment_factor = SEGMENT_FLOW_FACTOR.get(segment, 1.0)
    typology_factor = TYPOLOGY_FLOW_FACTOR.get(typology, 1.0)

    target = base * income_factor * segment_factor * typology_factor * 0.52
    if random.random() < 0.07:
        target *= random.uniform(2.5, 7.5)

    return float(min(max(target, 120000.0), 18000000.0))


def _history_transition_dates(open_date: date, now: date) -> tuple[date, date]:
    first_end = now - timedelta(days=random.randint(120, 320))
    if first_end <= open_date:
        first_end = open_date + timedelta(days=30)
    if first_end >= now:
        first_end = now - timedelta(days=1)

    second_start = first_end + timedelta(days=1)
    if second_start > now:
        second_start = now
    return first_end, second_start


def bulk_seed(db, clients: int = 6000, tx_per_client: int = 24, batch_size: int = 600):
    db.execute(text('SET synchronous_commit TO OFF'))
    created = 0
    tx_created = 0

    max_existing = db.execute(select(func.max(Client.client_id))).scalar_one_or_none()
    start_id = 1
    if max_existing and max_existing.startswith('C'):
        try:
            start_id = int(max_existing[1:]) + 1
        except Exception:
            start_id = 1

    for start in range(start_id, start_id + clients, batch_size):
        end = min(start + batch_size, start_id + clients)
        client_rows = []
        tx_rows = []
        risk_rows = []
        name_rows = []
        addr_rows = []
        phone_rows = []
        wc_rows = []
        case_rows = []
        note_rows = []
        alert_rows = []
        decision_rows = []
        review_rows = []
        login_rows = []

        for i in range(start, end):
            client_id = _cid(i)
            pep = 1 if random.random() < 0.055 else 0
            sanctions = 1 if random.random() < 0.012 else 0
            annual_income = float(max(15000, random.gauss(90000, 85000)))
            now = date.today()
            open_date = now - timedelta(days=random.randint(365, 3650))

            home_country = random.choices(LOW_POOL + MED_POOL + HIGH_POOL, weights=[6] * len(LOW_POOL) + [4] * len(MED_POOL) + [2] * len(HIGH_POOL))[0]
            segment = random.choice(SEGMENTS)
            client_type = random.choices(CLIENT_TYPES, weights=[38, 16, 28, 18])[0]
            current_segment_codes = _sample_segment_codes(1, 4)

            is_individual = client_type in INDIVIDUAL_TYPES
            resident_country = home_country if is_individual else None
            profile_ids = _build_individual_ids(home_country) if is_individual else _build_entity_ids(home_country)
            entity_owners = []
            entity_risk_profile = {}

            if is_individual:
                full_name = fake.name()
                dob = fake.date_of_birth(minimum_age=18, maximum_age=90)
                gender = random.choice(['M', 'F', 'X'])
                occupation = fake.job()
                entity_bsc_code = None
                entity_aml_business_type_code = None
                entity_sic_code = None
                registration_country = None
                domicile_country = None
                incorporation_country = None
                signing_officer = None
            else:
                full_name = fake.company()
                # Keep DOB populated for compatibility with older DBs that still enforce NOT NULL on dob.
                dob = fake.date_of_birth(minimum_age=18, maximum_age=90)
                gender = random.choice(['M', 'F', 'X'])
                occupation = 'entity'
                entity_bsc_code = f'BSC-{random.randint(100, 999)}'
                entity_aml_business_type_code = random.choice(['AML-BT-01', 'AML-BT-02', 'AML-BT-03', 'AML-BT-04'])
                entity_sic_code = str(random.randint(1000, 9999))
                registration_country = random.choice(LOW_POOL + MED_POOL)
                domicile_country = home_country
                incorporation_country = random.choice(LOW_POOL + MED_POOL + HIGH_POOL)
                signing_officer = fake.name()
                entity_owners = [_owner_profile() for _ in range(random.randint(1, 3))]
                entity_risk_profile = {
                    'risk_level': random.choice(['Medium', 'High1', 'High2']) if random.random() < 0.55 else 'Standard',
                    'segment_codes': _sample_segment_codes(1, 3),
                }

            c = Client(
                client_id=client_id,
                full_name=full_name,
                client_type=client_type,
                dob=dob,
                gender=gender,
                country=home_country,
                city=fake.city(),
                segment=segment,
                occupation=occupation,
                annual_income=annual_income,
                account_open_date=open_date,
                pep_flag=pep,
                sanctions_flag=sanctions,
                profile_text=f"Client {client_id} has {random.choice(['stable', 'expanding', 'volatile', 'bursty'])} transaction behavior.",
                resident_country=resident_country,
                profile_ids=profile_ids,
                current_segment_codes=current_segment_codes,
                entity_bsc_code=entity_bsc_code,
                entity_aml_business_type_code=entity_aml_business_type_code,
                entity_sic_code=entity_sic_code,
                registration_country=registration_country,
                domicile_country=domicile_country,
                incorporation_country=incorporation_country,
                signing_officer=signing_officer,
                entity_owners=entity_owners,
                entity_risk_profile=entity_risk_profile,
            )
            client_rows.append(c)

            first_end, second_start = _history_transition_dates(open_date, now)
            prev_name = fake.name() if is_individual else fake.company()
            name_rows.append(ClientNameHistory(client_id=client_id, full_name=prev_name, from_date=open_date, to_date=first_end))
            name_rows.append(ClientNameHistory(client_id=client_id, full_name=c.full_name, from_date=second_start, to_date=None))

            prev_addr_country = random.choice(LOW_POOL + MED_POOL + HIGH_POOL)
            addr_rows.append(ClientAddressHistory(
                client_id=client_id,
                address_line=fake.street_address(), city=fake.city(), country=prev_addr_country,
                from_date=open_date, to_date=first_end
            ))
            addr_rows.append(ClientAddressHistory(
                client_id=client_id,
                address_line=fake.street_address(), city=c.city, country=c.country,
                from_date=second_start, to_date=None
            ))

            phone_rows.append(ClientPhoneHistory(client_id=client_id, phone=fake.phone_number(), from_date=open_date, to_date=first_end))
            phone_rows.append(ClientPhoneHistory(client_id=client_id, phone=fake.phone_number(), from_date=second_start, to_date=None))

            if random.random() < 0.28:
                wc_rows.append(WorldCheckHit(
                    hit_id=f'WCH-{uuid.uuid4().hex[:20]}',
                    client_id=client_id,
                    category=random.choice(['sanctions', 'pep', 'adverse_media']),
                    match_score=round(random.uniform(78, 99.9), 2),
                    source=random.choice(['Dow Jones', 'World-Check', 'OpenSanctions']),
                    notes=fake.sentence(nb_words=12),
                ))

            tx_objs = []
            typology = random.choices(TYPOLOGIES, weights=[35, 10, 14, 12, 12, 6, 7, 4])[0]
            tx_count = _tx_count_for_client(tx_per_client, typology)
            target_dc_total = _client_debit_credit_target(segment, typology, annual_income)
            planned_dc_count = max(12, int(tx_count * random.uniform(0.42, 0.58)))
            dc_remaining_amount = target_dc_total
            dc_remaining_count = planned_dc_count

            required_types = ['debit', 'credit', 'wire', 'cash', 'emt']
            random.shuffle(required_types)

            for idx in range(tx_count):
                tx_type = required_types[idx] if idx < len(required_types) else random.choices(TX_TYPES, weights=[24, 24, 20, 10, 14, 8])[0]

                remaining_slots = tx_count - idx
                if dc_remaining_count >= remaining_slots:
                    tx_type = random.choice(['debit', 'credit'])

                direction = random.choice(['incoming', 'outgoing'])
                typology_force = idx >= len(required_types) and random.random() < 0.58

                if tx_type in {'debit', 'credit'}:
                    expected = dc_remaining_amount / max(1, dc_remaining_count)
                    expected = max(180.0, expected)
                    amount = round(max(25.0, random.gauss(expected, expected * 0.38)), 2)
                    amount = min(amount, max(220.0, expected * 3.4))
                    dc_remaining_amount -= amount
                    dc_remaining_count -= 1
                else:
                    base_amt = abs(random.gauss(3200, 10500)) + 30
                    if typology_force and typology == 'structuring':
                        base_amt = random.choice([9700, 9800, 9900, 9999, 10000])
                        tx_type = random.choice(['cash', 'wire', 'emt'])
                    elif typology_force and typology == 'layering':
                        tx_type = random.choice(['wire', 'emt'])
                        base_amt = abs(random.gauss(26000, 16500)) + 100
                    elif typology_force and typology == 'rapid_in_out':
                        tx_type = random.choice(['credit', 'debit', 'wire', 'emt'])
                        base_amt = abs(random.gauss(30000, 15000)) + 120
                    elif typology_force and typology == 'high_risk_corridor':
                        tx_type = random.choice(['wire', 'emt'])
                        base_amt = abs(random.gauss(36000, 24000)) + 250
                    elif typology_force and typology == 'cash_intensive':
                        tx_type = random.choice(['cash', 'debit'])
                        base_amt = abs(random.gauss(9800, 6200)) + 80
                    elif typology_force and typology == 'mule_flow':
                        tx_type = random.choice(['wire', 'emt', 'credit'])
                        base_amt = abs(random.gauss(17000, 9800)) + 90
                    elif typology_force and typology == 'trade_based':
                        tx_type = random.choice(['wire', 'credit'])
                        base_amt = abs(random.gauss(52000, 32000)) + 550
                    amount = float(round(base_amt, 2))

                ts = datetime.utcnow() - timedelta(days=random.randint(0, 364), hours=random.randint(0, 23), minutes=random.randint(0, 59))
                counter_country = _pick_counter_country(c.country, tx_type, typology)
                source_country = c.country if direction == 'outgoing' else counter_country
                destination_country = counter_country if direction == 'outgoing' else c.country
                tags = _build_typology_flags(ts, amount, source_country, destination_country, tx_type, typology)
                if typology in {'structuring', 'mule_flow'}:
                    tags['signal'] = 'near_threshold'
                if typology in {'layering', 'rapid_in_out'}:
                    tags['burst_signal'] = 1

                tx = Transaction(
                    tx_id=uuid.uuid4().hex,
                    client_id=client_id,
                    counterparty_id=_cid(random.randint(max(1, start_id), i)),
                    tx_type=tx_type,
                    direction=direction,
                    amount=amount,
                    currency=random.choice(['USD', 'CAD', 'EUR']),
                    channel=random.choice(CHANNELS),
                    country=counter_country,
                    timestamp=ts,
                    typology_tags=tags,
                )
                tx_objs.append(tx)
                tx_rows.append(tx)

            tx_created += len(tx_objs)
            score, hits, explain = evaluate_client(tx_objs, pep, sanctions)
            rating = _risk_rating(score)
            c.risk_rating = rating
            risk_rows.append(RiskResult(client_id=client_id, risk_score=score, rule_hits=hits, model_reason=explain))

            if random.random() < 0.56:
                case_id = _case_id(i)
                opened_at = datetime.utcnow() - timedelta(days=random.randint(1, 365))
                status = random.choice(CASE_STATUSES)
                case_rows.append(Case(
                    case_id=case_id,
                    client_id=client_id,
                    status=status,
                    opened_at=opened_at,
                    closed_at=(opened_at + timedelta(days=random.randint(5, 120))) if status == 'Close' else None,
                    title=f'Investigate unusual {random.choice(["wire activity", "cash flow", "counterparty behavior", "cross-border EMT pattern"])}',
                ))
                note_rows.append(CaseNote(note_id=f'NOTE-{uuid.uuid4().hex[:20]}', case_id=case_id, created_at=opened_at + timedelta(days=1), note='Initial case triage completed.'))
                note_rows.append(CaseNote(note_id=f'NOTE-{uuid.uuid4().hex[:20]}', case_id=case_id, created_at=opened_at + timedelta(days=3), note='Requested supporting transaction evidence.'))

                for _ in range(random.randint(2, 5)):
                    alert_rows.append(Alert(
                        alert_id=f'AL-{uuid.uuid4().hex[:22]}',
                        client_id=client_id,
                        case_id=case_id,
                        severity=random.choices(['Low', 'Medium', 'High'], weights=[15, 40, 45])[0],
                        status=random.choice(['Open', 'Open', 'Investigating', 'Closed']),
                        created_at=datetime.utcnow() - timedelta(days=random.randint(0, 180)),
                        description=f'Alert triggered by {random.choice(["wire corridor risk", "structuring", "rapid in-out", "unusual EMT burst", "cash threshold clustering"])}',
                        flags=_build_alert_flags(c, typology, tx_objs),
                    ))

            decision_reason = random.choice([
                'Increased wire/EMT exposure to high-risk corridor',
                'Improved source-of-funds documentation',
                'No material change in customer behavior',
                'Multiple near-threshold cash events observed',
            ])
            decision_action = random.choice(['up-risk', 'up-risk', 'down-risk', 'no-change'])
            decision_rows.append(RiskDecisionLog(
                decision_id=f'DEC-{uuid.uuid4().hex[:20]}',
                client_id=client_id,
                action=decision_action,
                reason=decision_reason,
                created_at=datetime.utcnow() - timedelta(days=random.randint(0, 180)),
            ))
            review_rows.append(ReviewDecision(
                decision_id=f'RVW-{uuid.uuid4().hex[:20]}',
                client_id=client_id,
                username=random.choice(['analyst_a', 'analyst_b', 'aml_lead']),
                risk_level=random.choice(['Standard', 'Medium', 'High1', 'High2', 'High3']),
                segment_codes=_sample_segment_codes(1, 3),
                description=decision_reason,
                created_at=datetime.utcnow() - timedelta(days=random.randint(0, 180)),
            ))

            login_events = random.randint(24, 120)
            login_countries = [c.country]
            if random.random() < 0.58:
                login_countries.append(random.choice(MED_POOL))
            if random.random() < 0.3:
                login_countries.append(random.choice(HIGH_POOL))

            run_count = random.randint(3, min(10, login_events))
            remaining = login_events
            logged_at = datetime.utcnow() - timedelta(days=random.randint(45, 360))
            for run_idx in range(run_count):
                if run_idx == run_count - 1:
                    this_run = remaining
                else:
                    min_remaining = run_count - run_idx - 1
                    this_run = random.randint(2, max(2, remaining - min_remaining))
                remaining -= this_run

                ip_country = random.choice(login_countries)
                for _ in range(this_run):
                    logged_at += timedelta(hours=random.randint(3, 36), minutes=random.randint(0, 59))
                    status = random.choices(['success', 'failed'], weights=[84, 16])[0]
                    login_rows.append(LoginActivity(
                        login_id=f'LG-{uuid.uuid4().hex[:24]}',
                        client_id=client_id,
                        ip_address=f"{random.randint(11, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}",
                        ip_country=ip_country,
                        status=status,
                        channel=random.choice(['web', 'mobile', 'api']),
                        logged_in_at=logged_at,
                    ))

        db.bulk_save_objects(client_rows)
        db.bulk_save_objects(tx_rows)
        db.bulk_save_objects(risk_rows)
        db.bulk_save_objects(name_rows)
        db.bulk_save_objects(addr_rows)
        db.bulk_save_objects(phone_rows)
        db.bulk_save_objects(wc_rows)
        db.bulk_save_objects(case_rows)
        db.bulk_save_objects(note_rows)
        db.bulk_save_objects(alert_rows)
        db.bulk_save_objects(decision_rows)
        db.bulk_save_objects(review_rows)
        db.bulk_save_objects(login_rows)
        db.commit()
        created += len(client_rows)

    return {'clients': created, 'transactions': tx_created}
