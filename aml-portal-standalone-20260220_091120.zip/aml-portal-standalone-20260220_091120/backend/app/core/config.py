from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    app_name: str = 'AML Portal'
    env: str = 'local'
    database_url: str = 'postgresql+psycopg://aml:aml@localhost:5433/aml_portal'
    redis_url: str = 'redis://localhost:6380/0'
    reset_schema_on_start: bool = False


settings = Settings()
