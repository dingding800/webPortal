#!/usr/bin/env bash
set -euo pipefail
BASE=${1:-http://localhost:8001/api}

ALLOWED='["white label ATM","payment processor","non profit","gambling","small business","public company","personal investment"]'
REQUIRED_CODES='["FSRPEP","GAMBLE","CASHINTENSIVE","PPP","NONPROFIT","ARMSDEALER","AUTODEALER","WLATM","EMBASSY"]'

echo "[targeted] segments constrained"
SEG=$(curl -sf "$BASE/analytics/segments")
python3 - <<'PY' "$SEG" "$ALLOWED"
import json,sys
rows=json.loads(sys.argv[1]); allowed=set(json.loads(sys.argv[2]))
found={r['segment'] for r in rows}
assert found.issubset(allowed), f"unexpected segments: {found-allowed}"
print('ok')
PY

echo "[targeted] segment code catalog"
CODES=$(curl -sf "$BASE/segment-codes")
python3 - <<'PY' "$CODES" "$REQUIRED_CODES"
import json,sys
rows=json.loads(sys.argv[1]); required=set(json.loads(sys.argv[2]))
found={r['code'] for r in rows}
missing=required-found
assert not missing, f"missing required segment codes: {sorted(missing)}"
print('ok')
PY

echo "[targeted] client detail has expanded profile"
CID=$(curl -sf "$BASE/clients?page=1&page_size=1" | jq -r '.items[0].client_id')
DET=$(curl -sf "$BASE/clients/$CID")
python3 - <<'PY' "$DET"
import json,sys
x=json.loads(sys.argv[1])
client=x.get('client', {})
assert client.get('client_type'), 'client_type missing'
assert 'current_risk_profile' in client, 'current_risk_profile missing'
assert 'profile_ids' in client, 'profile_ids missing'
ctype=client.get('client_type')
if ctype in {'personal','professional'}:
    assert client.get('individual_profile'), 'individual_profile missing'
else:
    ent=client.get('entity_profile')
    assert ent, 'entity_profile missing'
    for k in ['bsc_code','aml_business_type_code','sic_code','registration_country','domicile_country','incorporation_country','signing_officer','owners','entity_risk_profile']:
        assert k in ent, f"missing entity field {k}"

for k in ['history','world_check_hits','cases','alerts','wire_country_breakdown','risk_decisions','flag_summary']:
    assert k in x, f"missing {k}"

txs=x.get('transactions', [])
assert txs, 'transactions missing'
assert all('counterparty_name' in t for t in txs[:20]), 'counterparty_name missing on transactions'
print('ok')
PY

echo "[targeted] login activity grouped by country runs"
LOG=$(curl -sf "$BASE/clients/$CID/login-activity?limit=400")
python3 - <<'PY' "$LOG"
import json,sys
x=json.loads(sys.argv[1])
assert 'country_runs' in x, 'country_runs missing'
assert isinstance(x['country_runs'], list), 'country_runs should be list'
if x['country_runs']:
    run=x['country_runs'][0]
    for k in ['country','start_date','end_date','period','login_count']:
        assert k in run, f"missing run key {k}"
print('ok')
PY

echo "[targeted] review decision write path"
RD=$(curl -sf -X POST "$BASE/clients/$CID/review-decision" -H 'Content-Type: application/json' \
  -d '{"username":"targeted_test","risk_level":"Medium","segment_codes":["FSRPEP","WLATM"],"description":"targeted decision test"}')
echo "$RD" | jq -e '.status=="ok" and (.decision_id|length>0)' >/dev/null
DET2=$(curl -sf "$BASE/clients/$CID")
python3 - <<'PY' "$DET2"
import json,sys
x=json.loads(sys.argv[1])
decisions=x.get('risk_decisions', [])
assert decisions, 'risk decisions missing after submit'
assert any(d.get('description') == 'targeted decision test' for d in decisions), 'submitted review decision not found'
print('ok')
PY

echo "[targeted] alerts queue sort payload"
ALERTS=$(curl -sf "$BASE/alerts/outstanding?sort_by=risk_level&sort_dir=desc&limit=50")
python3 - <<'PY' "$ALERTS"
import json,sys
rows=json.loads(sys.argv[1])
assert isinstance(rows, list), 'alerts response should be list'
if rows:
    row=rows[0]
    for k in ['alert_id','status','severity','client_risk_level','alert_age_days','case_age_days']:
        assert k in row, f"missing alert field {k}"
print('ok')
PY

echo "[targeted] export endpoints"
HTTP_CSV=$(curl -s -o /tmp/aml_tx_export.csv -w '%{http_code}' "$BASE/clients/$CID/export/transactions.csv")
[ "$HTTP_CSV" = "200" ] && head -n 1 /tmp/aml_tx_export.csv | grep -q 'tx_id,timestamp,tx_type'
HTTP_JSON=$(curl -s -o /tmp/aml_dossier.json -w '%{http_code}' "$BASE/clients/$CID/export/dossier.json")
[ "$HTTP_JSON" = "200" ] && jq -e '.client.client_id == "'$CID'"' /tmp/aml_dossier.json >/dev/null

echo "[targeted] case status update endpoint"
CASE_ID=$(echo "$DET" | jq -r '.cases[0].case_id // empty')
if [ -n "$CASE_ID" ]; then
  curl -sf -X POST "$BASE/cases/$CASE_ID/status" -H 'Content-Type: application/json' \
    -d '{"status":"Investigating","reason":"targeted-api-test"}' | jq -e '.status=="ok"' >/dev/null
fi

echo "targeted tests passed"
