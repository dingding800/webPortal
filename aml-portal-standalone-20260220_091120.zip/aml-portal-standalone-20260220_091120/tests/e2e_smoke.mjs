import assert from 'node:assert/strict'
import { chromium } from 'playwright'

const FRONTEND = process.env.AML_FRONTEND_URL || 'http://localhost:5174'

const toNum = (text) => Number(String(text || '').replace(/[^0-9.]/g, '') || 0)

const run = async () => {
  const browser = await chromium.launch({ headless: true })
  const page = await browser.newPage()

  try {
    await page.goto(FRONTEND, { waitUntil: 'domcontentloaded', timeout: 60000 })
    await page.getByRole('heading', { name: 'AML Portal' }).waitFor({ timeout: 30000 })

    // API health/list/details reflected in loaded dashboard + clients list
    const totalClientsText = await page.locator('.mini-kpi b').first().textContent()
    assert.ok(toNum(totalClientsText) > 0, `Expected seeded clients > 0, got: ${totalClientsText}`)

    const firstClientBtn = page.locator('.client-list .client-item').first()
    await firstClientBtn.waitFor({ timeout: 30000 })
    await firstClientBtn.click()

    await page.locator('.detail-header h2').waitFor({ timeout: 30000 })

    // Risk "why flagged"
    await page.getByRole('heading', { name: 'Why flagged' }).waitFor({ timeout: 15000 })
    const flagCards = page.locator('.flag-card')
    assert.ok(await flagCards.count() >= 4, 'Expected at least 4 why-flagged cards')

    // Transactions tab
    await page.getByRole('button', { name: 'Transactions' }).click()
    await page.getByRole('heading', { name: /All transactions \(/ }).waitFor({ timeout: 15000 })
    const txRows = page.locator('.tx-scroll table tbody tr')
    assert.ok(await txRows.count() > 0, 'Expected at least one transaction row')

    const txSummary = page.locator('.tx-type-summary')
    await txSummary.waitFor({ timeout: 15000 })
    await page.getByText('Overall transaction type composition').first().waitFor({ timeout: 15000 })
    const legendRows = page.locator('.tx-type-summary .tx-summary-legend .legend-row')
    assert.equal(await legendRows.count(), 8, 'Expected 8 transaction summary categories in legend')
    const headingText = (await page.getByRole('heading', { name: /All transactions \(/ }).textContent()) || ''
    const totalTx = Number((headingText.match(/All transactions \((\d+)\)/) || [])[1] || 0)
    assert.ok(totalTx > 0, `Expected parsed transaction total > 0 from heading: ${headingText}`)

    const categoryCountTotal = await page.evaluate(() => {
      const rows = [...document.querySelectorAll('.tx-type-summary .tx-summary-legend .legend-row small')]
      return rows.reduce((sum, row) => {
        const m = (row.textContent || '').match(/\((\d+)\)$/)
        return sum + Number(m ? m[1] : 0)
      }, 0)
    })
    const uncategorizedText = (await page.locator('.tx-type-summary').textContent()) || ''
    const uncategorized = Number((uncategorizedText.match(/Uncategorized transactions:\s*(\d+)/) || [])[1] || 0)
    assert.equal(categoryCountTotal + uncategorized, totalTx, 'Summary category counts should reconcile to transaction total')

    // Connections tab (graph + linked entities + evidence drawer)
    await page.getByRole('button', { name: 'Connections' }).click()
    await page.getByRole('heading', { name: 'Connected-entity network' }).waitFor({ timeout: 15000 })
    await page.locator('[data-testid="connections-graph"]').waitFor({ timeout: 15000 })
    const firstGraphNode = page.locator('.graph-node').first()
    await firstGraphNode.click()
    await page.locator('[data-testid="link-evidence-panel"]').waitFor({ timeout: 15000 })

    const firstEvidenceBtn = page.locator('.linked-entities-scroll button', { hasText: 'Evidence' }).first()
    await firstEvidenceBtn.click()
    await page.locator('[data-testid="link-evidence-panel"]').waitFor({ timeout: 15000 })

    const traceBtn = page.locator('.linked-entities-scroll button', { hasText: 'Trace' }).first()
    if (await traceBtn.count()) {
      await traceBtn.click()
      await page.getByText(/Path hops:/).first().waitFor({ timeout: 15000 })
    }

    // Alerts click-through
    const firstAlertBtn = page.locator('.compact-list .link-btn').first()
    await firstAlertBtn.waitFor({ timeout: 15000 })
    const firstAlertText = (await firstAlertBtn.textContent()) || ''
    const alertClientId = (firstAlertText.match(/C\d+/) || [])[0]
    assert.ok(alertClientId, `Unable to parse alert client id from: ${firstAlertText}`)
    await firstAlertBtn.click()
    await page.locator('.detail-header h2').waitFor({ timeout: 15000 })
    await expectClientVisible(page, alertClientId)

    // Login Activity tab
    await page.getByRole('button', { name: 'Login Activity' }).click()
    await page.getByRole('heading', { name: /Historical login records/ }).waitFor({ timeout: 15000 })
    const loginRows = page.locator('.tx-scroll table tbody tr')
    assert.ok(await loginRows.count() > 0, 'Expected at least one login activity row')

    console.log('E2E smoke passed: dashboard, client detail, why flagged, transactions, connections graph/evidence/path, alerts click-through, login activity')
  } finally {
    await browser.close()
  }
}

const expectClientVisible = async (page, clientId) => {
  await page.waitForFunction(
    (target) => {
      const el = document.querySelector('.detail-header h2')
      return !!el && (el.textContent || '').includes(target)
    },
    clientId,
    { timeout: 30000 }
  )
}

run().catch((err) => {
  console.error(err)
  process.exit(1)
})
