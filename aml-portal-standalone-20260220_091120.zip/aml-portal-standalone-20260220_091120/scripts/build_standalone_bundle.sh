#!/usr/bin/env bash
set -euo pipefail

# Builds a copyable AML portal bundle for restricted machines.
# Result: ../dist/aml-portal-standalone-<timestamp>.tar.gz

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="$ROOT/dist"
STAMP="$(date +%Y%m%d_%H%M%S)"
BUNDLE_DIR="$OUT_DIR/aml-portal-standalone-$STAMP"

mkdir -p "$OUT_DIR"
rm -rf "$BUNDLE_DIR"
mkdir -p "$BUNDLE_DIR"

echo "[1/5] Preparing frontend build..."
(
  cd "$ROOT/frontend"
  npm ci
  npm run build
)

echo "[2/5] Copying app files..."
rsync -a \
  --exclude '.git' \
  --exclude '.venv' \
  --exclude '__pycache__' \
  --exclude '*.pyc' \
  --exclude 'node_modules' \
  --exclude 'tmp_*.log' \
  "$ROOT/" "$BUNDLE_DIR/"

# Ensure built frontend is present.
mkdir -p "$BUNDLE_DIR/frontend/dist"
rsync -a "$ROOT/frontend/dist/" "$BUNDLE_DIR/frontend/dist/"

echo "[3/5] Generating runtime config template..."
cat > "$BUNDLE_DIR/.env.standalone.example" <<'EOF'
# Local-only bind
HOST=127.0.0.1
API_PORT=8001
WEB_PORT=5174

# Prefer Postgres if available, otherwise use SQLite (uncomment one)
DATABASE_URL=postgresql+psycopg://aml:aml@127.0.0.1:5432/aml_portal
# DATABASE_URL=sqlite:///./data/aml_portal.db

# Optional worker queue
REDIS_URL=redis://127.0.0.1:6379/0

# Keep false unless you intentionally want schema reset
RESET_SCHEMA_ON_START=false
EOF

echo "[4/5] Adding portable start/stop scripts..."
mkdir -p "$BUNDLE_DIR/scripts"
cat > "$BUNDLE_DIR/scripts/start_standalone.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [ -f .env.standalone ]; then
  export $(grep -v '^#' .env.standalone | xargs)
fi

export HOST="${HOST:-127.0.0.1}"
export API_PORT="${API_PORT:-8001}"
export WEB_PORT="${WEB_PORT:-5174}"
export DATABASE_URL="${DATABASE_URL:-sqlite:///./data/aml_portal.db}"
export REDIS_URL="${REDIS_URL:-redis://127.0.0.1:6379/0}"
export RESET_SCHEMA_ON_START="${RESET_SCHEMA_ON_START:-false}"

mkdir -p "$ROOT/data" "$ROOT/logs"

# Use project-local Python if provided, else system python3
PY_BIN="${PY_BIN:-python3}"
if [ -x "$ROOT/runtime/python/bin/python3" ]; then
  PY_BIN="$ROOT/runtime/python/bin/python3"
fi

# Create local venv on first run (inside bundle)
if [ ! -d "$ROOT/.venv" ]; then
  "$PY_BIN" -m venv "$ROOT/.venv"
  "$ROOT/.venv/bin/pip" install --upgrade pip
  "$ROOT/.venv/bin/pip" install -r "$ROOT/backend/requirements.txt"
fi

# Frontend static serving only; no Node required on target
pkill -f "uvicorn app.main:app --host $HOST --port $API_PORT" >/dev/null 2>&1 || true
pkill -f "python -m app.workers.worker" >/dev/null 2>&1 || true
pkill -f "http.server $WEB_PORT --directory $ROOT/frontend/dist" >/dev/null 2>&1 || true

export PYTHONPATH="$ROOT/backend"
nohup "$ROOT/.venv/bin/uvicorn" app.main:app --host "$HOST" --port "$API_PORT" > "$ROOT/logs/backend.log" 2>&1 &
nohup "$ROOT/.venv/bin/python" -m app.workers.worker > "$ROOT/logs/worker.log" 2>&1 &
nohup "$ROOT/.venv/bin/python" -m http.server "$WEB_PORT" --directory "$ROOT/frontend/dist" > "$ROOT/logs/frontend.log" 2>&1 &

echo "Started"
echo "API:  http://$HOST:$API_PORT"
echo "Web:  http://$HOST:$WEB_PORT"
echo "Logs: $ROOT/logs"
EOF

cat > "$BUNDLE_DIR/scripts/stop_standalone.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

if [ -f .env.standalone ]; then
  export $(grep -v '^#' .env.standalone | xargs)
fi
HOST="${HOST:-127.0.0.1}"
API_PORT="${API_PORT:-8001}"
WEB_PORT="${WEB_PORT:-5174}"

pkill -f "uvicorn app.main:app --host $HOST --port $API_PORT" >/dev/null 2>&1 || true
pkill -f "python -m app.workers.worker" >/dev/null 2>&1 || true
pkill -f "http.server $WEB_PORT --directory $ROOT/frontend/dist" >/dev/null 2>&1 || true

echo "Stopped"
EOF

chmod +x "$BUNDLE_DIR/scripts/start_standalone.sh" "$BUNDLE_DIR/scripts/stop_standalone.sh"

echo "[5/5] Packaging..."
(
  cd "$OUT_DIR"
  tar -czf "aml-portal-standalone-$STAMP.tar.gz" "aml-portal-standalone-$STAMP"
)

echo "Bundle created: $OUT_DIR/aml-portal-standalone-$STAMP.tar.gz"
