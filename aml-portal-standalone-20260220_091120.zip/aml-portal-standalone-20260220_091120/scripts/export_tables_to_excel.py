#!/usr/bin/env python3
import json
from datetime import datetime
from pathlib import Path

import pandas as pd
from sqlalchemy import create_engine, text

from app.core.config import settings


def fetch_df(engine, query: str) -> pd.DataFrame:
    return pd.read_sql(text(query), engine)


def main():
    workspace = Path('/Users/dingceliu/.openclaw/workspace')
    out_dir = workspace / 'reports'
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    out_path = out_dir / f'aml_portal_data_review_{stamp}.xlsx'

    engine = create_engine(settings.database_url)

    tx_limit = 120000
    login_limit = 90000

    sheets = {
        'clients': 'SELECT * FROM clients ORDER BY client_id',
        'risk_results': 'SELECT * FROM risk_results ORDER BY client_id',
        'transactions': f"""
            SELECT
              tx_id,
              client_id,
              counterparty_id,
              tx_type,
              direction,
              amount,
              currency,
              channel,
              country,
              timestamp,
              typology_tags->>'typology' AS typology,
              typology_tags->>'purpose_code' AS purpose_code,
              typology_tags->>'corridor_risk_tag' AS corridor_risk_tag,
              typology_tags->>'source_country' AS source_country,
              typology_tags->>'destination_country' AS destination_country,
              typology_tags->>'cross_border' AS cross_border,
              typology_tags->>'near_threshold_flag' AS near_threshold_flag,
              typology_tags->>'round_amount_flag' AS round_amount_flag,
              typology_tags->>'weekend_flag' AS weekend_flag,
              typology_tags->>'night_flag' AS night_flag
            FROM transactions
            ORDER BY timestamp DESC
            LIMIT {tx_limit}
        """,
        'counterparties': """
            SELECT
              t.counterparty_id,
              COUNT(*) AS tx_count,
              COUNT(DISTINCT t.client_id) AS unique_clients,
              SUM(t.amount) AS total_amount,
              SUM(CASE WHEN t.direction='incoming' THEN t.amount ELSE 0 END) AS inbound_amount,
              SUM(CASE WHEN t.direction='outgoing' THEN t.amount ELSE 0 END) AS outbound_amount,
              MAX(t.timestamp) AS last_seen
            FROM transactions t
            GROUP BY t.counterparty_id
            ORDER BY total_amount DESC
        """,
        'cases': 'SELECT * FROM cases ORDER BY opened_at DESC',
        'alerts': 'SELECT * FROM alerts ORDER BY created_at DESC',
        'case_notes': 'SELECT * FROM case_notes ORDER BY created_at DESC',
        'login_activity': f'SELECT login_id, client_id, ip_address, ip_country, status, channel, logged_in_at FROM login_activity ORDER BY logged_in_at DESC LIMIT {login_limit}',
        'name_history': 'SELECT * FROM client_name_history ORDER BY client_id, from_date DESC',
        'address_history': 'SELECT * FROM client_address_history ORDER BY client_id, from_date DESC',
        'phone_history': 'SELECT * FROM client_phone_history ORDER BY client_id, from_date DESC',
        'world_check_hits': 'SELECT * FROM world_check_hits ORDER BY client_id',
        'risk_decisions': 'SELECT * FROM risk_decision_logs ORDER BY created_at DESC',
        'seed_jobs': 'SELECT * FROM seed_jobs ORDER BY updated_at DESC',
    }

    extracted_counts = {}
    source_counts = {}

    source_count_queries = {
        'clients': 'SELECT COUNT(*) AS n FROM clients',
        'risk_results': 'SELECT COUNT(*) AS n FROM risk_results',
        'transactions': 'SELECT COUNT(*) AS n FROM transactions',
        'counterparties': 'SELECT COUNT(DISTINCT counterparty_id) AS n FROM transactions',
        'cases': 'SELECT COUNT(*) AS n FROM cases',
        'alerts': 'SELECT COUNT(*) AS n FROM alerts',
        'case_notes': 'SELECT COUNT(*) AS n FROM case_notes',
        'login_activity': 'SELECT COUNT(*) AS n FROM login_activity',
        'name_history': 'SELECT COUNT(*) AS n FROM client_name_history',
        'address_history': 'SELECT COUNT(*) AS n FROM client_address_history',
        'phone_history': 'SELECT COUNT(*) AS n FROM client_phone_history',
        'world_check_hits': 'SELECT COUNT(*) AS n FROM world_check_hits',
        'risk_decisions': 'SELECT COUNT(*) AS n FROM risk_decision_logs',
        'seed_jobs': 'SELECT COUNT(*) AS n FROM seed_jobs',
    }

    with pd.ExcelWriter(out_path, engine='openpyxl') as writer:
        for sheet_name, query in sheets.items():
            df = fetch_df(engine, query)
            extracted_counts[sheet_name] = int(len(df))
            source_counts[sheet_name] = int(pd.read_sql(text(source_count_queries[sheet_name]), engine)['n'].iloc[0])
            df.to_excel(writer, sheet_name=sheet_name[:31], index=False)

        summary_df = pd.DataFrame([
            {
                'sheet': k,
                'source_rows': source_counts[k],
                'exported_rows': extracted_counts[k],
                'is_truncated': extracted_counts[k] < source_counts[k],
            }
            for k in sheets.keys()
        ])
        summary_df.to_excel(writer, sheet_name='export_summary', index=False)

    print(json.dumps({'workbook': str(out_path), 'row_counts': extracted_counts, 'source_counts': source_counts}, indent=2))


if __name__ == '__main__':
    main()
