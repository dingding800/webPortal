#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

brew services start postgresql@16 >/dev/null || true
brew services start redis >/dev/null || true

export PATH="/opt/homebrew/opt/postgresql@16/bin:$PATH"
psql -d postgres -tc "SELECT 1 FROM pg_roles WHERE rolname='aml'" | grep -q 1 || psql -d postgres -c "CREATE ROLE aml LOGIN PASSWORD 'aml';"
psql -d postgres -tc "SELECT 1 FROM pg_database WHERE datname='aml_portal'" | grep -q 1 || psql -d postgres -c "CREATE DATABASE aml_portal OWNER aml;"

if [ ! -d .venv ]; then
  /opt/homebrew/bin/python3.13 -m venv .venv
  source .venv/bin/activate
  pip install -U pip
  pip install -r backend/requirements.txt
else
  source .venv/bin/activate
fi

(cd frontend && npm install >/dev/null && npm run build >/dev/null)

export DATABASE_URL='postgresql+psycopg://aml:aml@localhost:5432/aml_portal'
export REDIS_URL='redis://localhost:6379/0'
export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES
export PYTHONPATH="$ROOT/backend"
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

pkill -f 'uvicorn app.main:app --host 0.0.0.0 --port 8001' || true
pkill -f 'python -m app.workers.worker' || true
pkill -f 'http.server 5174' || true

nohup "$ROOT/.venv/bin/uvicorn" app.main:app --host 0.0.0.0 --port 8001 > tmp_backend.log 2>&1 &
nohup "$ROOT/.venv/bin/python" -m app.workers.worker > tmp_worker.log 2>&1 &
nohup /opt/homebrew/bin/python3 -m http.server 5174 --directory "$ROOT/frontend/dist" > tmp_frontend.log 2>&1 &

echo "Started: API http://localhost:8001, Frontend http://localhost:5174 (static build)"
