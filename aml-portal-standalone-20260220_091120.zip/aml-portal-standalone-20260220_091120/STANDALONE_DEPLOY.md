# AML Portal Standalone Deploy (Restricted Work PC)

This package is designed for machines where global installs are restricted.

## 1) Build bundle on your current machine

```bash
cd /Users/dingceliu/.openclaw/workspace/aml-portal
chmod +x scripts/build_standalone_bundle.sh
./scripts/build_standalone_bundle.sh
```

Output will be under:

- `dist/aml-portal-standalone-<timestamp>.tar.gz`

## 2) Copy to work PC

Copy and extract the tarball (or zip it first if needed by your transfer policy).

## 3) Configure runtime

Inside extracted folder:

```bash
cp .env.standalone.example .env.standalone
```

Edit `.env.standalone`:

- Use Postgres if available:
  - `DATABASE_URL=postgresql+psycopg://aml:aml@127.0.0.1:5432/aml_portal`
- Or fallback to SQLite:
  - `DATABASE_URL=sqlite:///./data/aml_portal.db`

## 4) Start/stop

```bash
./scripts/start_standalone.sh
# open http://127.0.0.1:5174

./scripts/stop_standalone.sh
```

## Notes

- Frontend is prebuilt, so Node is not required on target for serving UI.
- Python packages are installed into project-local `.venv` on first start.
- If your work PC cannot create a venv or install packages, we can pre-bundle wheels/venv for your exact OS.
- Bind host defaults to `127.0.0.1` for local-only access.
